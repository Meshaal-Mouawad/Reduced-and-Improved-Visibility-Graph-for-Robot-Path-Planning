# JOCO V22.8 source and build

## Build the reviewed manuscript PDF
Run these commands from this directory with TeX Live:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex8 main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

`main.pdf` is the fully checked initial-submission manuscript.

## Journal-specified Springer formatting
The journal's author instructions specify Springer `svjour3` with `smallextended`.
`main_smallextended.tex` contains the IDENTICAL scientific text, figures, bibliography,
Data Availability DOI and declarations. `build_smallextended.sh` retrieves the
publisher-provided style files and compiles this variant on a Mac with TeX Live.

The `svjour3` class was not installed in the current authoring runtime, so that
optional class-specific PDF was not rebuilt here. The journal's official guidelines
permit an initial PDF submission and request LaTeX editable sources.

## Evidence and provenance
The primary data link is https://doi.org/10.7910/DVN/TICP0N.
The public project repository is:
https://github.com/Meshaal-Mouawad/Reduced-and-Improved-Visibility-Graph-for-Robot-Path-Planning
Two current research resources are Evidence/ESM_1.zip (ROBOTICA-PQV-v10)
and Evidence/ESM_2.zip (JIRS-TWO-TRACE-v1.1).

Theorem, proofs, frozen numerical results, figures, ORCID and AI declaration are unchanged from V22.5.

## V22.7 editorial adjustments
Table 1 now compares the directly relevant 2026 lazy-lifelong study, and Table 2 specifies that the count threshold is inclusive. Theorem, counts, figures, data links and AI declaration are unchanged.

## V22.8 reviewer finding R1
Figure 4 caption opening now reads "Cost analysis." in both main.tex and main_smallextended.tex; the figure itself and all numerical results are unchanged.
