#!/usr/bin/env bash
# Build using the Springer journal's documented svjour3/smallextended class.
set -euo pipefail
cd "$(dirname "$0")"
URL='https://media.springer.com/full/springer-instructions-for-authors-assets/zip/468198_LaTeX_DL_468198_240419.zip'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
if [[ ! -s svjour3.cls || ! -s svglov3.clo || ! -s spmpsci.bst ]]; then
  echo 'Obtaining the Springer style files from the official template ZIP...'
  curl -fLsS --retry 2 "$URL" -o "$TMP/Springer.zip"
  for name in svjour3.cls svglov3.clo spmpsci.bst; do
    entry="$(unzip -Z1 "$TMP/Springer.zip" | grep -E "(^|/)${name}$" | head -1 || true)"
    if [[ -z "$entry" ]]; then
      echo "Missing $name in downloaded Springer macro package" >&2
      exit 2
    fi
    unzip -p "$TMP/Springer.zip" "$entry" > "$name"
  done
fi
pdflatex -interaction=nonstopmode -halt-on-error main_smallextended.tex
bibtex8 main_smallextended
pdflatex -interaction=nonstopmode -halt-on-error main_smallextended.tex
pdflatex -interaction=nonstopmode -halt-on-error main_smallextended.tex
printf '\nBuilt main_smallextended.pdf using the Springer svjour3 class.\n'
