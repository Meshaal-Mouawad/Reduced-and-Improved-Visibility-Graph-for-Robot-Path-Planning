# JIRS manuscript figure filenames

| Figure | Manuscript assets | Descriptive basename in the computational record |
| --- | --- | --- |
| 1 | `figures/Fig1` (PDF, SVG and PNG) | `navigation_context` |
| 2 | `figures/Fig2` (PDF, SVG and PNG) | `foundation_route` |
| 3 | `figures/Fig3` (PDF, SVG and PNG) | `foundation_footprint` |
| 4 | `figures/Fig4` (PDF, SVG and PNG) | `persistent_requests` |
| 5 | `figures/Fig5` (PDF, SVG and PNG) | `cache_storyboard` |
| 6 | `figures/Fig6` (PDF, SVG and PNG) | `two_trace_mechanism` |
| 7 | `figures/Fig7` (PDF, SVG and PNG) | `completion_policies` |
| 8 | `figures/Fig8` (PDF, SVG and PNG) | `study_design` |
| 9 | `figures/Fig9` (PDF, SVG and PNG) | `observed_requests` |
| 10 | `figures/Fig10` (PDF, SVG and PNG) | `completion_frontiers` |
| 11 | `figures/Fig11` (PDF, SVG and PNG) | `completion_investment` |
| 12 | `figures/Fig12` (PDF, SVG and PNG) | `search_costs` |
| 13 | `figures/Fig13` (PDF, SVG and PNG) | `endpoint_ablation` |
| 14 | `figures/Fig14` (PDF, SVG and PNG) | `query_horizon` |
| 15 | `figures/Fig15` (PDF, SVG and PNG) | `failure_trace` |
| 16 | `figures/Fig16` (PDF, SVG and PNG) | `time_signal` |

The separate graphical abstract uses the basename `graphical_abstract`.
