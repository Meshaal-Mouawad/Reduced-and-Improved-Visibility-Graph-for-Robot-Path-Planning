# Algorithm packages

The source directory carries `algorithm.sty`, `algorithmicx.sty` and `algpseudocode.sty` so the manuscript can build on a TeX installation that lacks those files.

- `algorithm.sty` was generated from the unmodified `algorithms.ins` and `algorithms.dtx` in `algorithms.zip`. The generated file retains its copyright and GNU Lesser General Public License notice. `algorithms-COPYING.txt` and `algorithms-README.txt` are copies from the upstream archive. [CTAN algorithms](https://ctan.org/pkg/algorithms)
- `algorithmicx.sty` and `algpseudocode.sty` are unmodified files from `algorithmicx.zip`. The upstream documentation identifies the LaTeX Project Public License. `algorithmicx-README.txt` is the upstream README. [CTAN algorithmicx](https://ctan.org/pkg/algorithmicx)

Both ZIP archives are included byte-for-byte as obtained from CTAN.
