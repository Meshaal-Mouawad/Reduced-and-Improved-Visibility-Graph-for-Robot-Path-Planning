# Build the JIRS manuscript

Run this command from the extracted source directory with Python 3 and a TeX installation that provides `pdflatex` and `bibtex`.

```sh
python3 build_pdf.py
```

Use the complete TeX Live distribution or an equivalent installation with the packages listed in `main.tex`. The source includes Springer Nature’s December 2024 `sn-jnl` class, its `sn-mathphys-num` bibliography style, and local algorithm package files. Keep those files with `main.tex`, `references.bib` and the figure directory. The build runs PDF compilation and bibliography generation from fresh auxiliary files and writes `main.pdf`, `main.bbl`, `main.log` and `main.blg` on success. The unmodified algorithm package sources and notices are in `third_party/`.

For Overleaf, upload the source directory, select `main.tex` as the main document and select pdfLaTeX as the compiler. The equivalent command sequence for a normal local TeX installation is below. If the log asks for another pass to resolve cross-references, run pdfLaTeX again.

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

All manuscript text, equations and tables are in the single `main.tex` file. The figures are supplied as vector PDFs, editable SVGs and PNG previews. The graphical abstract is a separate asset. Rebuilding the manuscript uses the archived analysis outputs and requires no study execution.

For a TeX Live environment with an independently prepared local format and font map, set `JIRS_TEX_RUNTIME` to the path of that runtime tree. A normal TeX installation uses its own configuration.

## Figure filenames

The numbered PDF files are the manuscript inputs. The matching SVG files are editable sources and the matching PNG files are previews. FIGURE_FILENAMES.md maps the supplied numbers to the descriptive basenames used by the computational supplements.

## v20 release

This source builds the JIRS V20 manuscript. The only manuscript text change from V19 is the release identifier in Supplementary information, corrected from JIRS-TWO-TRACE-v1 to JIRS-TWO-TRACE-v1.1. Online Resource 2 is release JIRS-TWO-TRACE-v1.1 and documents a Python-version decimal-formatting reproducibility correction in its helper. The study inputs and recorded analyses are preserved. Its two named aggregate CSVs are compared using bounded last-bit float tolerance; primary direct outputs require identical SHA-256 hashes. See `JIRS_v19_Verification_Report.pdf` in the separate research package.
