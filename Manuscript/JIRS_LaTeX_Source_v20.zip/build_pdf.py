#!/usr/bin/env python3
"""Build the Springer Nature manuscript with pdfLaTeX and BibTeX."""

from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory


SOURCE = Path(__file__).resolve().parent
PUBLISHER_FILES = ("main.tex", "sn-jnl.cls", "sn-mathphys-num.bst", "references.bib")
BUILD_OUTPUTS = ("main.pdf", "main.bbl", "main.log", "main.blg")


def search_tex(kpsewhich: str, environment: dict[str, str], *arguments: str) -> str:
    result = subprocess.run(
        [kpsewhich, *arguments], env=environment, cwd=SOURCE,
        capture_output=True, text=True, check=False,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def build_environment() -> dict[str, str]:
    environment = os.environ.copy()
    kpsewhich = shutil.which("kpsewhich")
    if kpsewhich is None:
        return environment

    format_query = ("-format=fmt", "-engine=pdftex", "-progname=pdflatex", "pdflatex.fmt")
    format_available = search_tex(kpsewhich, environment, *format_query)
    algorithm_available = search_tex(kpsewhich, environment, "algorithm.sty")
    pseudocode_available = search_tex(kpsewhich, environment, "algpseudocode.sty")
    configured_runtime = environment.get("JIRS_TEX_RUNTIME")
    if format_available and algorithm_available and pseudocode_available and not configured_runtime:
        return environment

    local_runtime = Path(configured_runtime or SOURCE.parent / "venue" / "texlive_runtime").resolve()
    format_directory = local_runtime / "web2c" / "pdftex"
    if not (format_directory / "pdflatex.fmt").is_file():
        if configured_runtime:
            raise RuntimeError(f"No compiled pdfLaTeX format in JIRS_TEX_RUNTIME: {local_runtime}")
        return environment

    # Find the user's TeX Live trees and allow filesystem lookup when the
    # distribution's prebuilt filename indices are unavailable.
    tree_variables = ("TEXMFDIST", "TEXMFLOCAL", "TEXMFSYSCONFIG", "TEXMFSYSVAR", "TEXMFHOME")
    trees = [str(local_runtime)]
    for variable in tree_variables:
        tree = search_tex(kpsewhich, environment, f"-var-value={variable}")
        if tree and Path(tree).is_dir() and tree not in trees:
            trees.append(tree)

    environment["TEXMF"] = "{" + ",".join(trees) + "}"
    environment["TEXMFVAR"] = str(local_runtime)
    environment["TEXFORMATS"] = str(format_directory) + os.pathsep
    print(f"Using local TeX runtime at {local_runtime}")
    return environment


def run(command: list[str], directory: Path, environment: dict[str, str]) -> None:
    result = subprocess.run(
        command, cwd=directory, env=environment, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False,
    )
    if result.returncode:
        print(result.stdout[-12000:], file=sys.stderr)
        raise RuntimeError(f"{Path(command[0]).name} failed with exit code {result.returncode}.")


def main() -> None:
    missing_files = [filename for filename in PUBLISHER_FILES if not (SOURCE / filename).is_file()]
    if missing_files:
        raise RuntimeError("Extract the complete source archive. Missing files: " + ", ".join(missing_files))

    latex = shutil.which("pdflatex")
    bibtex = shutil.which("bibtex")
    if latex is None or bibtex is None:
        raise RuntimeError("Install pdfLaTeX and BibTeX or compile main.tex in Overleaf with pdfLaTeX.")

    environment = build_environment()
    for path_variable in ("BSTINPUTS", "BIBINPUTS"):
        environment[path_variable] = str(SOURCE) + os.pathsep + environment.get(path_variable, "")

    # Build with fresh auxiliaries and preserve the existing PDF on error.
    with TemporaryDirectory(prefix=".jirs-build-", dir=SOURCE) as directory:
        build = Path(directory)
        command = [latex, "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
                   f"-output-directory={build}", "main.tex"]
        run(command, SOURCE, environment)
        run([bibtex, "main"], build, environment)

        for _ in range(6):
            run(command, SOURCE, environment)
            log = (build / "main.log").read_text(errors="replace")
            if not any(message in log for message in (
                "Label(s) may have changed", "Rerun to get cross-references right",
                "Rerun to get outlines right", "Rerun to get citations correct",
            )):
                break
        else:
            raise RuntimeError("References did not stabilize after six passes.")

        if "undefined references" in log or "undefined citations" in log:
            raise RuntimeError("The compiled manuscript contains unresolved references or citations.")
        if any(not (build / name).is_file() for name in BUILD_OUTPUTS):
            raise RuntimeError("The compiler did not produce all expected outputs.")

        for name in BUILD_OUTPUTS:
            (build / name).replace(SOURCE / name)

    print(f"Built {SOURCE / 'main.pdf'}")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError) as error:
        print(f"BUILD ERROR: {error}", file=sys.stderr)
        sys.exit(1)
