#!/usr/bin/env python3
"""Verify S1 and reproduce saved-result analyses in a separate working copy."""
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess, sys, time
from pathlib import Path

def sha(p: Path) -> str: return hashlib.sha256(p.read_bytes()).hexdigest()
def main() -> None:
    root=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--verify-only',action='store_true');p.add_argument('--output',type=Path);p.add_argument('--skip-figures',action='store_true');a=p.parse_args()
    manifest=json.loads((root/'MANIFEST_SHA256.json').read_text())
    errors=[name for name,h in manifest.items() if not (root/name).is_file() or sha(root/name)!=h]
    if errors: raise RuntimeError('Manifest mismatch: '+', '.join(errors))
    print(f'Manifest verified: {len(manifest)} files.',flush=True)
    if a.verify_only:return
    if a.output is None:raise RuntimeError('Specify a new --output directory outside the archive.')
    out=a.output.resolve()
    if out==root or root in out.parents:raise RuntimeError('Output must be outside the archive to preserve frozen files.')
    if out.exists():raise RuntimeError('Output directory already exists; choose a new location.')
    out.mkdir(parents=True);work=out/'working_copy';shutil.copytree(root,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    logs=out/'logs';logs.mkdir();checks=[]
    def run(script,*args):
        log=logs/(script.replace('/','_')+'.log');t=time.perf_counter()
        with log.open('w') as f:r=subprocess.run([sys.executable,str(work/script),*map(str,args)],cwd=work,stdout=f,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError(f'{script} failed; inspect {log}')
        checks.append({'script':script,'exit_code':0,'seconds':time.perf_counter()-t});print('Completed:',script,flush=True)
    run('study/analyze.py')
    import pandas as pd
    def compare_csv(a,b):
        x=pd.read_csv(a);y=pd.read_csv(b);pd.testing.assert_frame_equal(x,y,check_exact=False,rtol=1e-11,atol=1e-11)
        return {'file':str(a.relative_to(root)),'rows':len(x),'match':True}
    comparisons=[compare_csv(f,work/'study/analysis'/f.name) for f in (root/'study/analysis').glob('*.csv')]
    identity=json.loads((work/'study/analysis/accounting_identity.json').read_text());assert identity==json.loads((root/'study/analysis/accounting_identity.json').read_text())
    assert all(x['exact_identity'] and x['same_switch'] and x['same_persistent_checks'] for x in identity)
    run('study/test_planners.py')
    run('study/exact_verify.py',work/'study/results')
    exact=json.loads((work/'study/results/exact_verification.json').read_text());assert exact['passed'] and not exact['errors']
    expected={'reference_queries':8640,'verified_routes':120960,'distinct_verified_segments':16843,'fraction_crosschecks':1440,'analytic_fixtures':8}
    assert all(exact[k]==v for k,v in expected.items())
    run('revision_analysis/timing_robustness.py')
    for f in (root/'revision_analysis/results').glob('*.csv'):comparisons.append(compare_csv(f,work/'revision_analysis/results'/f.name))
    run('revision_analysis/analyze_replay.py')
    for f in (root/'revision_analysis/replay_analysis').glob('*.csv'):comparisons.append(compare_csv(f,work/'revision_analysis/replay_analysis'/f.name))
    if not a.skip_figures:
        run('study/make_failure_trace.py')
        run('visual_sources/prepare_graph_evidence.py')
        run('visual_sources/build_schematics.py')
        run('visual_sources/build_data_charts.py')
        for name in ['search_costs','endpoint_ablation','query_horizon','failure_trace','time_signal']:
            comparisons.append(compare_csv(root/f'visual_data/{name}.csv',work/f'visual_data/{name}.csv'))
        for name in ['constructed_graph_comparison','observed_graph_comparison']:
            assert json.loads((root/f'visual_data/{name}.json').read_text())==json.loads((work/f'visual_data/{name}.json').read_text())
    report={'passed':True,'manifest_files':len(manifest),'executed':checks,'numerical_comparisons':comparisons,'exact_geometric_check':exact,'accounting_pairs':sum(x['request_pairs'] for x in identity),'scope':'Saved primary and follow-up records reproduced; no original timing run replaced; current regression driver checked; no new timing measurements in this command.'}
    (out/'REPRODUCTION_REPORT.json').write_text(json.dumps(report,indent=2));print('PASS:',out/'REPRODUCTION_REPORT.json',flush=True)
if __name__=='__main__':
    try:main()
    except (RuntimeError,AssertionError,OSError) as e:
        print(f'FAILED: {e}',file=sys.stderr);sys.exit(1)
