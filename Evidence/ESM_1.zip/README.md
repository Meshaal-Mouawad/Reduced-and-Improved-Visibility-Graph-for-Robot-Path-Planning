# Supplementary Material S1 — ROBOTICA-PQV-v10

**Paper:** Persistent and Query-Specific Collision Validation in Multi-Query Robot Path Planning.  
**Author:** Meshaal Mouawad. **Archive:** `Robotica_Computational_Supplement_v10.zip`.

This is the exact reviewer-accessible release identified in the v10 manuscript. It contains the current Python study, not merely the historical MATLAB project. `RELEASE.json` identifies the version and primary hashes; `MANIFEST_SHA256.json` identifies all files.

## Verify and reproduce
Use Python 3.13 and install `python -m pip install -r requirements.txt`. The pinned packages are the tested reproduction environment; original dependency provenance is separately documented.

```
python reproduce.py --verify-only
python reproduce.py --output /tmp/robotica-v10-reproduced
```

The second command works on a separate copy and never overwrites the archived original records. It recalculates primary paired summaries, exact collision accounting, independent reference lengths and archived route checks, implementation regressions, original per-repetition timing phases, and checkpoint-replay summaries. It also regenerates empirical plotting inputs and geometric evidence. It writes a machine-readable `REPRODUCTION_REPORT.json` and logs. The computations use the saved measurements; no new benchmark timing run is needed.

## Re-run the focused experiment separately

```
python revision_analysis/matched_checkpoint_replay.py --study study --out /tmp/robotica-v10-new-timing
python revision_analysis/analyze_replay.py --input /tmp/robotica-v10-new-timing --out /tmp/robotica-v10-new-analysis
```

New timings should remain a separate experiment. Do not overwrite the archived `replay` directory. The protocol fixes all 129 triggered engine/workloads, 20 paired repetitions, alternating policy order and no adaptive stopping. Runtime magnitudes can differ on another machine; route lengths and operation profiles are checked against the frozen study.

## Evidence layout
- `study/`: byte-identical v9 study records and source, including 362,880 primary timed query rows.
- `revision_analysis/results/`: new decomposition of original runs before summarization.
- `revision_analysis/replay/`: new matched-checkpoint measurements and contemporaneous environment.
- `revision_analysis/replay_analysis/`: deterministic summaries of those new records.
- `visual_sources/`, `visual_data/`, `manuscript/figures/`: editable, reproducible scientific figures and exact plotting inputs.
- `supplement/`: the adverse trace and selected raw records.
- `verification/`: reproduction checks, logs, source-hash comparison and disclosed provenance boundaries.
- `RESULT_TRACEABILITY.csv`: result-to-record-to-command map.
- `ENVIRONMENT_PROVENANCE.md`: original, follow-up and production environments, kept distinct.

The same 2021 MATLAB attribution and project history remain in `provenance/Research_Provenance.md`. The original Zenodo technical note is historical provenance; it is not claimed to host this Python release. No public DOI or repository upload is asserted for S1.
