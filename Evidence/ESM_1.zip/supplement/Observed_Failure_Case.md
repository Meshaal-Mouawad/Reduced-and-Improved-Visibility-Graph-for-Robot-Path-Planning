# Supplementary observed adverse-case trace

Workload: **maprandomStartAndGoalSmall8__shifted**. Selection: largest final persistent-only/permanently-lazy A* time ratio among the 60 switched workloads. This is an explicitly post-hoc explanation of an unfavorable case, not a new experiment or a representative sample.

The persistent-only/permanently-lazy ratio is **2.359**; the persistent-only/bundled ratio is **1.302**. The completion work is charged at request 35. The plot shows the median cumulative total across three repetitions at each request. Initial construction is included. Every reconstructed forty-query total exactly matches the archived prefix record.

![Observed adverse-case trace](failure_trace.png)

| Policy | Median total at 40 requests (ms) | Persistent checks | Terminal checks | Completion checks (included in persistent) | Adjacency inspections |
|---|---:|---:|---:|---:|---:|
| Permanently lazy | 17.216 | 60 | 171 | 0 | 14570 |
| Complete persistent edges; lazy terminals | 40.608 | 239 | 171 | 181 | 14570 |
| Complete persistent edges; eager terminals | 31.185 | 239 | 370 | 181 | 13231 |

The comparison separates two observations: completing unknown persistent edges purchases checks that permanent laziness may never request; making later terminal connections eager adds a different recurring charge. The saved counters quantify both operations. They do not assign every elapsed-time difference to a single counter. Exact route verification for this workload is part of the main verification record.

Rebuild with `python study/make_failure_trace.py`. Editable SVG, vector PDF, PNG, selected raw records and the selection rule are included.

## Interpreting the trace

Before request 35, the bundled and persistent-only policies have exactly equal collision-check, vertex-processing, adjacency-inspection and search-call totals in each repetition. Their elapsed-time curves nevertheless differ before the intervention. That pre-event difference cannot be attributed to the later change in validation policy. The example records the observed timings and operation counts; its selection by the largest final ratio makes it an adverse-case diagnostic, not an estimate of a causal timing effect or of a typical workload.
