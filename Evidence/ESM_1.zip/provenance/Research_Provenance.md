# Historical source provenance

- Repository: https://github.com/Meshaal-Mouawad/Reduced-and-Improved-Visibility-Graph-for-Robot-Path-Planning
- Repository creation: 2021-09-17T20:55:30Z; initial commit: `2700dda4be4230501b59f3ea30efb1fcf149f1f0`, 2021-09-17T20:55:31Z.
- Repository evaluated revision: `fd805345f6e80e077e22fa2dbe05a61ed1048964` (2026).
- Original project report cover date: 14 February 2025.
- Original project source attribution, retained without rewording: `% Evloved from Aditya Jain's codes` and `% Edited by Meshaal Mouawad 10/01/2021`.
- Repository license: MIT License, copyright (c) 2021 Meshaal Mouawad; original rights and attribution remain in the repository.
- Later research archival DOI: 10.5281/zenodo.20682235; cite as technical note, separately from new experiments.
- 2021 establishes research origin, not a journal publication date. Later experiments in 2026 are not backdated.
- Original MATLAB source was read remotely and not modified or republished in this release; exact source remains at its attributed upstream repository. The original report is preserved here as author research evidence.
