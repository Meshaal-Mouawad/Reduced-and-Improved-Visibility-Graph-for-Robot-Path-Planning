# Measurement and reconstruction environments

## Original experiment (primary end-to-end timings)
The unmodified `study/results/metadata.json` is the contemporaneous authority. It records Python 3.13.5, Linux 6.18.57 x86-64, glibc 2.41, start/completion timestamps, frozen input hash and source hashes. Processor model, CPU scheduling/affinity and the original NumPy version were not recorded and could not be recovered. The current host is **not** used to fill those fields.

The five contemporaneously hashed files used for input generation, measured execution, geometry, planning, and the independent reference match the recovered originals byte-for-byte. `test_planners.py` has a different hash: the archive contains a later regression-test revision, not the test-driver version in the original metadata. This driver is not imported by `run_study.py` or `planners.py`. Its recovered revision was run for this release and is identified by the final manifest. The older test revision was not found in the supplied historical packages. No original source hash has been silently amended.

## Focused matched-checkpoint follow-up
`revision_analysis/replay/environment.json` was captured for the actual follow-up. It identifies an AMD EPYC 9V74 CPU, one-CPU affinity, Python 3.13.5, NumPy 2.3.5, monotonic nanosecond timer, garbage-collection policy, paired execution order, protocol and driver hashes, and observation counts. These settings belong only to the follow-up. Timestamps are retained exactly as reported by the execution host's UTC clock. The clock reports 4 November 2026; the manuscript revision context is 5 November 2026. Neither timestamp has been reassigned to the 2021 research origin.

## Reproduction and production
`requirements.txt` pins the successfully used current analysis and figure dependencies. It is a tested reproduction environment, not a claim that the original experiment used each of these versions. The raw original timing records are reproduced by deterministic recalculation, not expected to be recreated numerically by a timing rerun on another machine. `verification/production_environment.json` records the later environment separately.
