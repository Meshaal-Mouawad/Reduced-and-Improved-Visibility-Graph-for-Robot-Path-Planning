"""Rebuild a declared adverse-case illustration from the frozen v5 timing records."""
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

H=Path(__file__).resolve().parent
O=H.parent/'supplement';O.mkdir(exist_ok=True)
pairs=pd.read_csv(H/'analysis/triggered_astar.csv')
case=pairs.sort_values(['versus_lazy','workload_id'],ascending=[False,True]).iloc[0]
wid=case.workload_id
q=pd.read_csv(H/'results/queries.csv')
p=pd.read_csv(H/'results/prefixes.csv')
modes=['lazy_astar','internal_astar','bundled_astar']
q=q[(q.workload_id==wid)&q['mode'].isin(modes)].copy()
p=p[(p.workload_id==wid)&p['mode'].isin(modes)].copy()
traces=[]
for (mode,rep),rows in q.groupby(['mode','repeat']):
 rows=rows.sort_values('index').copy()
 endpoints=p[(p['mode']==mode)&(p['repeat']==rep)].set_index('horizon')
 initial=int(endpoints.loc[1,'time_ns'])-int(rows.iloc[0].time_ns)
 rows['cumulative_ns']=rows.time_ns.cumsum()+initial
 assert int(rows.iloc[-1].cumulative_ns)==int(endpoints.loc[40,'time_ns'])
 rows['request']=rows['index']+1
 traces.append(rows)
a=pd.concat(traces,ignore_index=True)
a.to_csv(O/'failure_trace_records.csv',index=False)
v=a.groupby(['mode','request'],as_index=False).cumulative_ns.median()
complete=a[(a['mode']=='internal_astar')&(a.completion_checks>0)]
positions=sorted(complete.request.unique().tolist())
fig,ax=plt.subplots(figsize=(6.6,3.8))
labels={'lazy_astar':'Permanently lazy','internal_astar':'Complete persistent edges; lazy terminals','bundled_astar':'Complete persistent edges; eager terminals'}
for mode in modes:
 d=v[v['mode']==mode]
 ax.plot(d.request,d.cumulative_ns/1e6,label=labels[mode])
for i,pos in enumerate(positions):
 ax.axvline(pos,linestyle=':',linewidth=1,label='Persistent completion charged' if i==0 else None)
ax.set_xlabel('Completed requests');ax.set_ylabel('Median cumulative time (ms)')
ax.legend(fontsize=8);ax.grid(axis='y',alpha=.2);fig.tight_layout()
for ext in ('pdf','svg','png'):fig.savefig(O/f'failure_trace.{ext}',dpi=220,bbox_inches='tight')
plt.close(fig)
record={'workload_id':wid,'selection':'Largest persistent-only/permanently-lazy median 40-request time ratio among the 60 count-triggered A* workloads; ties lexicographic. Post-hoc adverse-case explanation, not a representative sample.','case_ratio_internal_to_lazy':float(case.versus_lazy),'case_ratio_internal_to_bundled':float(case.ratio),'completion_charged_requests':positions,'repetitions':3,'source_files':['analysis/triggered_astar.csv','results/queries.csv','results/prefixes.csv'],'cumulative_totals_match_archived_prefixes':True}
(O/'failure_trace_provenance.json').write_text(json.dumps(record,indent=2))
last=a[a.request==40].groupby('mode').cumulative_ns.median()/1e6
ct=a.groupby(['mode','repeat'])[['persistent_checks','terminal_checks','completion_checks','scans','pops','search_calls']].sum().groupby('mode').median()
text=f'''# Supplementary observed adverse-case trace\n\nWorkload: **{wid}**. Selection: largest final persistent-only/permanently-lazy A* time ratio among the 60 switched workloads. This is an explicitly post-hoc explanation of an unfavorable case, not a new experiment or a representative sample.\n\nThe persistent-only/permanently-lazy ratio is **{case.versus_lazy:.3f}**; the persistent-only/bundled ratio is **{case.ratio:.3f}**. The completion work is charged at request {', '.join(map(str,positions))}. The plot shows the median cumulative total across three repetitions at each request. Initial construction is included. Every reconstructed forty-query total exactly matches the archived prefix record.\n\n![Observed adverse-case trace](failure_trace.png)\n\n| Policy | Median total at 40 requests (ms) | Persistent checks | Terminal checks | Completion checks (included in persistent) | Adjacency inspections |\n|---|---:|---:|---:|---:|---:|\n'''
for mode in modes:
 r=ct.loc[mode]
 text+=f'| {labels[mode]} | {last[mode]:.3f} | {r.persistent_checks:.0f} | {r.terminal_checks:.0f} | {r.completion_checks:.0f} | {r.scans:.0f} |\n'
text+='\nThe comparison separates two observations: completing unknown persistent edges purchases checks that permanent laziness may never request; making later terminal connections eager adds a different recurring charge. The saved counters quantify both operations. They do not assign every elapsed-time difference to a single counter. Exact route verification for this workload is part of the main verification record.\n\nRebuild with `python study/make_failure_trace.py`. Editable SVG, vector PDF, PNG, selected raw records and the selection rule are included.\n'
# Check pre-intervention operation equality; do not attribute pre-event timing variation to completion.
cut=min(positions)
cols=['checks','pops','scans','search_calls','persistent_checks','terminal_checks']
pre=a[a.request<cut].groupby(['mode','repeat'])[cols].sum().reset_index()
bp=pre[pre['mode']=='bundled_astar'].set_index('repeat')[cols]
ip=pre[pre['mode']=='internal_astar'].set_index('repeat')[cols]
assert bp.equals(ip)
pre.to_csv(O/'precompletion_operation_check.csv',index=False)
record['precompletion_bundled_internal_operation_counts_equal']=True
(O/'failure_trace_provenance.json').write_text(json.dumps(record,indent=2))
text+='\n## Interpreting the trace\n\nBefore request '+str(cut)+', the bundled and persistent-only policies have exactly equal collision-check, vertex-processing, adjacency-inspection and search-call totals in each repetition. Their elapsed-time curves nevertheless differ before the intervention. That pre-event difference cannot be attributed to the later change in validation policy. The example records the observed timings and operation counts; its selection by the largest final ratio makes it an adverse-case diagnostic, not an estimate of a causal timing effect or of a typical workload.\n'
(O/'Observed_Failure_Case.md').write_text(text)
print(f'Observed failure trace saved for {wid}; cumulative totals verified.')
