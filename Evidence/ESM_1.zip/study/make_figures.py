"""Rebuild publication figures from the released measurements, without manual colors."""
from pathlib import Path
import json,gzip,math
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
H=Path(__file__).resolve().parent;A=H/'analysis';O=H.parent/'manuscript/figures';O.mkdir(parents=True,exist_ok=True)
assert json.loads((H/'results/exact_verification.json').read_text())['passed']
med=pd.read_csv(A/'workload_medians.csv');rat=pd.read_csv(A/'paired_workloads.csv');summary=pd.read_csv(A/'paired_summary.csv')
def save(fig,name):
 fig.tight_layout();fig.savefig(O/(name+'.pdf'),bbox_inches='tight');fig.savefig(O/(name+'.svg'),bbox_inches='tight');fig.savefig(O/(name+'.png'),dpi=220,bbox_inches='tight');plt.close(fig)
# Each chart has one axes; no decorative or synthetic data panels.
cases=json.loads((H/'inputs.json').read_text());m=next(m for m in cases if m['corpus']=='generated' and m['family']=='rectangles' and len(m['obstacles'])==8 and m['regime']=='shifted')
selected={}
with gzip.open(H/'results/paths.jsonl.gz','rt')as f:
 for line in f:
  r=json.loads(line)
  if r['workload_id']==m['workload_id'] and r['mode']=='lazy_astar' and r['index'] in (0,20):selected[r['index']]=r
fig,ax=plt.subplots(figsize=(6.5,3.8))
for po in m['obstacles']:ax.add_patch(Polygon(po,closed=True,alpha=.25,hatch='//',linewidth=.7))
for index,label,style in [(0,'Request 1: left region','-'),(20,'Request 21: right region','--')]:
 r=selected[index];xy=np.array(r['path']);ax.plot(xy[:,0],xy[:,1],style,marker='o',markersize=3,label=label)
 ax.annotate('S',xy[0],xytext=(4,4),textcoords='offset points');ax.annotate('G',xy[-1],xytext=(4,4),textcoords='offset points')
ax.set_aspect('equal',adjustable='datalim');ax.autoscale_view();ax.set_xlabel('Map coordinate (coordinate units)');ax.set_ylabel('Map coordinate (coordinate units)');ax.legend(fontsize=8,loc='best');save(fig,'query_geometry')
(O/'query_geometry_provenance.json').write_text(json.dumps(dict(workload_id=m['workload_id'],mode='lazy_astar',request_indices=[0,20],selection='First archived generated eight-obstacle rectangle configuration; shifted query sequence'),indent=2))
fig,ax=plt.subplots(figsize=(6.5,3.3));labels=[]
for j,metric in enumerate(('pops','scans','time_ns')):
 d=summary[(summary.numerator=='lazy_lpa_query')&(summary.denominator=='lazy_astar')&(summary.horizon==40)&(summary.metric==metric)].set_index('corpus').loc[['generated','external','finite']]
 x=np.arange(3)+(j-1)*.22;ax.errorbar(x,d['median'],yerr=[d['median']-d['low'],d['high']-d['median']],fmt='o',capsize=3,label={'pops':'Processed vertices','scans':'Adjacency inspections','time_ns':'Total time'}[metric])
ax.axhline(1,linestyle='--',linewidth=.8);ax.set_xticks(range(3),['Generated','External','Fixed square']);ax.set_ylabel('Query-local LPA* / restarted A*');ax.legend(fontsize=8,ncol=3,loc='upper center',bbox_to_anchor=(.5,1.18));ax.grid(axis='y',alpha=.16);save(fig,'search_costs')
fig,ax=plt.subplots(figsize=(6.5,3.6));labels=[];j=0
for engine,label in [('astar','A*'),('lpa_query','LPA*: query-local'),('lpa_persistent','LPA*: retained')]:
 d=pd.read_csv(A/f'triggered_{engine}.csv')
 for corpus,name in [('generated','generated'),('external','external'),('finite','fixed square')]:
  g=d[d.corpus==corpus];v=np.sort(g.ratio.to_numpy());jitter=np.linspace(-.16,.16,len(v)) if len(v)>1 else [0]
  ax.scatter(v,np.full(len(v),j)+jitter,s=15,alpha=.65);ax.plot([np.median(v)],[j],marker='D',markersize=5)
  labels.append(f'{label}; {name} (n={len(v)})');j+=1
ax.axvline(1,linestyle='--',linewidth=.8);ax.set_yticks(range(j),labels,fontsize=8);ax.invert_yaxis();ax.set_xlabel('Persistent-only / bundled total time at 40 requests');ax.grid(axis='x',alpha=.15);save(fig,'endpoint_ablation')
fig,ax=plt.subplots(figsize=(6.5,3.4))
for mode,label,style in [('internal_astar','Persistent-only completion','-'),('bundled_astar','Bundled completion','--'),('timed_astar','Time-triggered bundled completion',':'),('fixed_astar','Initial-budget completion','-.')]:
 d=summary[(summary.numerator==mode)&(summary.denominator=='lazy_astar')&(summary.metric=='time_ns')&(summary.corpus=='generated')].sort_values('horizon');ax.plot(d.horizon,d['median'],style,marker='o',label=label)
ax.axhline(1,linestyle='--',linewidth=.7);ax.set_xticks([1,5,20,40]);ax.set_xlabel('Completed requests after one construction');ax.set_ylabel('Median paired total time / permanent laziness');ax.legend(fontsize=8,loc='best');ax.grid(alpha=.15);save(fig,'query_horizon')
fig,ax=plt.subplots(figsize=(6.5,3.3))
for j,(engine,label) in enumerate([('astar','A*'),('lpa_query','Query-local LPA*'),('lpa_persistent','Retained LPA*')]):
 d=summary[(summary.numerator=='timed_'+engine)&(summary.denominator=='lazy_'+engine)&(summary.horizon==40)&(summary.metric=='time_ns')].set_index('corpus').loc[['generated','external','finite']]
 ax.errorbar(np.arange(3)+(j-1)*.21,d['median'],yerr=[d['median']-d['low'],d['high']-d['median']],fmt='o',capsize=3,label=label)
ax.axhline(1,linestyle='--',linewidth=.8);ax.set_xticks(range(3),['Generated','External','Fixed square']);ax.set_ylabel('Time-triggered completion / permanent laziness');ax.legend(fontsize=8);ax.grid(axis='y',alpha=.15);save(fig,'time_signal')
print('Five distinct, data-linked figures written in PDF, SVG and PNG.')
