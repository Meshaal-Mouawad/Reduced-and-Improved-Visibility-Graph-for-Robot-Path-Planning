"""Run serially. An existing output directory is never overwritten."""
import argparse,csv,gzip,json,hashlib,datetime,platform,random,time,sys
from pathlib import Path
from planners import Planner,MODES
H=Path(__file__).resolve().parent
METRICS=['time_ns','checks','pops','scans','rhs_updates','pushes','search_calls','extra_pops','completion_checks','completion_ns','persistent_checks','terminal_checks','terminal_candidates','check_time_ns','search_time_ns','extra_search_ns','edge_repair_ns','terminal_repair_ns']
def main(out,repeats=3,pilot=False):
 import math
 out=Path(out);out.mkdir(exist_ok=False,parents=True);cases=json.loads((H/'inputs.json').read_text())
 if pilot:cases=[{**cases[i],'queries':cases[i]['queries'][:6]} for i in [0,1,2,60,120,179,180,215]]
 meta=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=sys.version,platform=platform.platform(),repeats=repeats,modes=list(MODES),workloads=len(cases),query_cases=sum(len(c['queries']) for c in cases),pilot=pilot,inputs_sha256=hashlib.sha256((H/'inputs.json').read_bytes()).hexdigest(),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in H.glob('*.py')})
 (out/'metadata.json').write_text(json.dumps(meta,indent=2));rng=random.Random(20261104);begin=time.perf_counter();w=pw=None
 with (out/'queries.csv').open('w',newline='') as f,(out/'prefixes.csv').open('w',newline='') as g,gzip.open(out/'paths.jsonl.gz','wt') as paths:
  for k,m in enumerate(cases):
   expected=None
   for rep in range(repeats):
    modes=list(MODES);rng.shuffle(modes)
    for mode in modes:
     planner=Planner(m['obstacles'],mode);sums={key:0 for key in METRICS};sums['time_ns']=planner.preprocess_ns;sums['checks']=sums['persistent_checks']=planner.preprocess_checks;lengths=[]
     for i,q in enumerate(m['queries']):
      r=planner.query(q['start'],q['goal'],i);lengths.append(r['length'])
      if expected is not None:
       a,b=expected[i],r['length'];assert (math.isinf(a) and math.isinf(b)) or math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8),(m['workload_id'],mode,rep,i,a,b)
      assert r['checks']==r['persistent_checks']+r['terminal_checks']
      row={key:m[key] for key in ['workload_id','setup_id','source_map','corpus','family','regime']};row.update(repeat=rep,mode=mode,**{a:b for a,b in r.items() if a!='path'})
      if w is None:w=csv.DictWriter(f,fieldnames=list(row));w.writeheader()
      w.writerow(row)
      for key in METRICS:sums[key]+=r[key]
      if i+1 in (1,5,20,40) or(pilot and i+1==len(m['queries'])):
       row={key:m[key] for key in ['workload_id','setup_id','source_map','corpus','family','regime']};row.update(repeat=rep,mode=mode,horizon=i+1,**sums,completed=planner.complete,switch_request=planner.switch_request,initial_candidates=planner.initial_candidates,unknown=r['unknown'])
       if pw is None:pw=csv.DictWriter(g,fieldnames=list(row));pw.writeheader()
       pw.writerow(row)
      if rep==0:paths.write(json.dumps(dict(workload_id=m['workload_id'],mode=mode,index=i,length=r['length'],status=r['status'],path=r['path']),separators=(',',':'))+'\n')
     if expected is None:expected=lengths
   f.flush();g.flush();paths.flush();print(k+1,len(cases),m['workload_id'],round(time.perf_counter()-begin,2),flush=True)
 meta.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.perf_counter()-begin,all_lengths_agree=True)
 (out/'metadata.json').write_text(json.dumps(meta,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--repeats',type=int,default=3);p.add_argument('--pilot',action='store_true');a=p.parse_args();main(a.out,a.repeats,a.pilot)
