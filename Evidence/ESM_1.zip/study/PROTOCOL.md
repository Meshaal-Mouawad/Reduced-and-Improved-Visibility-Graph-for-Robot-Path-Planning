# Consolidated v5 protocol — frozen before the released measurement run

## Study status
The design follows the documented v3 experiment and subsequent implementation diagnosis. It is a controlled computational investigation, not a preregistered confirmatory trial. This released run consolidates the state-reuse, cost-signal, and endpoint-policy comparisons into one identically instrumented execution. Earlier transient measurements are not used as the data of this release. The original archived v3 evidence is preserved separately and is not pooled with these timings.

## Questions
1. What changes when lazy validation reuses distance labels within or across moving-endpoint requests?
2. Does completing persistent obstacle-edge validation have the same effect as also making new terminal connections eager?
3. How do count-based and measured-time completion signals behave across dispersed, localized and shifted query sequences?

## Frozen material
Forty generated point maps: four polygon families, 8/16 obstacles, seeds10–14. Twenty external point maps from the archived RVG release. Twelve fixed-orientation square configurations derived from rectangle/corridor maps, 8/16 obstacles, seeds10–12. The square half-side is min(0.005 span,0.2 minimum obstacle gap); inflated rectangle coordinates are stored at nine decimals. Physical and transformed polygons are archived. These are 72 configurations derived from60 source maps, not72 independent source environments.

Each configuration has three seeded40-request sequences: dispersed over a15%-padded sampling window; localized in a left central window; and a shift from the left to right window after20 requests. Sampling excludes strict-interior endpoints and pairs below prescribed separation only. The window is not a workspace boundary. Inputs are saved and hashed before planner outcomes are examined.

## Matched implementations
Fourteen modes: eager A*; fixed-initial-budget A*; and, for each of A*, query-local LPA*, persistent LPA*, permanent laziness, bundled count-based completion, persistent-only count-based completion, and measured-time bundled completion. All modes share Euclidean weights, tangent candidates, fixed-candidate adjacency with blocked weights at infinity, geometry, instrumented clocks, and forward path-edge selection. No original-author C++ performance claim is made.

LPA* follows optimized successor updates with full goal consistency termination. Persistent labels handle moving endpoints through incident-edge changes and re-keying of inconsistent vertices. Zero-length terminal/corner aliases are omitted. Invalid or identical endpoint requests reset query search labels but preserve persistent collision statuses.

Count rule: cumulative processed vertices in searches after the first candidate path per request >=4×unknown persistent edges. Fixed-budget A* uses the initial edge count. Measured-time rule replaces the left side by accumulated subsequent-search and edge-repair nanoseconds and the right by mean observed collision-check duration×unknown edges. The time rule is fixed without fitted coefficients and observes no future query.

Bundled completion validates persistent edges and makes every subsequent terminal candidate eager. Persistent-only completion validates the same persistent edges and keeps terminal validation lazy. Their count-triggered switch request must agree. Each newly checked terminal edge is charged once per request.

## Execution
216 workloads ×40 requests ×14 modes ×3 repetitions =362,880 timed policy-request executions on8,640 distinct request cases. Modes run serially in deterministically shuffled order. Include construction, terminal replacement, search repair, rekeying, completion, counting and instrumentation. Exclude input generation, serialization, analysis, oracle work and rendering. No CPU-heavy analysis is run concurrently with timing.

## Evidence and analysis
Every mode/repetition must match the common route length at relative1e-9/absolute1e-8 (or agree on failure). A separate exact-decimal integer checker constructs full visibility graphs without tangent pruning; Dijkstra supplies all8,640 reference lengths. Check all120,960 first-repetition routes and distinct segments; cross-check integer predicates against the archived Fraction implementation and analytic fixtures. Preserve all failures.

Use median of three cumulative runtimes per workload, then paired ratios. Geometry-cluster bootstrap uses5,000 resamples and preserves each source map's three regimes. Report generated40, external20 and finite12 strata separately. Triggered-only comparisons are descriptive within a paired algorithmic condition and are not substituted for all-workload effects. Do not treat repeated timings or derived finite configurations as new independent maps.

Verify the collision-count identity C_bundled−C_internal=sum(|terminal candidates|−|tested terminal subset|) after the common completion event for every paired engine/workload/repetition. This is a cost accounting identity, not a runtime or competitive guarantee.
