"""Independent full-visibility reference with exact decimal integer predicates.

No tangent filtering, planner visibility routine, LPA or A* is imported.
Integer predicates are additionally checked against the archived Fraction oracle.
"""
import json,gzip,heapq,math,random,decimal,time
from pathlib import Path
from collections import defaultdict
from independent_oracle import point as qpoint, visible_exact as segment_free
H=Path(__file__).resolve().parent

def digits(x):return max(0,-decimal.Decimal(str(x)).as_tuple().exponent)
def intval(x,p):
 t=decimal.Decimal(str(x)).as_tuple();v=0
 for d in t.digits:v=v*10+d
 return (-v if t.sign else v)*10**(t.exponent+p)
def orient(a,b,c):return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def loc(x,y,d,poly):
 w=0
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ax,ay=a[0]*d,a[1]*d;bx,by=b[0]*d,b[1]*d
  det=(b[0]-a[0])*(y-ay)-(b[1]-a[1])*(x-ax)
  if det==0 and min(ax,bx)<=x<=max(ax,bx) and min(ay,by)<=y<=max(ay,by):return 0
  if ay<=y<by and det>0:w+=1
  elif by<=y<ay and det<0:w-=1
 return 1 if w else -1

class Exact:
 def __init__(self,obs,allpoints):
  self.precision=max(digits(v) for p in allpoints for v in p);self.scale=10**self.precision
  self.obstacles=[tuple(self.p(p) for p in po) for po in obs]
  self.bounds=[(min(p[0] for p in po),min(p[1] for p in po),max(p[0] for p in po),max(p[1] for p in po)) for po in self.obstacles]
 def p(self,p):return tuple(intval(x,self.precision) for x in p)
 def visible(self,a,b):
  lo0,hi0=sorted((a[0],b[0]));lo1,hi1=sorted((a[1],b[1]));dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy
  for po,bb in zip(self.obstacles,self.bounds):
   if hi0<bb[0] or lo0>bb[2] or hi1<bb[1] or lo1>bb[3]:continue
   if loc(a[0],a[1],1,po)>0 or loc(b[0],b[1],1,po)>0:return False
   if den==0:continue
   cuts={0,den}
   for u,v in zip(po,po[1:]+po[:1]):
    o1,o2=orient(a,b,u),orient(a,b,v)
    if ((o1>0 and o2<0)or(o1<0 and o2>0)):
     o3,o4=orient(u,v,a),orient(u,v,b)
     if (o3>0 and o4<0)or(o3<0 and o4>0):return False
    if o1==0:
     dot=(u[0]-a[0])*dx+(u[1]-a[1])*dy
     if 0<dot<den:cuts.add(dot)
   if len(cuts)==2:
    if loc(a[0]+b[0],a[1]+b[1],2,po)>0:return False
   else:
    ordered=sorted(cuts);d=2*den
    for lo,hi in zip(ordered,ordered[1:]):
     m=lo+hi
     if loc(a[0]*d+m*dx,a[1]*d+m*dy,d,po)>0:return False
  return True

def dijkstra(adj,s,t):
 ds=[math.inf]*len(adj);ds[s]=0.;heap=[(0.,s)]
 while heap:
  z,u=heapq.heappop(heap)
  if z!=ds[u]:continue
  if u==t:return z
  for v,w in adj[u]:
   alt=z+w
   if alt<ds[v]:ds[v]=alt;heapq.heappush(heap,(alt,v))
 return math.inf

def main(results):
 import csv
 results=Path(results);cases=json.loads((H/'inputs.json').read_text());bysetup=defaultdict(list)
 for m in cases:bysetup[m['setup_id']].append(m)
 paths=defaultdict(list)
 with gzip.open(results/'paths.jsonl.gz','rt') as f:
  for line in f:
   r=json.loads(line);paths[r['workload_id']].append(r)
 stats=dict(reference_queries=0,verified_routes=0,distinct_verified_segments=0,fraction_crosschecks=0,analytic_fixtures=0,errors=[])
 output=[];begin=time.perf_counter()
 for ix,(sid,ms) in enumerate(bysetup.items()):
  obs=ms[0]['obstacles'];points=[p for po in obs for p in po];terminals=[p for m in ms for q in m['queries'] for p in(q['start'],q['goal'])]
  ex=Exact(obs,points+terminals);ips=[ex.p(p) for p in points];n=len(points);base=[[] for _ in points]
  for i in range(n):
   for j in range(i+1,n):
    if ex.visible(ips[i],ips[j]):
     w=math.dist(points[i],points[j]);base[i].append((j,w));base[j].append((i,w))
  unique={};rng=random.Random(20261104+ix)
  for m in ms:
   refs=[]
   for k,q in enumerate(m['queries']):
    s,t=q['start'],q['goal'];a,b=ex.p(s),ex.p(t);adj=[v.copy() for v in base]+[[],[]]
    for i,p in enumerate(ips):
     for node,end,raw in((n,a,s),(n+1,b,t)):
      if ex.visible(p,end):w=math.dist(points[i],raw);adj[i].append((node,w));adj[node].append((i,w))
    if ex.visible(a,b):w=math.dist(s,t);adj[n].append((n+1,w));adj[n+1].append((n,w))
    value=dijkstra(adj,n,n+1);refs.append(value);stats['reference_queries']+=1
    output.append(dict(workload_id=m['workload_id'],index=k,length=value))
   for r in paths[m['workload_id']]:
    a,b=refs[r['index']],r['length']
    if not((math.isinf(a)and math.isinf(b))or math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8)):stats['errors'].append(dict(kind='reference_length',**r,reference=a))
    route=r['path'];q=m['queries'][r['index']]
    if math.isfinite(a) and not route:stats['errors'].append(dict(kind='missing_feasible_route',**r))
    if math.isinf(a) and route:stats['errors'].append(dict(kind='route_for_unreachable_query',**r))
    if route:
     if tuple(route[0])!=tuple(q['start']) or tuple(route[-1])!=tuple(q['goal']):stats['errors'].append(dict(kind='endpoints',**r))
     length=sum(math.dist(a,b) for a,b in zip(route,route[1:]))
     if not math.isclose(length,r['length'],rel_tol=1e-9,abs_tol=1e-8):stats['errors'].append(dict(kind='reported_length',**r))
    for a,b in zip(route,route[1:]):unique[tuple(sorted((tuple(a),tuple(b))))]=(a,b)
    stats['verified_routes']+=1
  for a,b in unique.values():
   if not ex.visible(ex.p(a),ex.p(b)):stats['errors'].append(dict(kind='invalid_segment',setup_id=sid,a=a,b=b))
  stats['distinct_verified_segments']+=len(unique)
  rational=[tuple(qpoint(p)for p in po) for po in obs];allpoints=points+terminals
  pairs=[rng.sample(allpoints,2) for _ in range(12)]+rng.sample(list(unique.values()),min(8,len(unique)))
  for a,b in pairs:
   x=ex.visible(ex.p(a),ex.p(b));y=segment_free(qpoint(a),qpoint(b),rational)
   if x!=y:stats['errors'].append(dict(kind='fraction_disagreement',setup_id=sid,a=a,b=b,integer=x,fraction=y))
   stats['fraction_crosschecks']+=1
  print(ix+1,len(bysetup),sid,stats['verified_routes'],round(time.perf_counter()-begin,2),flush=True)
 for d,_,expected in verification_fixtures():
  allpts=[p for po in d['obstacles'] for p in po]+[d['start'],d['goal']];ex=Exact(d['obstacles'],allpts)
  for a in allpts:
   for b in allpts:
    assert ex.visible(ex.p(a),ex.p(b))==segment_free(qpoint(a),qpoint(b),[tuple(qpoint(p) for p in po) for po in d['obstacles']])
  stats['analytic_fixtures']+=1
 stats['passed']=not stats['errors'];stats['duration_seconds']=time.perf_counter()-begin
 (results/'exact_verification.json').write_text(json.dumps(stats,indent=2))
 with(results/'reference_lengths.csv').open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=['workload_id','index','length']);w.writeheader();w.writerows(output)
 print(json.dumps(stats,indent=2))

def verification_fixtures():
 r=[[[0,0],[1,0],[1,1],[0,1]]]
 return [({'obstacles':[],'start':[-1,0],'goal':[1,0]},None,2.),({'obstacles':r,'start':[-1,0],'goal':[2,0]},None,3.),({'obstacles':r,'start':[-1,.5],'goal':[2,.5]},None,1+2*(1.25**.5)),({'obstacles':r,'start':[-1,-1],'goal':[-1,2]},None,3.),({'obstacles':r,'start':[2,2],'goal':[2,2]},None,0.),({'obstacles':r,'start':[.5,.5],'goal':[2,2]},None,float('inf')),({'obstacles':r,'start':[0,0],'goal':[2,0]},None,2.),({'obstacles':r,'start':[2,-1],'goal':[2,2]},None,3.)]

if __name__=='__main__':
 import sys
 main(sys.argv[1] if len(sys.argv)>1 else H/'results')
