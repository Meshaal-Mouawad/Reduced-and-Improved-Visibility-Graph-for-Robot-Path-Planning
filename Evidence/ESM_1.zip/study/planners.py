"""Controlled planning variants separating persistent and terminal validation.

Independent implementation of optimized LPA* updates (Koenig et al., 2004)
and a shortest-path-event, forward lazy selector (Lim et al., 2024). It is not
the original authors' OMPL implementation. All modes share geometry, graph
storage, timing instrumentation and the Euclidean objective.
"""
from dataclasses import dataclass,field
import heapq,math,time
import planner_core as geo
INF=math.inf
@dataclass
class Counts:
    pops:int=0
    scans:int=0
    updates:int=0
    pushes:int=0
    search_times:list=field(default_factory=list)
    edge_repair_ns:int=0
    terminal_repair_ns:int=0

def astar(points,adj,s,t,c):
    begin=time.perf_counter_ns();ds=[INF]*len(points);parents=[-1]*len(points);ds[s]=0.
    h=[math.dist(p,points[t]) for p in points];heap=[(h[s],0.,s)];c.pushes+=1
    while heap:
        _,d,u=heapq.heappop(heap)
        if d!=ds[u]:continue
        c.pops+=1
        if u==t:
            route=[]
            while u!=-1:route.append(u);u=parents[u]
            c.search_times.append(time.perf_counter_ns()-begin);return d,route[::-1]
        for v,w in adj[u].items():
            c.scans+=1;alt=d+w
            if alt<ds[v]:
                ds[v],parents[v]=alt,u;heapq.heappush(heap,(alt+h[v],alt,v));c.pushes+=1
    c.search_times.append(time.perf_counter_ns()-begin);return INF,[]

class LPA:
    def __init__(self,points,adj,s,t,c):
        self.points,self.adj,self.s,self.t,self.c=points,adj,s,t,c
        self.g=[INF]*len(points);self.rhs=[INF]*len(points);self.parent=[-1]*len(points)
        self.versions=[0]*len(points);self.heap=[];self.h=[math.dist(p,points[t]) for p in points]
        self.rhs[s]=0.;self.enqueue(s)
    def key(self,u):
        z=min(self.g[u],self.rhs[u]);return z+self.h[u],z,u
    def enqueue(self,u):
        self.versions[u]+=1
        if self.g[u]!=self.rhs[u]:heapq.heappush(self.heap,(*self.key(u),self.versions[u]));self.c.pushes+=1
    def recompute(self,u):
        self.c.updates+=1
        if u!=self.s:
            best,parent=INF,-1
            for v,w in self.adj[u].items():
                self.c.scans+=1;z=self.g[v]+w
                if z<best or(z==best and z<INF and v<parent):best,parent=z,v
            self.rhs[u],self.parent[u]=best,parent
        self.enqueue(u)
    def changes(self,vertices,new_query=False):
        begin=time.perf_counter_ns()
        if new_query:self.h=[math.dist(p,self.points[self.t]) for p in self.points];self.heap=[]
        for u in sorted(set(vertices)):self.recompute(u)
        if new_query:
            self.heap=[]
            for u in range(len(self.points)):
                if self.g[u]!=self.rhs[u]:self.enqueue(u)
        if new_query:self.c.terminal_repair_ns+=time.perf_counter_ns()-begin
        else:self.c.edge_repair_ns+=time.perf_counter_ns()-begin
    def clean(self):
        while self.heap:
            a,b,u,v=self.heap[0]
            if v==self.versions[u] and self.g[u]!=self.rhs[u]:return a,b,u
            heapq.heappop(self.heap)
        return INF,INF,-1
    def shortest(self):
        begin=time.perf_counter_ns()
        while self.clean()[:2]<self.key(self.t)[:2] or self.rhs[self.t]!=self.g[self.t]:
            if not self.heap:raise RuntimeError('Inconsistent goal with empty LPA queue')
            _,_,u,_=heapq.heappop(self.heap);self.versions[u]+=1;self.c.pops+=1
            if self.g[u]>self.rhs[u]:
                self.g[u]=self.rhs[u]
                for v,w in self.adj[u].items():
                    self.c.scans+=1
                    if v!=self.s and self.g[u]+w<self.rhs[v]:
                        self.rhs[v],self.parent[v]=self.g[u]+w,u;self.enqueue(v)
            else:
                self.g[u]=INF
                for v in list(self.adj[u])+[u]:
                    self.c.scans+=1
                    if v!=self.s and self.parent[v]==u:self.recompute(v)
                self.enqueue(u)
        if self.g[self.t]==INF:
            self.c.search_times.append(time.perf_counter_ns()-begin);return INF,[]
        route=[];seen=set();u=self.t
        while u!=self.s:
            if u<0 or u in seen:raise RuntimeError(('Invalid LPA parent chain',u,route))
            seen.add(u);route.append(u);u=self.parent[u]
        route.append(self.s);route.reverse();length=sum(self.adj[u][v] for u,v in zip(route,route[1:]))
        if not math.isclose(length,self.g[self.t],rel_tol=1e-9,abs_tol=1e-8):raise RuntimeError('LPA path and value disagree')
        self.c.search_times.append(time.perf_counter_ns()-begin);return length,route

MODES={'eager':('astar','eager',True),'fixed_astar':('astar','fixed',True)}
for engine in ('astar','lpa_query','lpa_persistent'):
    MODES['lazy_'+engine]=(engine,'lazy',False)
    MODES['bundled_'+engine]=(engine,'count',True)
    MODES['internal_'+engine]=(engine,'count',False)
    MODES['timed_'+engine]=(engine,'time',True)

class Planner:
    def __init__(self,obstacles,mode,alpha=4.):
        begin=time.perf_counter_ns();self.mode=mode
        self.engine_name,self.schedule,self.eager_terminals=MODES[mode]
        self.alpha=alpha;self.geom=geo.Geometry(obstacles)
        self.check_ns=0;self.num_timed_checks=0
        original=self.geom.visible
        def timed_visible(a,b):
            t=time.perf_counter_ns();result=original(a,b)
            self.check_ns+=time.perf_counter_ns()-t;self.num_timed_checks+=1;return result
        self.geom.visible=timed_visible
        self.points=[];self.neighbors=[]
        for po in self.geom.polys:
            for i,p in enumerate(po):self.points.append(p);self.neighbors.append((po[i-1],po[(i+1)%len(po)]))
        self.n=len(self.points);self.s,self.t=self.n,self.n+1;self.points += [(0.,0.),(0.,0.)]
        self.adj=[{} for _ in self.points];self.known={}
        for i in range(self.n):
            for j in range(i+1,self.n):
                p,q=self.points[i],self.points[j]
                if geo.tangent(p,q,self.neighbors[i]) and geo.tangent(q,p,self.neighbors[j]):
                    state=self.geom.visible(p,q) if self.schedule=='eager' else None
                    self.known[(i,j)]=state;self.adj[i][j]=self.adj[j][i]=math.dist(p,q) if state is not False else INF
        self.initial_candidates=len(self.known);self.complete=self.schedule=='eager';self.pending=False
        self.switch_request=None;self.accum_extra_pops=0;self.accum_extra_ns=0
        self.engine=None;self.previous_terminals=[];self.c=Counts()
        self.preprocess_ns=time.perf_counter_ns()-begin;self.preprocess_checks=self.geom.checks
    def query(self,start,goal,index):
        begin=time.perf_counter_ns();check_before=self.geom.checks;check_ns_before=self.check_ns
        self.c=Counts();affected=set();pc=tc=completion_checks=completion_ns=0
        if self.pending and not self.complete:
            tick=time.perf_counter_ns()
            for (i,j),state in self.known.items():
                if state is None:
                    state=self.geom.visible(self.points[i],self.points[j]);self.known[(i,j)]=state;completion_checks+=1
                    if not state:self.adj[i][j]=self.adj[j][i]=INF;affected.update((i,j))
            self.complete=True;self.switch_request=index+1;completion_ns=time.perf_counter_ns()-tick
        for i,j in self.previous_terminals:
            del self.adj[i][j];del self.adj[j][i];affected.update((i,j))
        self.previous_terminals=[];self.points[self.s],self.points[self.t]=tuple(start),tuple(goal)
        invalid=any(geo.inside(p,po) for p in (start,goal) for po in self.geom.polys)
        if invalid or tuple(start)==tuple(goal):
            self.engine=None;length=INF if invalid else 0.;route=[] if invalid else [self.s];calls=extra_pops=0
            status='invalid_endpoint' if invalid else 'success'
        else:
            terminal_known={};fully_eager=self.complete and self.eager_terminals
            for i in (self.s,self.t):
                for j in range(i):
                    p,q=self.points[i],self.points[j]
                    # A corner-coincident terminal does not need a zero-length alias.
                    if p==q:continue
                    if j<self.n and not geo.tangent(q,p,self.neighbors[j]):continue
                    state=self.geom.visible(p,q) if fully_eager else None
                    if state is not None:tc+=1
                    terminal_known[(j,i)]=state;self.adj[i][j]=self.adj[j][i]=math.dist(p,q) if state is not False else INF
                    self.previous_terminals.append((j,i));affected.update((i,j))
            if self.engine_name!='astar':
                if self.engine is None or self.engine_name=='lpa_query':self.engine=LPA(self.points,self.adj,self.s,self.t,self.c)
                else:self.engine.c=self.c;self.engine.changes(affected,new_query=True)
            calls=extra_pops=0
            while True:
                before=self.c.pops
                length,route=astar(self.points,self.adj,self.s,self.t,self.c) if self.engine_name=='astar' else self.engine.shortest()
                if calls:extra_pops+=self.c.pops-before
                calls+=1
                if not route or fully_eager:break
                invalid_edge=False
                for a,b in zip(route,route[1:]):
                    key=min(a,b),max(a,b);states=self.known if key[1]<self.n else terminal_known
                    if states[key] is None:
                        states[key]=self.geom.visible(self.points[a],self.points[b])
                        if key[1]<self.n:pc+=1
                        else:tc+=1
                    if states[key] is False:
                        self.adj[a][b]=self.adj[b][a]=INF
                        if self.engine_name!='astar':self.engine.changes((a,b))
                        invalid_edge=True;break
                if not invalid_edge:break
            status='success' if route else 'disconnected'
        extra_ns=sum(self.c.search_times[1:])+self.c.edge_repair_ns
        self.accum_extra_pops+=extra_pops;self.accum_extra_ns+=extra_ns
        unknown=sum(state is None for state in self.known.values())
        predicted_ns=(self.check_ns/self.num_timed_checks if self.num_timed_checks else 0)*unknown
        if not self.complete and unknown:
            if self.schedule in ('count','fixed') and self.accum_extra_pops>=self.alpha*(self.initial_candidates if self.schedule=='fixed' else unknown):self.pending=True
            elif self.schedule=='time' and self.num_timed_checks and self.accum_extra_ns>=predicted_ns:self.pending=True
        return dict(index=index,time_ns=time.perf_counter_ns()-begin,checks=self.geom.checks-check_before,
            length=length,path=[self.points[u] for u in route],status=status,pops=self.c.pops,scans=self.c.scans,
            rhs_updates=self.c.updates,pushes=self.c.pushes,search_calls=calls,extra_pops=extra_pops,
            unknown=unknown,complete=self.complete,switch_request=self.switch_request,
            completion_checks=completion_checks,completion_ns=completion_ns,persistent_checks=pc+completion_checks,
            terminal_checks=tc,terminal_candidates=len(self.previous_terminals),check_time_ns=self.check_ns-check_ns_before,
            search_time_ns=sum(self.c.search_times),extra_search_ns=extra_ns,edge_repair_ns=self.c.edge_repair_ns,
            terminal_repair_ns=self.c.terminal_repair_ns,predicted_completion_ns=predicted_ns)
