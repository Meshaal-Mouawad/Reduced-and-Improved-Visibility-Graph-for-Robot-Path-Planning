"""Resume only missing execution stages; preserve earlier files and logs."""
import json,subprocess,sys,traceback,time,shutil
from pathlib import Path
H=Path(__file__).resolve().parent
STATUS=H/'PIPELINE_STATUS.json'
def read(p):
 try:return json.loads(p.read_text())
 except Exception:return {}
def run(script,args,log):
 with (H/log).open('w') as f:
  p=subprocess.run([sys.executable,script,*args],cwd=H,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{script}: exit {p.returncode}; see {log}')
status={}
try:
 # Avoid guessing an archived helper's signature: use explicit analytic fixtures.
 fixture='''\ndef verification_fixtures():\n r=[[[0,0],[1,0],[1,1],[0,1]]]\n return [({'obstacles':[],'start':[-1,0],'goal':[1,0]},None,2.),({'obstacles':r,'start':[-1,0],'goal':[2,0]},None,3.),({'obstacles':r,'start':[-1,.5],'goal':[2,.5]},None,1+2*(1.25**.5)),({'obstacles':r,'start':[-1,-1],'goal':[-1,2]},None,3.),({'obstacles':r,'start':[2,2],'goal':[2,2]},None,0.),({'obstacles':r,'start':[.5,.5],'goal':[2,2]},None,float('inf')),({'obstacles':r,'start':[0,0],'goal':[2,0]},None,2.),({'obstacles':r,'start':[2,-1],'goal':[2,2]},None,3.)]\n'''
 for name in ('test_planners.py','exact_verify.py'):
  p=H/name;s=p.read_text()
  if 'def verification_fixtures' not in s:
   s=s.replace('for d,_,expected in analytic_fixtures():','for d,_,expected in verification_fixtures():')
   # Put fixture definitions before execution; originals remain in baseline archive.
   s=s.replace("if __name__=='__main__':",fixture+"\nif __name__=='__main__':")
   p.write_text(s)
 # Only install an absent helper; do not alter a completed measured algorithm.
 import planner_core
 if not hasattr(planner_core,'inside'):
  p=H/'planners.py';s=p.read_text()
  old="invalid=any(geo.inside(p,po) for p in (start,goal) for po in self.geom.polys)"
  new="from shapely.geometry import Polygon,Point\n        invalid=any(Polygon(po).contains(Point(p)) for p in (start,goal) for po in self.geom.polys)"
  assert old in s or new in s
  if old in s:p.write_text(s.replace(old,new))
 if not read(H/'implementation_tests.json').get('passed'):run('test_planners.py',[],'test_final.log')
 status['implementation_tests']=read(H/'implementation_tests.json')
 metadata=read(H/'results/metadata.json')
 if not metadata.get('completed_utc'):
  if (H/'results').exists():
   destination=H/f'interrupted_results_{int(time.time())}';(H/'results').rename(destination)
  run('run_study.py',['--out','results','--repeats','3'],'consolidated_final.log')
 status['measurement']=read(H/'results/metadata.json')
 if not read(H/'results/exact_verification.json').get('passed'):run('exact_verify.py',['results'],'exact_final.log')
 status['geometry']=read(H/'results/exact_verification.json')
 if not status['geometry'].get('passed'):raise RuntimeError('Independent geometry/reference errors remain; no submission-ready claim is authorized.')
 run('analyze.py',[],'analysis_final.log')
 status['analysis']=read(H/'analysis/analysis_manifest.json');status['status']='COMPUTATIONAL_CHECKS_PASSED'
except Exception as e:
 status['status']='BLOCKED';status['exception']=str(e);status['traceback']=traceback.format_exc()
finally:
 STATUS.write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))
