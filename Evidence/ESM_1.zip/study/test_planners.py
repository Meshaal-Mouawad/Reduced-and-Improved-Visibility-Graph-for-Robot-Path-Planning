import random,math,heapq,json
from pathlib import Path
from planners import Planner,MODES,LPA,Counts,INF
from independent_oracle import analytic_fixtures

def eq(a,b):assert (math.isinf(a) and math.isinf(b)) or math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8),(a,b)
def dijkstra(adj,s,t):
 d={s:0.};q=[(0.,s)]
 while q:
  z,u=heapq.heappop(q)
  if z!=d[u]:continue
  if u==t:return z
  for v,w in adj[u].items():
   if z+w<d.get(v,INF):d[v]=z+w;heapq.heappush(q,(d[v],v))
 return INF

def main():
 dynamic=fixtures=moving=exceptions=0
 for seed in range(30):
  rng=random.Random(seed);pts=[(rng.random()*50,rng.random()*50) for _ in range(24)];adj=[{} for _ in pts]
  for u in range(24):
   for v in range(u+1,24):
    if rng.random()<.18:adj[u][v]=adj[v][u]=math.dist(pts[u],pts[v])*(1+rng.random())
  l=LPA(pts,adj,0,23,Counts())
  for _ in range(60):
   eq(l.shortest()[0],dijkstra(adj,0,23));dynamic+=1;changed=set()
   for j in range(4):
    u,v=rng.sample(range(24),2);w=math.dist(pts[u],pts[v])*(1+rng.random()) if rng.random()<.7 else INF
    adj[u][v]=adj[v][u]=w;changed.update((u,v))
   l.changes(changed)
 for d,_,expected in verification_fixtures():
  for mode in MODES:
   r=Planner(d['obstacles'],mode).query(d['start'],d['goal'],0);eq(r['length'],expected)
   assert r['checks']==r['persistent_checks']+r['terminal_checks'];fixtures+=1
 for seed in range(12):
  rng=random.Random(1500+seed);obs=[[[x,y],[x+8,y],[x+8,y+8],[x,y+8]] for x in (10,30,50) for y in (10,30)]
  ps={m:Planner(obs,m) for m in MODES}
  for i in range(25):
   s=[rng.uniform(0,65),rng.uniform(45,55)];t=[rng.uniform(0,65),rng.uniform(-10,-2)];expected=ps['eager'].query(s,t,i)['length']
   for m,p in ps.items():
    if m!='eager':eq(p.query(s,t,i)['length'],expected);moving+=1
 obs=[[[0,0],[1,0],[1,1],[0,1]]];qs=[([-1,.5],[2,.5]),([.5,.5],[2,2]),([2,2],[2,2]),([-2,0],[2,0])]
 for mode in MODES:
  p=Planner(obs,mode)
  for i,(s,t) in enumerate(qs):eq(p.query(s,t,i)['length'],Planner(obs,'eager').query(s,t,i)['length']);exceptions+=1
 out=dict(dynamic_graph_checks=dynamic,analytic_mode_checks=fixtures,moving_endpoint_comparisons=moving,exception_sequence_checks=exceptions,passed=True)
 Path(__file__).with_name('implementation_tests.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

def verification_fixtures():
 r=[[[0,0],[1,0],[1,1],[0,1]]]
 return [({'obstacles':[],'start':[-1,0],'goal':[1,0]},None,2.),({'obstacles':r,'start':[-1,0],'goal':[2,0]},None,3.),({'obstacles':r,'start':[-1,.5],'goal':[2,.5]},None,1+2*(1.25**.5)),({'obstacles':r,'start':[-1,-1],'goal':[-1,2]},None,3.),({'obstacles':r,'start':[2,2],'goal':[2,2]},None,0.),({'obstacles':r,'start':[.5,.5],'goal':[2,2]},None,float('inf')),({'obstacles':r,'start':[0,0],'goal':[2,0]},None,2.),({'obstacles':r,'start':[2,-1],'goal':[2,2]},None,3.)]

if __name__=='__main__':main()
