"""Independent exact-rational geometry and weighted Dijkstra reference.
Boundary contact is allowed; all strict polygon interiors are forbidden.
Geometry uses Fraction, while Euclidean path costs use double precision.
No code from the planner under evaluation is imported.
"""
from fractions import Fraction as F
import heapq
import math

def point(p): return tuple(F(str(x)) for x in p)
def polygons(obs): return tuple(tuple(point(p) for p in po) for po in obs)
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def cross(a,b): return a[0]*b[1]-a[1]*b[0]
def orient(a,b,c): return cross(sub(b,a),sub(c,a))
def edges(po): return zip(po,po[1:]+po[:1])
def on_segment(p,a,b):
    return orient(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def location(p,po):
    winding=0
    for a,b in edges(po):
        if on_segment(p,a,b):return 0
        if a[1]<=p[1]<b[1] and orient(a,b,p)>0:winding+=1
        elif b[1]<=p[1]<a[1] and orient(a,b,p)<0:winding-=1
    return 1 if winding else -1
def at(a,b,t):return (a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]))
def intersection_parameters(a,b,u,v):
    r,s=sub(b,a),sub(v,u)
    if r==(0,0):return [F(0)] if on_segment(a,u,v) else []
    delta=sub(u,a);den=cross(r,s)
    if den:
        t,q=cross(delta,s)/den,cross(delta,r)/den
        return [t] if 0<=t<=1 and 0<=q<=1 else []
    if cross(delta,r):return []
    axis=0 if r[0] else 1
    t0=(u[axis]-a[axis])/r[axis];t1=(v[axis]-a[axis])/r[axis]
    lo=max(F(0),min(t0,t1));hi=min(F(1),max(t0,t1))
    return [] if lo>hi else [lo,hi]
def visible_exact(a,b,obs):
    for po in obs:
        # This broad-phase bound is exact and independent of planner code.
        if max(a[0],b[0])<min(p[0] for p in po) or min(a[0],b[0])>max(p[0] for p in po) or max(a[1],b[1])<min(p[1] for p in po) or min(a[1],b[1])>max(p[1] for p in po):continue
        if location(a,po)==1 or location(b,po)==1:return False
        if a==b:continue
        cuts={F(0),F(1)}
        for u,v in edges(po):cuts.update(intersection_parameters(a,b,u,v))
        ts=sorted(cuts)
        for lo,hi in zip(ts,ts[1:]):
            if lo<hi and location(at(a,b,(lo+hi)/2),po)==1:return False
    return True
def visible(a,b,obs):return visible_exact(point(a),point(b),polygons(obs))
def valid_path(data,path):
    if not path:return False
    pts=[point(p) for p in path];obs=polygons(data['obstacles'])
    if pts[0]!=point(data['start']) or pts[-1]!=point(data['goal']):return False
    if any(location(p,po)==1 for p in pts for po in obs):return False
    return all(visible_exact(a,b,obs) for a,b in zip(pts,pts[1:]))
def reference(data):
    obs=polygons(data['obstacles']);s=point(data['start']);g=point(data['goal'])
    if any(location(p,po)==1 for p in (s,g) for po in obs):return {'length':math.inf,'path':[]}
    pts=list(dict.fromkeys([s,g]+[p for po in obs for p in po]));adj=[[] for p in pts]
    target=pts.index(g)
    for i,a in enumerate(pts):
        for j in range(i+1,len(pts)):
            if visible_exact(a,pts[j],obs):
                w=math.dist(a,pts[j]);adj[i].append((j,w));adj[j].append((i,w))
    ds=[math.inf]*len(pts);ds[0]=0;parent=[-1]*len(pts);heap=[(0.,0)]
    while heap:
        d,u=heapq.heappop(heap)
        if d!=ds[u]:continue
        if u==target:break
        for v,w in adj[u]:
            if d+w<ds[v]:ds[v]=d+w;parent[v]=u;heapq.heappush(heap,(ds[v],v))
    route=[];u=target
    if math.isfinite(ds[u]):
        while u!=-1:route.append([str(x) for x in pts[u]]);u=parent[u]
    return {'length':ds[target],'path':route[::-1],'nodes':len(pts),'edges':sum(map(len,adj))//2}
def analytic_fixtures():
    sq=[[0,0],[1,0],[1,1],[0,1]];L=[[0,0],[3,0],[3,1],[1,1],[1,3],[0,3]]
    cases=[('direct',[],[0,0],[2,3],True,math.sqrt(13)),('boundary',[sq],[0,0],[1,0],True,1),('diagonal',[sq],[0,0],[1,1],False,2),('vertex_passage',[sq],[-1,-1],[2,2],False,2*math.sqrt(5)),('collinear',[sq],[-1,0],[2,0],True,3),('concave_notch',[L],[1,3],[3,1],True,math.sqrt(8)),('inside_start',[sq],[.5,.5],[2,2],False,math.inf),('detour',[sq],[-1,.5],[2,.5],False,1+math.sqrt(5))]
    return [(dict(id=i,obstacles=o,start=s,goal=g),v,d) for i,o,s,g,v,d in cases]
def self_test():
    out=[]
    for m,v,d in analytic_fixtures():
        assert visible(m['start'],m['goal'],m['obstacles'])==v,m['id']
        r=reference(m)
        assert (math.isinf(r['length']) and math.isinf(d)) or math.isclose(r['length'],d,rel_tol=1e-12), (m,r,d)
        if r['path']:assert valid_path(m,r['path'])
        out.append({'id':m['id'],'passed':True})
    return out
if __name__=='__main__':
    import json
    print(json.dumps(self_test(),indent=2))
