"""Paired analysis with source-map clustered intervals; no result selection."""
import json,math
from pathlib import Path
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;R=H/'results';A=H/'analysis';A.mkdir(exist_ok=True)
rng=np.random.default_rng(20261104)
p=pd.read_csv(R/'prefixes.csv');q=pd.read_csv(R/'queries.csv')
keys=['workload_id','setup_id','source_map','corpus','family','regime','mode','horizon']
med=p.groupby(keys,as_index=False).median(numeric_only=True);med.to_csv(A/'workload_medians.csv',index=False)
contrasts=[('lazy_lpa_query','lazy_astar','Within-query repair'),('lazy_lpa_persistent','lazy_lpa_query','Cross-query reuse'),('eager','lazy_astar','Eager construction'),('bundled_astar','lazy_astar','Bundled A* completion'),('internal_astar','lazy_astar','Persistent-only A* completion'),('fixed_astar','lazy_astar','Initial-budget A* completion')]
for engine in ('astar','lpa_query','lpa_persistent'):
 contrasts.extend([('internal_'+engine,'bundled_'+engine,'Endpoint ablation'),('timed_'+engine,'lazy_'+engine,'Measured-time completion'),('bundled_'+engine,'lazy_'+engine,'Count completion')])
ratios=[];summaries=[]
for num,den,label in contrasts:
 for horizon in (1,5,20,40):
  a=med[(med['mode']==num)&(med.horizon==horizon)];b=med[(med['mode']==den)&(med.horizon==horizon)]
  d=a.merge(b,on=['workload_id','setup_id','source_map','corpus','family','regime','horizon'],suffixes=('_n','_d'),validate='one_to_one')
  for metric in ('time_ns','checks','pops','scans','search_calls'):
   d['ratio']=d[metric+'_n']/d[metric+'_d'];assert np.isfinite(d.ratio).all()
   for corpus,g in d.groupby('corpus'):
    groups=np.stack([z.ratio.to_numpy() for _,z in g.groupby('source_map',sort=True)])
    draws=rng.integers(len(groups),size=(5000,len(groups)));boot=np.median(groups[draws].reshape(5000,-1),axis=1)
    lo,hi=np.quantile(boot,[.025,.975])
    summaries.append(dict(numerator=num,denominator=den,comparison=label,horizon=horizon,metric=metric,corpus=corpus,workloads=len(g),source_maps=len(groups),median=float(g.ratio.median()),low=float(lo),high=float(hi),faster=int((g.ratio<1).sum())))
   if metric=='time_ns':
    for _,z in d.iterrows():ratios.append({**{k:z[k] for k in ['workload_id','setup_id','source_map','corpus','family','regime','horizon']},'numerator':num,'denominator':den,'ratio':z.ratio})
s=pd.DataFrame(summaries).drop_duplicates(['numerator','denominator','horizon','metric','corpus']);s.to_csv(A/'paired_summary.csv',index=False);pd.DataFrame(ratios).drop_duplicates().to_csv(A/'paired_workloads.csv',index=False)
final=p[p.horizon==40].copy();switches=[]
for (corpus,mode),g in final.groupby(['corpus','mode']):
 switches.append(dict(corpus=corpus,mode=mode,runs=len(g),completed_runs=int(g.switch_request.notna().sum()),workloads=g.workload_id.nunique(),triggered_workloads=g.loc[g.switch_request.notna(),'workload_id'].nunique()))
pd.DataFrame(switches).to_csv(A/'switch_counts.csv',index=False)
identities=[];triggered=[]
for engine in ('astar','lpa_query','lpa_persistent'):
 key=['workload_id','repeat','index']
 a=q[q['mode']=='bundled_'+engine];b=q[q['mode']=='internal_'+engine]
 d=a.merge(b,on=key,suffixes=('_b','_i'),validate='one_to_one')
 same_switch=(d.switch_request_b.fillna(-1)==d.switch_request_i.fillna(-1));same_persistent=d.persistent_checks_b==d.persistent_checks_i
 expected=np.where(d.complete_b,d.terminal_candidates_b-d.terminal_checks_i,0)
 actual=d.checks_b-d.checks_i
 identities.append(dict(engine=engine,request_pairs=len(d),same_switch=bool(same_switch.all()),same_persistent_checks=bool(same_persistent.all()),exact_identity=bool((expected==actual).all()),extra_bundled_checks=int(actual.sum())))
 # Define the paired condition by the deterministic count-based switch, before comparing time.
 a=med[(med['mode']=='internal_'+engine)&(med.horizon==40)];b=med[(med['mode']=='bundled_'+engine)&(med.horizon==40)];l=med[(med['mode']=='lazy_'+engine)&(med.horizon==40)][['workload_id','time_ns']].rename(columns={'time_ns':'lazy_ns'})
 d=a.merge(b,on=['workload_id','corpus','source_map','family','regime'],suffixes=('_i','_b'),validate='one_to_one').merge(l,on='workload_id',validate='one_to_one');d=d[d.switch_request_b.notna()].copy();d['ratio']=d.time_ns_i/d.time_ns_b;d['versus_lazy']=d.time_ns_i/d.lazy_ns;d['engine']=engine
 d.to_csv(A/f'triggered_{engine}.csv',index=False)
 for corpus,g in d.groupby('corpus'):
  triggered.append(dict(engine=engine,corpus=corpus,triggered_workloads=len(g),internal_over_bundled=float(g.ratio.median()),internal_faster=int((g.ratio<1).sum()),internal_over_lazy=float(g.versus_lazy.median()),internal_faster_than_lazy=int((g.versus_lazy<1).sum())))
 pd.DataFrame(d).to_csv(A/f'triggered_{engine}.csv',index=False)
pd.DataFrame(triggered).to_csv(A/'triggered_summary.csv',index=False)
(A/'accounting_identity.json').write_text(json.dumps(identities,indent=2));assert all(z['same_switch'] and z['same_persistent_checks'] and z['exact_identity'] for z in identities)
meta=json.loads((R/'metadata.json').read_text());counts=dict(configurations=72,source_maps=60,workloads=216,request_cases=8640,modes=14,repetitions=3,timed_executions=len(q),first_repetition_routes=len(q[q.repeat==0]),rows_by_status=q.status.value_counts().to_dict())
assert counts['timed_executions']==362880
(A/'analysis_manifest.json').write_text(json.dumps(dict(counts=counts,bootstrap_replicates=5000,cluster='source_map with all three query regimes',comparisons='paired medians of three cumulative runtimes; strata separate',elapsed_seconds=meta['duration_seconds']),indent=2))
print(json.dumps(counts,indent=2));print(pd.DataFrame(triggered).to_string(index=False));print(s[(s.metric=='time_ns')&(s.horizon==40)].to_string(index=False))
