import json,random,hashlib,datetime
from pathlib import Path
from shapely.geometry import Polygon,Point
H=Path(__file__).resolve().parent
B=H.parent/'baseline/03_Reproducibility/baseline/experiment/results_final/maps.json'
def queries(obs,seed,regime):
 rng=random.Random(seed);ps=[Polygon(p) for p in obs];assert all(p.is_valid for p in ps)
 xy=[p for po in obs for p in po];xmin,xmax=min(p[0] for p in xy),max(p[0] for p in xy);ymin,ymax=min(p[1] for p in xy),max(p[1] for p in xy)
 span=max(xmax-xmin,ymax-ymin);xmin-=.15*span;xmax+=.15*span;ymin-=.15*span;ymax+=.15*span
 def sample(r):
  for _ in range(100000):
   p=[round(rng.uniform(r[0],r[2]),6),round(rng.uniform(r[1],r[3]),6)]
   if not any(po.contains(Point(p)) for po in ps):return p
  raise RuntimeError('Sampling failed')
 out=[]
 for i in range(40):
  if regime=='dispersed':r=[xmin,ymin,xmax,ymax];minimum=.3*span
  else:
   l,u=(.1,.4) if regime=='localized' or i<20 else (.6,.9)
   r=[xmin+l*(xmax-xmin),ymin+.25*(ymax-ymin),xmin+u*(xmax-xmin),ymin+.75*(ymax-ymin)];minimum=.06*span
  for _ in range(100000):
   s,g=sample(r),sample(r)
   if ((s[0]-g[0])**2+(s[1]-g[1])**2)**.5>=minimum:break
  out.append(dict(start=s,goal=g))
 return out

def main():
 maps=json.loads(B.read_text());selected=[m for m in maps if m['seed'] is None or(m['n_obstacles'] in (8,16) and m['seed'] in range(10,15))];assert len(selected)==60
 setups=[dict(setup_id=m['id'],source_map=m['id'],family=m['family'],corpus='external' if m['seed'] is None else 'generated',robot='point',obstacles=m['obstacles'],half_side=0.) for m in selected]
 finite=[m for m in selected if m['family'] in ('rectangles','corridors') and m['seed'] in (10,11,12)];assert len(finite)==12
 for m in finite:
  ps=[Polygon(p) for p in m['obstacles']];gap=min(a.distance(b) for i,a in enumerate(ps) for b in ps[i+1:]);xy=[p for po in m['obstacles'] for p in po]
  span=max(max(p[k] for p in xy)-min(p[k] for p in xy) for k in (0,1));r=min(.005*span,.2*gap);assert r>0
  obs=[]
  for p in ps:
   x0,y0,x1,y1=p.bounds;assert abs(p.area-(x1-x0)*(y1-y0))<1e-8
   obs.append([[round(x0-r,9),round(y0-r,9)],[round(x1+r,9),round(y0-r,9)],[round(x1+r,9),round(y1+r,9)],[round(x0-r,9),round(y1+r,9)]])
  assert all(Polygon(a).disjoint(Polygon(b)) for i,a in enumerate(obs) for b in obs[i+1:])
  setups.append(dict(setup_id='square_'+m['id'],source_map=m['id'],family=m['family'],corpus='finite',robot='fixed_orientation_square',half_side=r,obstacles=obs,physical_obstacles=m['obstacles']))
 cases=[]
 for m in setups:
  for regime in ('dispersed','localized','shifted'):
   seed=int(hashlib.sha256((m['setup_id']+'|'+regime+'|20261104V5').encode()).hexdigest()[:16],16)
   cases.append(dict(**m,regime=regime,workload_id=m['setup_id']+'__'+regime,seed=seed,queries=queries(m['obstacles'],seed,regime)))
 p=H/'inputs.json';p.write_text(json.dumps(cases,separators=(',',':')))
 meta=dict(prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),configurations=72,source_geometries=60,workloads=216,query_cases=8640,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (H/'INPUT_MANIFEST.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
