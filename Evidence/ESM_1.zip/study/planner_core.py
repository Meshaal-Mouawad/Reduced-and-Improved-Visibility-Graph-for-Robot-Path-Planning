"""Controlled polygonal visibility-graph implementations.

Boundary contact is permitted; strict obstacle interiors are forbidden.
All planners share one map and Euclidean edge lengths. Lazy search follows
the forward edge selector of LazySP. No rendering is included in timers.
"""
import heapq
import math
import time
from collections import deque
import numpy as np

EPS = 1e-10

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def inside(p, poly):
    winding = 0
    for a,b in zip(poly, poly[1:]+poly[:1]):
        z = cross(a,b,p)
        if abs(z) <= EPS and min(a[0],b[0])-EPS <= p[0] <= max(a[0],b[0])+EPS and min(a[1],b[1])-EPS <= p[1] <= max(a[1],b[1])+EPS:
            return False
        if a[1] <= p[1] < b[1] and z > EPS: winding += 1
        if b[1] <= p[1] < a[1] and z < -EPS: winding -= 1
    return winding != 0

class Geometry:
    def __init__(self, obstacles):
        self.polys = [[tuple(map(float,p)) for p in poly] for poly in obstacles]
        self.bounds = [(min(p[0] for p in po),min(p[1] for p in po),max(p[0] for p in po),max(p[1] for p in po)) for po in self.polys]
        self.edges = [(a,b) for po in self.polys for a,b in zip(po,po[1:]+po[:1])]
        self.a = np.array([a for a,b in self.edges],dtype=float).reshape((-1,2))
        self.b = np.array([b for a,b in self.edges],dtype=float).reshape((-1,2))
        self.d = self.b-self.a
        self.checks = 0

    def visible(self,a,b):
        self.checks += 1
        if not self.polys: return True
        x0,y0 = a; x1,y1 = b; dx=x1-x0; dy=y1-y0
        if dx == 0 and dy == 0: return not any(inside(a,po) for po in self.polys)
        c1 = dx*(self.a[:,1]-y0)-dy*(self.a[:,0]-x0)
        c2 = dx*(self.b[:,1]-y0)-dy*(self.b[:,0]-x0)
        c3 = self.d[:,0]*(y0-self.a[:,1])-self.d[:,1]*(x0-self.a[:,0])
        c4 = self.d[:,0]*(y1-self.a[:,1])-self.d[:,1]*(x1-self.a[:,0])
        if np.any(((c1 > EPS)&(c2 < -EPS)|(c1 < -EPS)&(c2 > EPS)) & ((c3 > EPS)&(c4 < -EPS)|(c3 < -EPS)&(c4 > EPS))):
            return False
        xmin,xmax=min(x0,x1),max(x0,x1); ymin,ymax=min(y0,y1),max(y0,y1)
        denom = dx*dx+dy*dy
        for po,bb in zip(self.polys,self.bounds):
            if xmax < bb[0]-EPS or xmin > bb[2]+EPS or ymax < bb[1]-EPS or ymin > bb[3]+EPS: continue
            cuts=[0.,1.]
            for p in po:
                if abs(cross(a,b,p)) <= EPS:
                    t=((p[0]-x0)*dx+(p[1]-y0)*dy)/denom
                    if EPS < t < 1-EPS: cuts.append(t)
            cuts=sorted(set(cuts))
            for lo,hi in zip(cuts,cuts[1:]):
                t=(lo+hi)/2
                if inside((x0+t*dx,y0+t*dy),po): return False
        return True

def tangent(p,q,neighbors):
    if neighbors is None: return True
    u,v = neighbors
    a,b=cross(p,q,u),cross(p,q,v)
    return not ((a > EPS and b < -EPS) or (a < -EPS and b > EPS))

def astar(points,adj,start,goal,blocked=None,heuristic=True):
    n=len(points); ds=[math.inf]*n; parent=[-1]*n; ds[start]=0.
    h=lambda i: math.dist(points[i],points[goal]) if heuristic else 0.
    heap=[(h(start),0.,start)]; expanded=0
    while heap:
        _,d,u=heapq.heappop(heap)
        if d != ds[u]: continue
        expanded+=1
        if u==goal:
            path=[]
            while u!=-1: path.append(u);u=parent[u]
            return d,list(reversed(path)),expanded
        for v,w in adj[u]:
            key=(min(u,v),max(u,v))
            if blocked is not None and key in blocked: continue
            alt=d+w
            if alt < ds[v]-1e-12:
                ds[v]=alt;parent[v]=u;heapq.heappush(heap,(alt+h(v),alt,v))
    return math.inf,[],expanded

def bfs_diagnostics(points,adj,s,g):
    def levels(root):
        d=[-1]*len(points);d[root]=0;q=deque([root]);pr=[-1]*len(points)
        while q:
            u=q.popleft()
            for v,w in adj[u]:
                if d[v]<0: d[v]=d[u]+1;pr[v]=u;q.append(v)
        return d,pr
    ds,parent=levels(s); dg,_=levels(g); hops=ds[g]
    if hops<0: return {'hops':-1,'length':math.inf,'min_length':math.inf,'max_length':math.inf,'path':[]}
    route=[];u=g
    while u!=-1:route.append(u);u=parent[u]
    route=route[::-1]
    mn=[math.inf]*len(points);mx=[-math.inf]*len(points);mn[s]=mx[s]=0.
    for u in sorted(range(len(points)),key=lambda i:ds[i]):
        if ds[u]<0 or dg[u]<0 or ds[u]+dg[u]!=hops:continue
        for v,w in adj[u]:
            if ds[v]==ds[u]+1 and ds[v]+dg[v]==hops:
                mn[v]=min(mn[v],mn[u]+w);mx[v]=max(mx[v],mx[u]+w)
    return {'hops':hops,'length':sum(math.dist(points[a],points[b]) for a,b in zip(route,route[1:])), 'min_length':mn[g],'max_length':mx[g], 'path':[points[i] for i in route]}

class Planner:
    def __init__(self,obstacles,mode):
        t=time.perf_counter_ns()
        self.mode=mode;self.geom=Geometry(obstacles);self.points=[];self.neighbors=[]
        for po in self.geom.polys:
            for i,p in enumerate(po):
                self.points.append(p);self.neighbors.append((po[i-1],po[(i+1)%len(po)]))
        self.adj=[[] for p in self.points];self.known={};self.blocked=set()
        self.candidate_pairs=0;self.tangent_pairs=0 if mode in ('tangent','lazy_tangent') else None
        for i,p in enumerate(self.points):
            for j in range(i+1,len(self.points)):
                self.candidate_pairs+=1;q=self.points[j]
                if mode in ('tangent','lazy_tangent'):
                    tg=tangent(p,q,self.neighbors[i]) and tangent(q,p,self.neighbors[j])
                    self.tangent_pairs+=int(tg)
                    if not tg:continue
                if mode=='lazy_tangent': valid=True
                else:valid=self.geom.visible(p,q)
                if valid:
                    w=math.dist(p,q);self.adj[i].append((j,w));self.adj[j].append((i,w))
                if mode=='lazy_tangent': self.known[(i,j)]=None
        if mode=='posthoc_tangent':
            self.adj=[[(j,w) for j,w in row if tangent(self.points[i],self.points[j],self.neighbors[i]) and tangent(self.points[j],self.points[i],self.neighbors[j])] for i,row in enumerate(self.adj)]
        self.preprocess_checks=self.geom.checks
        self.preprocess_edges=sum(map(len,self.adj))//2
        self.preprocess_ns=time.perf_counter_ns()-t

    def query(self,start,goal,diagnostics=False):
        t=time.perf_counter_ns(); before=self.geom.checks
        if any(inside(start,po) or inside(goal,po) for po in self.geom.polys):
            return {'length':math.inf,'path':[],'reason':'endpoint_inside_obstacle','query_ns':time.perf_counter_ns()-t,'checks':0}
        pts=self.points+[tuple(start),tuple(goal)];n=len(self.points);s=n;g=n+1
        adj=[row.copy() for row in self.adj]+[[],[]];known=self.known.copy();blocked=self.blocked.copy()
        candidate=0;retained=0
        for i in (s,g):
            for j in range(i):
                p,q=pts[i],pts[j]; candidate+=1
                if self.mode in ('tangent','lazy_tangent'):
                    tg=tangent(q,p,self.neighbors[j]) if j<n else True
                    if not tg:continue
                key=(j,i)
                if self.mode=='lazy_tangent':valid=True;known[key]=None
                else:valid=self.geom.visible(p,q)
                if valid:
                    w=math.dist(p,q);adj[i].append((j,w));adj[j].append((i,w));retained+=1
        if self.mode=='posthoc_tangent':
            for i in (s,g):
                for j,w in adj[i].copy():
                    if j<n and not tangent(pts[j],pts[i],self.neighbors[j]):
                        adj[i].remove((j,w));adj[j].remove((i,w));retained-=1
        calls=0;expanded=0
        while True:
            length,path,exp=astar(pts,adj,s,g,blocked if self.mode=='lazy_tangent' else None)
            calls+=1;expanded+=exp
            if self.mode!='lazy_tangent' or not path:break
            invalid=False
            for a,b in zip(path,path[1:]):
                key=(min(a,b),max(a,b))
                if known.get(key) is None:
                    ok=self.geom.visible(pts[a],pts[b]);known[key]=ok
                    if key[1]<n:self.known[key]=ok
                    if not ok:
                        blocked.add(key)
                        if key[1]<n:self.blocked.add(key)
                        invalid=True;break
            if not invalid:break
        elapsed=time.perf_counter_ns()-t
        result={'length':length,'path':[pts[i] for i in path],'query_ns':elapsed,'checks':self.geom.checks-before,'expanded':expanded,'search_calls':calls,'query_candidates':candidate,'query_edges':retained,'reason':'success' if path else 'disconnected'}
        if diagnostics and self.mode!='lazy_tangent':
            result['bfs']=bfs_diagnostics(pts,adj,s,g)
            if self.mode=='full':
                result['dijkstra_length']=astar(pts,adj,s,g,heuristic=False)[0]
        return result
