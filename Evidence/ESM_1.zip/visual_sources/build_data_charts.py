"""Re-create approved chart compositions from frozen data, not image pixels.
One matplotlib axes per chart. Exact markers, intervals and path traces are
exported beside editable SVG / PDF artwork. Colors follow the author's examples.
"""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.stats import gaussian_kde
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
R=Path(__file__).resolve().parents[1];B=R/'baseline_release'
if not B.exists():B=R
A=B/'study/analysis';O=R/'manuscript/figures';D=R/'visual_data';O.mkdir(parents=True,exist_ok=True);D.mkdir(exist_ok=True)
S=pd.read_csv(A/'paired_summary.csv')
plt.rcParams.update({'font.family':'Liberation Sans','font.size':9.2,'axes.labelsize':9.2,'xtick.labelsize':8.5,'ytick.labelsize':8.5,'axes.titlesize':8.8,'axes.titleweight':'normal','axes.labelweight':'normal','font.weight':'normal','svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.unicode_minus':False,'axes.edgecolor':'#9AA9B2','axes.linewidth':.55,'text.color':'#294052','axes.labelcolor':'#294052','xtick.color':'#637583','ytick.color':'#637583','savefig.facecolor':'white'})
N='#203B50';T='#178C92';AM='#D99527';RE='#B96560';GR='#708997';EDGE='#E3E9ED'
C=['generated','external','finite'];CN=['Generated','External','Fixed square'];MC=[T,AM,N]
ledger={}
def ink(c): return {T:'#0A7075',AM:'#8A5D17',RE:'#984D48'}.get(c,c)
def base(w=6.62,h=3.5,left=.12,right=.97,bottom=.18,top=.90):
 f,ax=plt.subplots(figsize=(w,h));f.subplots_adjust(left=left,right=right,bottom=bottom,top=top)
 for sp in ['top','right']:ax.spines[sp].set_visible(False)
 ax.tick_params(axis='both',width=.5,length=3);ax.set_axisbelow(True)
 return f,ax

def save(f,name):
 f.savefig(O/(name+'.pdf'));f.savefig(O/(name+'.svg'));f.savefig(O/(name+'.png'),dpi=340);plt.close(f)

def clean_records(frame):return json.loads(frame.to_json(orient='records'))

# Fig. 9: aligned measure panels, complete corpus labeling and exact intervals.
f,ax=base(h=3.62,left=.105,bottom=.19,top=.90)
recs=[]
for j,(metric,label,col) in enumerate([('pops','Processed vertices',T),('scans','Adjacency inspections',AM),('time_ns','Total time',N)]):
 x=1.2*np.arange(3)+3.6*j;g=S[(S.numerator=='lazy_lpa_query')&(S.denominator=='lazy_astar')&(S.horizon==40)&(S.metric==metric)].set_index('corpus').loc[C].reset_index();recs+=clean_records(g)
 ax.axvspan(3.6*j-.5,3.6*j+2.9,facecolor=col,alpha=.045,linewidth=0,zorder=0)
 ax.text(3.6*j+1.2,4.57,label,fontsize=9.0,ha='center',va='center',color=ink(col))
 ax.errorbar(x,g['median'],yerr=[g['median']-g.low,g.high-g['median']],fmt='o',color=col,ms=4.2,lw=.9,capsize=2,capthick=.8,zorder=3)
 for xi,med in zip(x,g['median']):ax.annotate(f'{med:.3f}',(xi,med),xytext=(5,0),textcoords='offset points',va='center',fontsize=8.2,color=ink(col))
ax.axhline(1,color=T,lw=.7,ls=(0,(4,3)),zorder=2);ax.set_ylim(.45,4.76);ax.set_xlim(-.6,10.4);ax.set_yticks([.5,1,2,3,4]);ax.grid(axis='y',color=EDGE,lw=.5)
ax.set_xticks([0,1.2,2.4,3.6,4.8,6.0,7.2,8.4,9.6],['Generated','External','Fixed\nsquare']*3,fontsize=8.2);ax.set_ylabel('Query-local LPA* / restarted A*');save(f,'search_costs');pd.DataFrame(recs).to_csv(D/'search_costs.csv',index=False);ledger['search_costs']={'composition':'Three aligned metric lanes; source-exact estimates and 95% cluster intervals','rows':len(recs),'source':'study/analysis/paired_summary.csv'}

# Fig. 10: raincloud of all observed ratios; descriptive KDE never alters points.
f,ax=base(h=4.8,left=.35,bottom=.14,top=.96)
rows=[];labels=[];colors=[T,AM,'#6889A3'];j=0
for engine,en in [('astar','A*'),('lpa_query','Query-local LPA*'),('lpa_persistent','Retained LPA*')]:
 dat=pd.read_csv(A/f'triggered_{engine}.csv')
 for corpus,cn,col in zip(C,CN,colors):
  g=dat[dat.corpus==corpus].copy();v=np.sort(g.ratio.to_numpy());y=8-j
  lo,hi=min(v)-.10,max(v)+.10;xx=np.linspace(lo,hi,240);density=gaussian_kde(v,bw_method='scott')(xx);density=density/density.max()*.29
  ax.fill_between(xx,y+.045,y+.045+density,color=col,alpha=.17,lw=0,zorder=1)
  # deterministic vertical offsets only; every horizontal value is an archived ratio.
  dy=np.array([-.05,-.10,-.15,-.07,-.12])[np.arange(len(v))%5]
  ax.scatter(v,y+dy,s=15,facecolors=col,edgecolors='white',lw=.35,alpha=.8,zorder=3)
  ax.plot(np.median(v),y-.095,marker='D',color=col,ms=5.5,mec='white',mew=.8,zorder=4)
  labels.append(f'{en} · {cn.lower()} (n={len(v)})')
  g['figure_row']=j;rows+=clean_records(g[['workload_id','source_map','corpus','engine','ratio','figure_row']]);j+=1
ax.axvline(1,color=T,lw=.75,ls=(0,(4,3)));ax.set_xlim(.32,1.50);ax.set_ylim(-.45,8.65);ax.set_yticks(range(8,-1,-1),labels,fontsize=8.2);ax.tick_params(axis='y',length=0,pad=6);ax.spines['left'].set_visible(False)
ax.set_xticks(np.arange(.4,1.5,.2));ax.grid(axis='x',color=EDGE,lw=.5);ax.set_xlabel('Persistent-only / bundled total time at 40 requests');save(f,'endpoint_ablation')
pd.DataFrame(rows).to_csv(D/'endpoint_ablation.csv',index=False);ledger['endpoint_ablation']={'composition':'Raincloud: one point per observed workload, group median diamond, Scott-bandwidth descriptive KDE','rows':len(rows),'x_values':'Unchanged archived per-workload ratios','smoothing':'gaussian_kde, Scott rule, maximum normalized per row; no inferential density interpretation'}

# Fig. 11: approved direct-labeled horizon trajectories, exact medians.
f,ax=base(h=3.5,left=.115,right=.75,bottom=.18,top=.94)
series=[]
for mode,label,col,ls,mark in [('internal_astar','Persistent-only',T,'-','o'),('bundled_astar','Bundled',AM,'--','s'),('timed_astar','Time-triggered',N,':','D'),('fixed_astar','Initial-budget',RE,'-.','^')]:
 g=S[(S.numerator==mode)&(S.denominator=='lazy_astar')&(S.metric=='time_ns')&(S.corpus=='generated')].sort_values('horizon');series+=clean_records(g)
 ax.plot(g.horizon,g['median'],ls,color=col,lw=1.15,marker=mark,ms=4,mec='white',mew=.4)
 last=g.iloc[-1];ax.text(41.5,last['median'],label,color=ink(col),fontsize=9,va='center',clip_on=False)
ax.axhline(1,color=GR,lw=.7,ls=(0,(4,3)));ax.set_xlim(0,40.7);ax.set_ylim(.977,1.033);ax.set_xticks([1,5,20,40]);ax.set_yticks([.98,.99,1,1.01,1.02,1.03]);ax.grid(color=EDGE,lw=.5)
ax.set_xlabel('Completed requests after one construction');ax.set_ylabel('Median total time / permanent laziness');save(f,'query_horizon');pd.DataFrame(series).to_csv(D/'query_horizon.csv',index=False);ledger['query_horizon']={'composition':'Direct-labeled four-policy horizon trajectories','rows':len(series),'source':'study/analysis/paired_summary.csv'}

# Fig. 12: observed adverse trace, subtle non-stacked fills and exact end labels.
f,ax=base(h=3.7,left=.115,right=.74,bottom=.18,top=.90)
trace=pd.read_csv(B/'supplement/failure_trace_records.csv');curves=[]
for mode,label,col,ls in [('internal_astar','Persistent-only',AM,'-'),('bundled_astar','Bundled',N,'--'),('lazy_astar','Permanently lazy',T,'-')]:
 g=trace[trace['mode']==mode].groupby('request',as_index=False)['cumulative_ns'].median();g['mode']=mode;g['milliseconds']=g.cumulative_ns/1e6;curves+=clean_records(g)
 ax.fill_between(g.request,0,g.milliseconds,facecolor=col,alpha=.045,linewidth=0)
 ax.plot(g.request,g.milliseconds,color=col,lw=1.15,ls=ls)
 last=g.iloc[-1];ax.plot(40,last.milliseconds,'o',mfc='white',mec=col,ms=4.8,mew=1)
 ax.text(41.5,last.milliseconds,label+'\n'+f'{last.milliseconds:.3f} ms',color=ink(col),fontsize=9,va='center',linespacing=1.45,clip_on=False)
ax.axvline(35,color=GR,lw=.7,ls=(0,(1,3)));ax.annotate('Completion before request 35',xy=(35,44),xytext=(34,46),ha='right',fontsize=8.5,color=GR)
ax.set_xlim(0,40.7);ax.set_ylim(0,45.5);ax.set_xticks([1,10,20,30,35,40]);ax.set_yticks([0,10,20,30,40]);ax.grid(axis='y',color=EDGE,lw=.5)
ax.set_xlabel('Completed requests');ax.set_ylabel('Median cumulative elapsed time (ms)');save(f,'failure_trace');pd.DataFrame(curves).to_csv(D/'failure_trace.csv',index=False);ledger['failure_trace']={'composition':'Direct-labeled adverse case with recorded event marker and exact cumulative curves','rows':len(curves),'source':'supplement/failure_trace_records.csv','final_ms':{m:float(g[g.request==40].milliseconds.iloc[0]) for m,g in pd.DataFrame(curves).groupby('mode')}}

# Fig. 13: full-policy comparison in three light corpus lanes.
f,ax=base(h=3.5,left=.115,bottom=.18,top=.86)
recs=[]
for i,col in enumerate([T,'#8490AC',AM]):ax.axvspan(i-.44,i+.44,color=col,alpha=.045,lw=0)
for j,(engine,label,col,marker) in enumerate([('astar','A*',T,'o'),('lpa_query','Query-local LPA*',AM,'s'),('lpa_persistent','Retained LPA*',N,'D')]):
 g=S[(S.numerator=='timed_'+engine)&(S.denominator=='lazy_'+engine)&(S.horizon==40)&(S.metric=='time_ns')].set_index('corpus').loc[C].reset_index();recs+=clean_records(g)
 ax.errorbar(np.arange(3)+(j-1)*.23,g['median'],yerr=[g['median']-g.low,g.high-g['median']],color=col,fmt=marker,ms=4.3,lw=.9,capsize=2,label=label)
ax.axhline(1,color=T,lw=.7,ls=(0,(4,3)));ax.set_xlim(-.5,2.5);ax.set_ylim(.945,1.355);ax.set_yticks([.95,1,1.1,1.2,1.3]);ax.grid(axis='y',color=EDGE,lw=.5);ax.set_xticks(range(3),CN)
ax.set_ylabel('Time-triggered completion / permanent laziness');ax.legend(loc='lower center',bbox_to_anchor=(.5,1.045),ncol=3,frameon=False,fontsize=9,handlelength=1.2,columnspacing=2)
save(f,'time_signal');pd.DataFrame(recs).to_csv(D/'time_signal.csv',index=False);ledger['time_signal']={'composition':'Three corpus lanes, engine-specific markers and exact cluster intervals','rows':len(recs),'source':'study/analysis/paired_summary.csv'}
(D/'CHART_DATA_LEDGER.json').write_text(json.dumps(ledger,indent=2))
print('Five approved chart compositions rebuilt from archived numbers with one consistent typeface.')
print('Adverse-case endpoints (ms):',ledger['failure_trace']['final_ms'])
