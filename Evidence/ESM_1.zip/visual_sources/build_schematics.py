"""Deterministic vector artwork for manuscript v9.
Typeface, physical width, and line hierarchy are shared by every schematic.
Displayed empirical geometry is loaded from exact-predicate verified edge sets.
"""
from pathlib import Path
from html import escape
import json, math, shutil
import cairosvg
from shapely.geometry import Polygon,LineString
R=Path(__file__).resolve().parents[1]; O=R/'manuscript/figures'; O.mkdir(parents=True,exist_ok=True)
N='#203B50'; T='#178C92'; A='#D99527'; G='#6D7F8D'; C='#B7C3CC'; RED='#B96560'; OBS='#E8EDF0'; LT='#F4F8F9'; INK='#294052'
FONT='Liberation Sans'
class S:
 def __init__(self,h,title):
  self.w=1200;self.h=h;self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" width="168mm" height="{168*h/1200:.5f}mm" viewBox="0 0 1200 {h}"><title>{escape(title)}</title><rect width="1200" height="{h}" fill="white"/>']
 def text(self,x,y,s,size=21,color=INK,weight='normal',anchor='start'):
  color={T:'#0A7075',A:'#8A5D17',G:'#5B6F7D',RED:'#984D48'}.get(color,color)
  self.a.append(f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" fill="{color}">{escape(str(s))}</text>')
 def lines(self,x,y,ss,size=21,color=INK,step=28,anchor='start'):
  for i,s in enumerate(ss):self.text(x,y+i*step,s,size,color,anchor=anchor)
 def rect(self,x,y,w,h,fill='white',stroke=C,r=8,sw=1):self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def poly(self,ps,fill=OBS,stroke=N,sw=1.5):self.a.append('<polygon points="'+' '.join(f'{x:.6f},{y:.6f}' for x,y in ps)+f'" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def path(self,ps,col=N,sw=1.5,dash=None,alpha=1):
  das=f' stroke-dasharray="{dash}"' if dash else ''
  self.a.append('<polyline points="'+' '.join(f'{x:.6f},{y:.6f}' for x,y in ps)+f'" fill="none" stroke="{col}" stroke-width="{sw}" stroke-linecap="butt" stroke-linejoin="miter" opacity="{alpha}"{das}/>')
 def line(self,a,b,col=N,sw=1.5,dash=None,alpha=1):self.path([a,b],col,sw,dash,alpha)
 def arrow(self,ps,col=G,sw=1.5):
  self.path(ps,col,sw);(x0,y0),(x1,y1)=ps[-2:]; ang=math.atan2(y1-y0,x1-x0);l=8;w=4
  self.poly([(x1,y1),(x1-l*math.cos(ang)+w*math.sin(ang),y1-l*math.sin(ang)-w*math.cos(ang)),(x1-l*math.cos(ang)-w*math.sin(ang),y1-l*math.sin(ang)+w*math.cos(ang))],col,col,.4)
 def circle(self,x,y,r=3,fill='white',stroke=N,sw=1.2):self.a.append(f'<circle cx="{x:.6f}" cy="{y:.6f}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def header(self,x,y,label):self.text(x,y,label,22,N)
 def save(self,name):
  src=''.join(self.a)+'</svg>';(O/(name+'.svg')).write_text(src)
  cairosvg.svg2pdf(bytestring=src.encode(),write_to=str(O/(name+'.pdf')))
  cairosvg.svg2png(bytestring=src.encode(),write_to=str(O/(name+'.png')),output_width=2400)

def mapping(box,bounds):
 x,y,w,h=box; xmin,ymin,xmax,ymax=bounds;k=min(w/(xmax-xmin),h/(ymax-ymin));ox=x+(w-k*(xmax-xmin))/2;oy=y+(h-k*(ymax-ymin))/2
 return lambda p:(ox+(p[0]-xmin)*k,oy+(ymax-p[1])*k)

D=json.loads((R/'visual_data/constructed_graph_comparison.json').read_text()); OBS0=D['obstacles']
def graph(d,data,box,bounds,edges=None,route=True,alternative=False,labels=True,route_width=2.4):
 f=mapping(box,bounds);pts=data['points']
 for po in data['obstacles']:d.poly([f(p) for p in po],OBS,N,1.0)
 if edges is not None:
  for i,j in edges:d.line(f(pts[i]),f(pts[j]),'#7A8E9D',.9,alpha=1)
 if alternative:
  path=[pts[-2],[4,6],[6,6],pts[-1]];d.path([f(p) for p in path],T,1.9)
 if route:d.path([f(p) for p in data['path']],A,route_width)
 if edges is not None:
  for p in pts[:-2]:d.circle(*f(p),2.0,'white',N,.8)
 for idx,lab,col in [(data['start_index'],'S',T),(data['goal_index'],'G',N)]:
  x,y=f(pts[idx]);d.circle(x,y,4.2,col,'white',1)
  if labels:d.text(x+8,y-7,lab,20,col)
 return f

# Fig. 1: restrained architecture; short orthogonal connectors.
d=S(450,'Navigation functions and representative roadmap constructions')
d.header(22,28,'a  Navigation functions')
for x,title,lines in [(22,'Perception',['Sensor observations','Environment features']),(320,'Localization',['Pose estimation','Map-relative position']),(618,'Planning',['Goal and map','Collision-free path']),(916,'Motion control',['Path tracking','Actuator commands'])]:
 col=T if title=='Planning' else N;d.rect(x,50,262,113,'#EEF7F7' if title=='Planning' else LT,'#D6E1E6',5)
 d.text(x+17,83,title,22,col);d.lines(x+17,116,lines,19,step=26)
for x in [284,582,880]:d.arrow([(x+5,106),(x+27,106)],G,1.4)
d.arrow([(1047,169),(1047,201),(153,201),(153,169)],G,1.2);d.text(600,191,'Sensor feedback during execution',20,G,anchor='middle')
d.header(22,247,'b  Representative roadmap constructions')
for x,title,ss in [(22,'Visibility / tangent',['Obstacle-derived vertices','Geometric connections']),(424,'Voronoi-based',['Clearance-based structure','Equidistant free-space loci']),(826,'Probabilistic roadmap',['Sampled configurations','Local connection attempts'])]:
 d.rect(x,267,352,112,'#EEF7F7' if x==22 else 'white','#D1DFE4',5);d.text(x+16,300,title,21,T if x==22 else N);d.lines(x+16,332,ss,19,step=25)
d.line((22,399),(1178,399),'#D9E2E6',1);d.text(22,431,'Study scope',19,T);d.text(145,431,'Visibility-based candidates; persistent and query-specific collision validation',20,N)
d.save('navigation_context')

# Fig. 2: full versus reduced constructed graph, same weighted objective.
d=S(495,'Full and reduced visibility graphs on the same constructed geometry')
d.header(22,29,'a  Full visibility graph');d.header(626,29,'b  Tangent-reduced visibility graph')
ff=graph(d,D,(24,56,548,319),(0,0,11,9),D['full_edges'],True,True)
d.line(ff([1,3]),ff([10,3]),RED,1.3,'6 5')
graph(d,D,(628,56,548,319),(0,0,11,9),D['reduced_edges'],True,False)
d.text(24,400,f"{D['full_edge_count']} visible edges",20,N);d.text(628,400,f"{D['reduced_edge_count']} retained edges · {D['removed_count']} removed",20,N)
d.text(24,429,'Lower route 9.285; upper route 11.243 units',20,G);d.text(628,429,'Same minimum path length: 9.285 units',20,G)
d.line((24,461),(65,461),A,2.4);d.text(77,468,'Shortest route',19)
d.line((265,461),(306,461),T,1.9);d.text(318,468,'Alternative route',19)
d.line((528,461),(569,461),'#7A8E9D',.9);d.text(581,468,'Collision-free edge',19)
d.line((888,461),(929,461),RED,1.3,'6 5');d.text(941,468,'Rejected direct segment',20);d.save('foundation_route')

# Fig. 3: finite footprint, with no offset of the actual centreline.
d=S(395,'Robot footprint and configuration-space obstacle')
d.header(22,29,'a  Workspace');d.header(626,29,'b  Configuration space')
for k in [0,1]:
 f=mapping((25+604*k,60,545,244),(0,0,8,5)); po=[[2,1],[5,1],[5,4],[2,4]]
 if k:d.poly([f(p) for p in [[1.6,.6],[5.4,.6],[5.4,4.4],[1.6,4.4]]],'#E6F3F3',T,1.3)
 d.poly([f(p) for p in po],OBS,N,1.1);d.path([f(p) for p in [[.5,.6],[7,.6]]],A,2)
 if not k:
  d.poly([f(p) for p in [[3,.2],[3.8,.2],[3.8,1],[3,1]]],'#FAEFDA',A,1.5)
 d.circle(*f([3.4,.6]),3.2,A,A,1)
d.text(24,332,'Square footprint; fixed orientation',20);d.text(628,332,'Obstacle expanded by half-side 0.4',20)
d.text(24,375,'The same centre path meets the respective contact boundary in both representations.',20,G)
d.save('foundation_footprint')

# Fig. 4: persistent geometry in a common color; changing query attachments.
d=S(414,'Persistent graph and query-specific attachment')
V=[p for po in OBS0 for p in po];polys=[Polygon(po) for po in OBS0]
def valid(a,b):return all(LineString([a,b]).relate_pattern(p,'F********') for p in polys)
for k,(s,g) in enumerate([([1,3],[10,3]),([1,7],[10,7])]):
 d.header(22+604*k,28,'a  Query 1' if k==0 else 'b  Query 2: changed terminals');f=mapping((24+604*k,56,548,280),(0,0,11,9))
 for po in OBS0:d.poly([f(p) for p in po],OBS,N,1)
 for i,p in enumerate(V):
  for q in V[i+1:]:
   if valid(p,q):d.line(f(p),f(q),T,1.05)
 for p in V:
  for q in [s,g]:
   if valid(p,q):d.line(f(p),f(q),A,1.2,'5 4')
 if valid(s,g):d.line(f(s),f(g),A,1.2,'5 4')
 for p in V:d.circle(*f(p),2.3,'white',N,.8)
 for p,lab,col in [(s,'S',T),(g,'G',N)]:
  x,y=f(p);d.circle(x,y,4,col,'white');d.text(x+8,y-7,lab,20,col)
d.line((24,373),(65,373),T,1.5);d.text(78,380,'Persistent obstacle connections',19)
d.line((627,373),(668,373),A,1.5,'5 4');d.text(681,380,'Query-specific terminal connections',19)
d.save('persistent_requests')

# Fig. 5: state branches on a grid, avoiding skewed and crossing arrows.
d=S(361,'Collision validation states and their retention lifetime')
for x,y,w,h,label,ss,col in [(24,80,230,101,'Unknown',['Candidate not yet tested'],N),(343,80,246,101,'Collision test',['Test segment geometry'],N),(797,25,376,100,'Valid',['Retain Euclidean edge cost'],T),(797,177,376,100,'Blocked',['Set cost to infinity'],RED)]:
 d.rect(x,y,w,h,'#F2F8F8' if col==T else ('#FBF6F5' if col==RED else LT),'#D5E0E5',5);d.text(x+18,y+35,label,22,col);d.lines(x+18,y+71,ss,19,col,step=24)
d.arrow([(263,130),(334,130)],G);d.arrow([(599,130),(704,130),(704,75),(787,75)],G);d.arrow([(704,130),(704,227),(787,227)],G)
d.lines(24,235,['On demand: test edges selected by search.','Completion: test remaining persistent candidates.'],20,N,step=29)
d.line((24,310),(1175,310),'#D9E2E6',1);d.text(24,342,'Persistent states survive query replacement; terminal states belong to one query.',20,T)
d.save('cache_storyboard')

# Fig. 6: two matched branches with shared decision and aligned arrows.
d=S(380,'Matched completion and terminal validation alternatives')
d.rect(24,80,295,165,LT,'#D1DFE4',5);d.text(43,113,'Shared completion event',22,N);d.lines(43,149,['Check all unknown','persistent candidates.','Retain their validity.'],20,step=28)
for y,label,ss,col in [(25,'Bundled completion',['For every later query:','check all terminal candidates before search.'],A),(195,'Persistent-only completion',['For every later query:','check terminal candidates on demand.'],T)]:
 d.rect(500,y,673,122,'#FAF6EC' if col==A else '#EFF8F7','#D7E2E5',5);d.text(520,y+34,label,22,N);d.lines(520,y+67,ss,20,step=27)
d.arrow([(328,163),(413,163),(413,86),(490,86)],G);d.arrow([(413,163),(413,256),(490,256)],G)
d.text(24,360,'Same persistent edge set and completion request; different query-attachment schedules.',20,G)
d.save('completion_policies')

# Fig. 7: reconstruct sampling units, not a broad decorative pipeline.
d=S(386,'Experiment units and matched comparisons')
for x,num,title,foot in [(24,'40','Generated point settings','Four geometry families'),(426,'20','External point settings','Released polygon maps'),(828,'12','Fixed-square settings','Derived from generated maps')]:
 d.rect(x,24,347,108,LT,'#D5E0E5',5);d.text(x+16,59,f'{num}  {title}',21,N);d.text(x+16,94,foot,20,G)
d.line((198,139),(198,157),G,1.2);d.line((600,139),(600,157),G,1.2);d.line((1000,139),(1000,157),G,1.2);d.line((198,157),(1000,157),G,1.2);d.arrow([(600,157),(600,182)],G,1.3)
d.rect(24,193,1151,61,'#EFF7F7','#D5E0E5',5);d.text(600,231,'72 settings × 3 query regimes × 40 requests = 8,640 request cases',22,N,anchor='middle')
d.arrow([(600,261),(600,285)],G,1.3)
d.text(24,279,'Dispersed · localized · shifted',20,G)
d.rect(24,296,1151,61,'white','#D5E0E5',5);d.text(600,333,'Each workload → 14 matched planner modes × 3 timing repetitions',21,N,anchor='middle')
d.text(600,380,'Shared geometry, requests and path objective; timings repeat the same cases.',20,G,anchor='middle');d.save('study_design')

# Fig. 8: identical geometry before / after edge reduction, both recorded queries.
arr=json.loads((R/'visual_data/observed_graph_comparison.json').read_text())
d=S(1290,'Full and reduced graphs for recorded requests 12 and 23')
d.header(24,29,'Full visibility graph');d.header(628,29,'Tangent-reduced graph')
bounds=(115,115,863,880)
for row,data in enumerate(arr):
 y=56+row*465
 for col,which in enumerate(['full_edges','reduced_edges']):
  x=24+col*604
  graph(d,data,(x,y+20,548,368),bounds,data[which],True,False,True,2.15)
  n=len(data[which]);d.text(x,y+416,f'Request {data["request"]} · {n} valid edges',21,N)
  bottom=f'Path length {data["shortest_full"]:.3f} units' if col==0 else f'{data["removed_count"]} edges removed · same path length'
  d.text(x,y+444,bottom,20,G)
 d.line((24,y+461),(1176,y+461),'#DFE6E9',1)
# Contact details show exact path and distinct boundary; no artificial clearance.
for k,data in enumerate(arr):
 x=24+604*k; y=1006
 d.text(x,y,f'Corner detail · request {data["request"]}',21,N)
 a,b=data['path'][1:3]; xmin=a[0]-72;xmax=a[0]+80;ymin=b[1]-40;ymax=a[1]+40
 f=mapping((x,y+20,245,190),(xmin,ymin,xmax,ymax))
 # clipped inset to keep the actual geometry, not a stylistic redraw.
 clip='clip'+str(k);d.a.append(f'<defs><clipPath id="{clip}"><rect x="{x}" y="{y+20}" width="245" height="190"/></clipPath></defs><g clip-path="url(#{clip})">')
 for po in data['obstacles']:d.poly([f(p) for p in po],OBS,N,1.5)
 d.path([f(p) for p in data['path']],A,2.15)
 for p in [a,b]:d.circle(*f(p),3,'white',A,1.15)
 d.a.append('</g>');d.lines(x+265,y+73,['Route coincides with','the obstacle boundary.','Strict interior is excluded.'],20,G,step=27)
 d.text(x+265,y+178,'Point model: contact permitted',18,N)
d.line((24,1256),(62,1256),'#7A8E9D',1);d.text(76,1263,'All valid graph edges',18)
d.line((372,1256),(410,1256),A,2.15);d.text(424,1263,'Recorded shortest path',18)
d.text(1175,1263,'Same coordinates and scale in all four maps',20,G,anchor='end');d.save('observed_requests')

# Graphical abstract: retain the approved left-to-right design logic, current evidence.
d=S(450,'Persistent validation and query-specific attachment')
d.text(24,30,'Reusable collision information and recurring query attachment',23,N)
# Left: map, edge states; centre: paired policy; right: fixed observed comparisons.
d.text(24,80,'Fixed polygonal map',22,N)
graph(d,D,(24,95,310,205),(0,0,11,9),D['reduced_edges'],True,False,False,2)
d.lines(24,335,['Persistent: obstacle connections','Query-specific: start / goal attachments'],20,G,step=26)
d.arrow([(354,201),(403,201)],G,1.5)
d.text(425,80,'Separate the validation domains',22,N)
d.rect(425,113,330,83,'#EFF8F7','#D3E0E4',6);d.lines(443,145,['Complete persistent checks','once for the fixed map.'],20,step=26)
d.rect(425,221,330,83,'#FAF6EC','#D3E0E4',6);d.lines(443,253,['Keep new terminal checks','on demand.'],20,step=26)
d.arrow([(590,202),(590,215)],G,1.4)
d.arrow([(770,201),(811,201)],G,1.5)
d.text(833,80,'Same 60 switched A* workloads',21,N)
for y,n,label,col in [(137,55,'Faster than bundled completion',T),(248,8,'Faster than permanent laziness',A)]:
 d.text(833,y,label,20,G);d.rect(833,y+18,340,20,'#EDF1F3','none',3,0);d.rect(833,y+18,340*n/60,20,col,'none',3,0);d.text(833,y+71,f'{n} / 60',22,N)
d.line((24,397),(1175,397),'#D6E1E5',1);d.text(600,431,'Recurring validation savings and the value of completing the graph are distinct.',21,N,anchor='middle');d.save('graphical_summary')
for ext in ['svg','pdf','png']:shutil.copy2(O/('graphical_summary.'+ext),R/'manuscript'/('graphical_abstract.'+ext))
print('Nine vector schematics built, including full/reduced graphs and current graphical abstract.')
