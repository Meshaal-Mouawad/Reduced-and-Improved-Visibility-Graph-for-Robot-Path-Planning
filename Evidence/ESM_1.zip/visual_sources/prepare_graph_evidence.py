"""Reconstruct displayed edge sets on two archived queries. No timing reruns.
Full visibility uses exact rational predicates from the independent reference.
The reduced set intersects full visibility with the frozen planner's tangency filter.
"""
from pathlib import Path
from itertools import combinations
import importlib.util, sys, math, json, heapq, hashlib
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'baseline_release'/'study'
if not DATA.exists(): DATA=ROOT/'study'
sys.path.insert(0,str(DATA))
import independent_oracle as exact
from planner_core import tangent
OUT=ROOT/'visual_data'; OUT.mkdir(exist_ok=True)

def distance(points,edges,s,t):
 adj=[[] for _ in points]
 for a,b in edges:
  w=math.dist(points[a],points[b]);adj[a].append((b,w));adj[b].append((a,w))
 dist=[math.inf]*len(points);dist[s]=0;prev={};heap=[(0,s)]
 while heap:
  d,u=heapq.heappop(heap)
  if d!=dist[u]:continue
  if u==t:break
  for v,w in adj[u]:
   if d+w<dist[v]:dist[v]=d+w;prev[v]=u;heapq.heappush(heap,(d+w,v))
 path=[t];u=t
 if math.isfinite(dist[t]):
  while u!=s:u=prev[u];path.append(u)
 return dist[t],path[::-1]

def evaluate(obstacles,s,g,archived=None):
 vertices=[p for po in obstacles for p in po]; neighbors=[]
 for po in obstacles:
  for i in range(len(po)):neighbors.append((po[i-1],po[(i+1)%len(po)]))
 pts=vertices+[s,g]; n=len(vertices);neighbors += [None,None]
 po=exact.polygons(obstacles); pp=[exact.point(p) for p in pts]
 full=[];red=[];candidates=[]
 for i,j in combinations(range(len(pts)),2):
  keep=tangent(pts[i],pts[j],neighbors[i]) and tangent(pts[j],pts[i],neighbors[j])
  if keep:candidates.append([i,j])
  # An independent, rational form checks that the frozen filter's signs agree.
  def tr(a,b,ns):
   if ns is None:return True
   vals=[exact.orient(a,b,exact.point(z)) for z in ns]
   return not (vals[0]*vals[1]<0)
  assert keep==(tr(pp[i],pp[j],neighbors[i]) and tr(pp[j],pp[i],neighbors[j]))
  if exact.visible_exact(pp[i],pp[j],po):
   full.append([i,j])
   if keep:red.append([i,j])
 df,pf=distance(pts,full,n,n+1);dr,pr=distance(pts,red,n,n+1)
 assert math.isclose(df,dr,rel_tol=1e-12)
 assert set(map(tuple,red))<=set(map(tuple,full))
 route=archived['path'] if archived else [pts[i] for i in pr]
 assert exact.valid_path(dict(obstacles=obstacles,start=s,goal=g),route)
 l=sum(math.dist(a,b) for a,b in zip(route,route[1:]));assert math.isclose(l,df,rel_tol=1e-12)
 if archived:assert math.isclose(l,archived['length'],rel_tol=1e-12)
 ids=[pts.index(p) for p in route]
 assert all(tuple(sorted((a,b))) in set(map(tuple,red)) for a,b in zip(ids,ids[1:]))
 contact=[]
 for a,b in zip(route,route[1:]):
  pa,pb=exact.point(a),exact.point(b)
  matches=[]
  for k,poly in enumerate(po):
   for u,v in exact.edges(poly):
    if exact.on_segment(pa,u,v) and exact.on_segment(pb,u,v):matches.append(k)
  contact.append({'a':a,'b':b,'coincident_obstacle_boundaries':matches})
 return dict(obstacles=obstacles,points=pts,start_index=n,goal_index=n+1,full_edges=full,reduced_edges=red,candidate_edges=candidates,full_edge_count=len(full),reduced_edge_count=len(red),removed_count=len(full)-len(red),reduction_fraction=1-len(red)/len(full),shortest_full=df,shortest_reduced=dr,path=route,route_segments=contact,all_rendered_edges_exact_valid=True,full_and_reduced_lengths_agree=True,route_in_reduced_graph=True)

cases=json.loads((DATA/'inputs.json').read_text());case=next(x for x in cases if x['workload_id']=='rectangles_8_10__shifted')
PV=ROOT/'baseline_release/visual_sources/observed_scenario_provenance.json'
if not PV.exists():PV=ROOT/'visual_data/archived_observed_provenance.json'
arch=json.loads(PV.read_text())
results=[]
for a in arch['requests']:
 q=case['queries'][a['index']];r=evaluate(case['obstacles'],q['start'],q['goal'],a);r.update(request=a['index']+1,workload_id=case['workload_id']);results.append(r)
(OUT/'observed_graph_comparison.json').write_text(json.dumps(results,indent=2))
obs=[[[4,2],[6,2],[6,6],[4,6]],[[7,6],[8.5,6],[8.5,8],[7,8]]]
c=evaluate(obs,[1,3],[10,3]);c['purpose']='Constructed explanatory geometry, separate from measured study';(OUT/'constructed_graph_comparison.json').write_text(json.dumps(c,indent=2))
print(json.dumps([{'request':r.get('request','constructed'),'nodes':len(r['points']),'full':r['full_edge_count'],'reduced':r['reduced_edge_count'],'removed':r['removed_count'],'length':r['shortest_full'],'boundary_segments':sum(bool(x['coincident_obstacle_boundaries']) for x in r['route_segments'])} for r in results+[c]],indent=2))
