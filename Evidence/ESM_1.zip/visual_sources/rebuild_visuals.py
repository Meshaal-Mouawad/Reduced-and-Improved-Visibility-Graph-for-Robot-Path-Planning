from pathlib import Path
import runpy
R=Path(__file__).resolve().parents[1]
for name in ("prepare_graph_evidence.py", "build_schematics.py", "build_data_charts.py"):
    runpy.run_path(str(R/"visual_sources"/name), run_name="__main__")
print("Figures regenerated. Run python manuscript/build_pdf.py from manuscript/ to rebuild the article.")
