#!/usr/bin/env python3
"""Paired policy-suffix measurements; never overwrite the original study."""
from pathlib import Path
import argparse, copy, csv, datetime, gc, hashlib, importlib.metadata, json, math, os, platform, random, sys, time
import pandas as pd

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--study',type=Path,default=Path(__file__).resolve().parents[1]/'study');ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'replay');ap.add_argument('--repetitions',type=int,default=20);a=ap.parse_args()
    if (a.out/'query_records.csv').exists():raise SystemExit('Refusing to overwrite recorded follow-up measurements. Choose a new output directory.')
    a.out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(a.study));from planners import Planner
    original=pd.read_csv(a.study/'results/queries.csv');oq=original[original['repeat']==0].set_index(['workload_id','mode','index'])
    cases={m['workload_id']:m for m in json.loads((a.study/'inputs.json').read_text())}
    specs=pd.read_csv(Path(__file__).resolve().parent/'results/triggered_workload_robustness.csv').sort_values(['engine','workload_id'])
    refs=pd.read_csv(a.study/'results/reference_lengths.csv').set_index(['workload_id','index']).length.to_dict()
    cpus=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else []
    try:
        if cpus:os.sched_setaffinity(0,{cpus[0]})
        affinity=sorted(os.sched_getaffinity(0)) if cpus else None
    except OSError:affinity=None
    cpu=Path('/proc/cpuinfo').read_text() if Path('/proc/cpuinfo').exists() else ''
    model=next((l.split(':',1)[1].strip() for l in cpu.splitlines() if l.startswith('model name')),platform.processor())
    env=dict(record_type='follow-up measurement environment, not original 2026-11-04 host metadata',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=sys.version,platform=platform.platform(),cpu_model=model,available_cpus=cpus,measurement_affinity=affinity,clock=vars(time.get_clock_info('perf_counter')),packages={n:importlib.metadata.version(n) for n in ['numpy','pandas']},repetitions=a.repetitions,engine_workload_pairs=len(specs),protocol_sha256=sha(Path(__file__).with_name('REPLAY_PROTOCOL.md')),driver_sha256=sha(Path(__file__)),planner_sha256=sha(a.study/'planners.py'),geometry_sha256=sha(a.study/'planner_core.py'),inputs_sha256=sha(a.study/'inputs.json'),garbage_collection='collect before pair; disabled during both timed suffixes',schedule='whole suffixes paired consecutively; balanced alternating AB/BA',seed=20261105)
    (a.out/'environment.json').write_text(json.dumps(env,indent=2))
    def clone(checkpoint,mode):
        old=checkpoint.geom.__dict__.pop('visible')
        try:c=copy.deepcopy(checkpoint)
        finally:checkpoint.geom.visible=old
        orig=c.geom.visible
        def timed_visible(x,y):
            t=time.perf_counter_ns();res=orig(x,y);c.check_ns+=time.perf_counter_ns()-t;c.num_timed_checks+=1;return res
        c.geom.visible=timed_visible;c.mode=mode;c.eager_terminals=mode.startswith('bundled_')
        return c
    expected_fields=['checks','pops','scans','rhs_updates','pushes','search_calls','extra_pops','unknown','completion_checks','persistent_checks','terminal_checks','terminal_candidates']
    rng=random.Random(20261105);count=0;checks=0;runrows=[];started=time.perf_counter();qw=None
    with (a.out/'query_records.csv').open('w',newline='') as f:
        for ix,sp in enumerate(specs.itertuples()):
            case=cases[sp.workload_id];engine=sp.engine;event=int(sp.completion_request)-1
            checkpoint=Planner(case['obstacles'],'bundled_'+engine)
            for i,q in enumerate(case['queries'][:event]):checkpoint.query(q['start'],q['goal'],i)
            assert checkpoint.pending and not checkpoint.complete
            before=(checkpoint.geom.checks,checkpoint.num_timed_checks,dict(checkpoint.known))
            first=rng.randint(0,1)
            for rep in range(-1,a.repetitions):
                branches=['internal_'+engine,'bundled_'+engine]
                if (first+rep)%2:branches.reverse()
                copies={mode:clone(checkpoint,mode) for mode in branches}
                gc.collect();enabled=gc.isenabled();gc.disable()
                pending=[]
                try:
                    for order,mode in enumerate(branches):
                        planner=copies[mode];rows=[]
                        for i in range(event,len(case['queries'])):
                            q=case['queries'][i];r=planner.query(q['start'],q['goal'],i);rows.append(r)
                        pending.append((order,mode,rows))
                finally:
                    if enabled:gc.enable()
                for order,mode,rows in pending:
                    for r in rows:
                        ref=refs[(sp.workload_id,r['index'])];assert math.isclose(r['length'],ref,rel_tol=1e-9,abs_tol=1e-8)
                        ex=oq.loc[(sp.workload_id,mode,r['index'])]
                        assert all(r[k]==int(ex[k]) for k in expected_fields),(sp.workload_id,mode,r['index'])
                        assert r['switch_request']==int(sp.completion_request)
                        if rep<0:continue
                        row=dict(workload_id=sp.workload_id,engine=engine,corpus=sp.corpus,source_map=sp.source_map,completion_request=int(sp.completion_request),repeat=rep,order_in_pair=order,mode=mode,**{k:v for k,v in r.items() if k!='path'})
                        if qw is None:qw=csv.DictWriter(f,fieldnames=list(row));qw.writeheader()
                        qw.writerow(row);count+=1;checks+=len(expected_fields)
                    if rep>=0:
                        total=sum(r['time_ns'] for r in rows);comp=sum(r['completion_ns'] for r in rows)
                        runrows.append(dict(workload_id=sp.workload_id,engine=engine,corpus=sp.corpus,source_map=sp.source_map,completion_request=int(sp.completion_request),repeat=rep,order_in_pair=order,mode=mode,suffix_ns=total,completion_ns=comp,requestwork_ns=total-comp,requests=len(rows),checks=sum(r['checks'] for r in rows),scans=sum(r['scans'] for r in rows)))
                assert before==(checkpoint.geom.checks,checkpoint.num_timed_checks,dict(checkpoint.known))
            f.flush();print(ix+1,len(specs),engine,sp.workload_id,round(time.perf_counter()-started,2),flush=True)
    pd.DataFrame(runrows).to_csv(a.out/'run_totals.csv',index=False)
    env.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.perf_counter()-started,timed_query_executions=count,operation_field_equalities=checks,all_lengths_match_reference=True,all_operation_profiles_match_archived=True,checkpoint_unchanged=True)
    (a.out/'environment.json').write_text(json.dumps(env,indent=2));print(json.dumps(env,indent=2))
if __name__=='__main__':main()
