#!/usr/bin/env python3
"""R2: recover run-level phases from immutable original records, then summarize.
No subtraction of plotted medians. No replacement or normalization of raw times.
"""
from pathlib import Path
import argparse, json, hashlib
import numpy as np
import pandas as pd

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--study',type=Path,default=Path(__file__).resolve().parents[1]/'study');pa.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'results');a=pa.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    q=pd.read_csv(a.study/'results/queries.csv');p=pd.read_csv(a.study/'results/prefixes.csv')
    k=['workload_id','mode','repeat']
    qs={key:g.sort_values('index') for key,g in q.groupby(k,sort=False)}
    ps={key:g.set_index('horizon') for key,g in p.groupby(k,sort=False)}
    identity=[];phases=[]
    for key,g in qs.items():
        pg=ps[key];init=int(pg.loc[1,'time_ns'])-int(g.iloc[0].time_ns)
        assert init>=0
        for h,row in pg.iterrows():
            reconstructed=init+int(g.loc[g['index']<h,'time_ns'].sum())
            assert reconstructed==int(row.time_ns),(key,h)
            identity.append(dict(workload_id=key[0],mode=key[1],repeat=key[2],horizon=int(h),time_ns=reconstructed))
    for engine in ('astar','lpa_query','lpa_persistent'):
        finals=p[(p.horizon==40)&(p['mode']=='bundled_'+engine)&p.switch_request.notna()]
        for _,f in finals.iterrows():
            wid,rep=f.workload_id,int(f['repeat']);c=int(f.switch_request);ev=c-1
            rec=dict(workload_id=wid,repeat=rep,engine=engine,source_map=f.source_map,corpus=f.corpus,regime=f.regime,completion_request=c)
            gi=qs[(wid,'internal_'+engine,rep)];gb=qs[(wid,'bundled_'+engine,rep)]
            opcols=['checks','pops','scans','rhs_updates','pushes','search_calls','extra_pops','unknown','persistent_checks','terminal_checks','terminal_candidates']
            assert gi.loc[gi['index']<ev,opcols].reset_index(drop=True).equals(gb.loc[gb['index']<ev,opcols].reset_index(drop=True))
            assert int(gi.switch_request.dropna().iloc[0])==c
            rec['equal_prefix_operations']=True
            for short,mode in [('i','internal_'+engine),('b','bundled_'+engine),('l','lazy_'+engine)]:
                g=qs[(wid,mode,rep)];pg=ps[(wid,mode,rep)]
                init=int(pg.loc[1,'time_ns'])-int(g.iloc[0].time_ns)
                prefix=init+int(g.loc[g['index']<ev,'time_ns'].sum())
                completion=int(g.loc[g['index']>=ev,'completion_ns'].sum())
                event_request=int(g.loc[g['index']==ev,'time_ns'].sum())-completion
                later=int(g.loc[g['index']>ev,'time_ns'].sum())
                requestwork=event_request+later;total=int(pg.loc[40,'time_ns'])
                assert prefix+completion+requestwork==total
                rec.update({f'{short}_{n}_ns':v for n,v in [('construction',init),('prefix',prefix),('completion',completion),('event_request',event_request),('later_requests',later),('requestwork',requestwork),('suffix',completion+requestwork),('total',total)]})
            for den in ['b','l']:
                for phase in ['prefix','completion','requestwork','suffix','total']:
                    rec[f'i_minus_{den}_{phase}_ns']=rec[f'i_{phase}_ns']-rec[f'{den}_{phase}_ns']
                    if rec[f'{den}_{phase}_ns']:
                        rec[f'i_over_{den}_{phase}']=rec[f'i_{phase}_ns']/rec[f'{den}_{phase}_ns']
            phases.append(rec)
    d=pd.DataFrame(phases);d.to_csv(a.out/'original_run_phases.csv',index=False)
    # Workload-level rankings: sign of each repetition, original ratio of medians,
    # and separately the median of within-repetition differences.
    workloads=[]
    for (eng,wid),g in d.groupby(['engine','workload_id'],sort=False):
        r=dict(engine=eng,workload_id=wid,corpus=g.iloc[0].corpus,source_map=g.iloc[0].source_map,completion_request=int(g.iloc[0].completion_request),repetitions=len(g))
        assert len(g)==3
        for den in ['b','l']:
            for phase in ['prefix','requestwork','suffix','total']:
                ni,nd=f'i_{phase}_ns',f'{den}_{phase}_ns'
                ratio=float(g[ni].median()/g[nd].median())
                delta=g[ni]-g[nd]
                r[f'i_over_{den}_{phase}_ratio_of_medians']=ratio
                r[f'i_minus_{den}_{phase}_median_ns']=float(delta.median())
                r[f'i_faster_{den}_{phase}_runs']=int((delta<0).sum())
            r[f'{den}_ranking_flips_total_to_suffix']=bool((r[f'i_over_{den}_total_ratio_of_medians']<1)!=(r[f'i_over_{den}_suffix_ratio_of_medians']<1))
            r[f'{den}_median_prefix_dominates_final_gap']=bool(abs(r[f'i_minus_{den}_prefix_median_ns'])>=abs(r[f'i_minus_{den}_total_median_ns']))
        workloads.append(r)
    w=pd.DataFrame(workloads);w.to_csv(a.out/'triggered_workload_robustness.csv',index=False)
    summary=[]
    for (eng,corp),g in w.groupby(['engine','corpus']):
        rr=d[(d.engine==eng)&(d.corpus==corp)]
        r=dict(engine=eng,corpus=corp,workloads=len(g),paired_runs=len(rr))
        for den in ['b','l']:
            for phase in ['total','suffix','requestwork']:
                v=g[f'i_faster_{den}_{phase}_runs']
                r[f'{den}_{phase}_median_wins']=int((g[f'i_over_{den}_{phase}_ratio_of_medians']<1).sum())
                r[f'{den}_{phase}_all3_wins']=int((v==3).sum());r[f'{den}_{phase}_all3_losses']=int((v==0).sum());r[f'{den}_{phase}_mixed']=int(v.between(1,2).sum())
            r[f'{den}_ranking_flips_total_to_suffix']=int(g[f'{den}_ranking_flips_total_to_suffix'].sum())
            r[f'{den}_median_prefix_dominates_final_gap']=int(g[f'{den}_median_prefix_dominates_final_gap'].sum())
            r[f'{den}_median_abs_prefix_imbalance_ms']=float(np.median(abs(g[f'i_minus_{den}_prefix_median_ns']))/1e6)
        summary.append(r)
    s=pd.DataFrame(summary);s.to_csv(a.out/'robustness_summary.csv',index=False)
    # Tables 4--6: all principal comparison signs, for every repetition and horizon.
    rr=[]
    for eng in ('astar','lpa_query','lpa_persistent'):
        for num,den in [('internal_'+eng,'bundled_'+eng),('internal_'+eng,'lazy_'+eng),('timed_'+eng,'lazy_'+eng),('bundled_'+eng,'lazy_'+eng)]:
            pn=p[p['mode']==num];pdn=p[p['mode']==den]
            z=pn.merge(pdn,on=['workload_id','repeat','horizon'],suffixes=('_n','_d'),validate='one_to_one')
            for (wid,h),g in z.groupby(['workload_id','horizon']):
                wins=int((g.time_ns_n<g.time_ns_d).sum())
                rr.append(dict(numerator=num,denominator=den,workload_id=wid,horizon=int(h),corpus=g.iloc[0].corpus_n,source_map=g.iloc[0].source_map_n,ratio_of_medians=float(g.time_ns_n.median()/g.time_ns_d.median()),faster_repetitions=wins,all_three_same_direction=wins in (0,3),num_triggered_runs=int(g.switch_request_n.notna().sum())))
    allrank=pd.DataFrame(rr);allrank.to_csv(a.out/'all_comparison_rank_stability.csv',index=False)
    out=dict(input_hashes={str(x.relative_to(a.study)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (a.study/'results/queries.csv',a.study/'results/prefixes.csv')},original_query_rows=len(q),reconstructed_prefix_rows=len(identity),triggered_engine_workloads=len(w),paired_triggered_runs=len(d),all_prefix_operation_counts_equal=bool(d.equal_prefix_operations.all()),all_phases_sum_to_original_total=True,method='Integer nanoseconds separated within each recorded repetition, before medians; completion_ns is the original timed completion block; requestwork includes the first request after completion and all later requests. No subtraction of medians.',summary=summary)
    (a.out/'ROBUSTNESS_CHECKS.json').write_text(json.dumps(out,indent=2))
    bad=d[d.workload_id=='maprandomStartAndGoalSmall8__shifted'];bad.to_csv(a.out/'adverse_case_run_phases.csv',index=False)
    print(s.to_string(index=False));print('\nA* ADVERSE CASE\n',bad[bad.engine=='astar'].to_string(index=False))
if __name__=='__main__':main()
