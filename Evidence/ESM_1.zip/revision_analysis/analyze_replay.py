#!/usr/bin/env python3
"""Summarize matched-checkpoint suffix timings without altering primary records."""
from pathlib import Path
import argparse, json, hashlib
import numpy as np
import pandas as pd

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def cluster_ci(frame, metric, rng, B=5000):
    ids=sorted(frame.source_map.unique()); groups=[frame.loc[frame.source_map==x,metric].to_numpy() for x in ids]
    draws=np.empty(B)
    for b in range(B):
        draws[b]=np.median(np.concatenate([groups[i] for i in rng.integers(len(groups),size=len(groups))]))
    return np.quantile(draws,[.025,.975]).tolist()
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path(__file__).parent/'replay');p.add_argument('--out',type=Path,default=Path(__file__).parent/'replay_analysis');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(a.input/'run_totals.csv'); env=json.loads((a.input/'environment.json').read_text()); n=int(env['repetitions'])
    assert len(d)==129*n*2 and n==20
    assert ((d.completion_ns+d.requestwork_ns)==d.suffix_ns).all()
    out=[]
    for (wid,engine),g in d.groupby(['workload_id','engine']):
        I=g[g['mode']=='internal_'+engine].set_index('repeat').sort_index();B=g[g['mode']=='bundled_'+engine].set_index('repeat').sort_index()
        assert list(I.index)==list(range(n)) and I.shape[0]==B.shape[0]
        assert (I.order_in_pair+B.order_in_pair==1).all() and (I.order_in_pair==0).sum()==10
        rec=dict(workload_id=wid,engine=engine,corpus=g.corpus.iloc[0],source_map=g.source_map.iloc[0],completion_request=int(g.completion_request.iloc[0]),pairs=n)
        for metric in ['suffix_ns','completion_ns','requestwork_ns']:
            rec[metric+'_ratio']=float(I[metric].median()/B[metric].median())
            wins=int((I[metric]<B[metric]).sum());rec[metric+'_wins']=wins
            rec[metric+'_paired_median_difference_ms']=float(np.median(I[metric]-B[metric])/1e6)
        for order in [0,1]:
            ix=I.index[I.order_in_pair==order];rec[f'suffix_ratio_internal_order{order}']=float(I.loc[ix,'suffix_ns'].median()/B.loc[ix,'suffix_ns'].median())
        rec['order_strata_agree']=(rec['suffix_ratio_internal_order0']<1)==(rec['suffix_ratio_internal_order1']<1)
        out.append(rec)
    w=pd.DataFrame(out);w.to_csv(a.out/'workload_summary.csv',index=False)
    rng=np.random.default_rng(20261105); summaries=[]
    for (eng,corpus),g in w.groupby(['engine','corpus']):
        rec=dict(engine=eng,corpus=corpus,workloads=len(g),source_maps=g.source_map.nunique(),median_suffix_ratio=float(g.suffix_ns_ratio.median()),faster=int((g.suffix_ns_ratio<1).sum()),all20_wins=int((g.suffix_ns_wins==20).sum()),all20_losses=int((g.suffix_ns_wins==0).sum()),mixed=int(((g.suffix_ns_wins>0)&(g.suffix_ns_wins<20)).sum()),order_strata_agree=int(g.order_strata_agree.sum()),median_requestwork_ratio=float(g.requestwork_ns_ratio.median()),median_completion_ratio=float(g.completion_ns_ratio.median()))
        rec['ci_low'],rec['ci_high']=cluster_ci(g,'suffix_ns_ratio',rng)
        summaries.append(rec)
    s=pd.DataFrame(summaries);s.to_csv(a.out/'group_summary.csv',index=False)
    # Reconstruct recorded totals directly from raw per-query timings.
    q=pd.read_csv(a.input/'query_records.csv');sums=q.groupby(['workload_id','engine','repeat','mode']).agg(suffix_ns=('time_ns','sum'),completion_ns=('completion_ns','sum'),checks=('checks','sum'),scans=('scans','sum'))
    comp=d.set_index(['workload_id','engine','repeat','mode'])[sums.columns].sort_index();assert comp.equals(sums.sort_index())
    report=dict(input_hashes={x:sha(a.input/x) for x in ['run_totals.csv','query_records.csv','environment.json']},workloads=len(w),paired_repetitions=len(d)//2,timed_query_executions=len(q),all_raw_sums_match=True,balanced_pair_order=True,engine_summary=[])
    for eng,g in w.groupby('engine'):
        report['engine_summary'].append(dict(engine=eng,workloads=len(g),faster=int((g.suffix_ns_ratio<1).sum()),all20_wins=int((g.suffix_ns_wins==20).sum()),all20_losses=int((g.suffix_ns_wins==0).sum()),mixed=int(((g.suffix_ns_wins>0)&(g.suffix_ns_wins<20)).sum()),order_strata_agree=int(g.order_strata_agree.sum()),median_suffix_ratio=float(g.suffix_ns_ratio.median())))
    report['adverse_case']=w[(w.workload_id=='maprandomStartAndGoalSmall8__shifted')&(w.engine=='astar')].to_dict('records')
    (a.out/'REPLAY_ANALYSIS_CHECKS.json').write_text(json.dumps(report,indent=2));print(s.to_string(index=False));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
