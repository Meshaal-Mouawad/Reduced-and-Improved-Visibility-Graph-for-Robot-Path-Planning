# Focused timing follow-up: matched pre-completion checkpoints

Protocol fixed before the follow-up measurements. Trigger: the original three-run
phase analysis reveals a substantial common-prefix imbalance and mixed per-run
rankings. This experiment isolates the policy suffix; it does not replace the
original end-to-end timings or acquire new independent environments.

Population: every engine/workload pair for which deterministic count-triggered
completion occurred in the archived run: 60 restarted-A*, 34 query-local-LPA*,
and 35 retained-LPA* pairs (129 pairs in total). No timing-based selection.

Use the unchanged archived planner, geometry, requests, switch event and coefficient.
Construct one pre-event checkpoint for each pair by replaying all requests before
its recorded completion request. Restore independent deep copies for each policy.
Rebind the instrumented geometry method to each copy, so neither copy modifies the
checkpoint's counters or geometric state. Verify every recorded operation and route
length against the original first repetition; report any disagreement as failure.

At the checkpoint, change only the policy flag: bundled terminal attachment versus
on-demand terminal attachment. Execute the entire remaining query sequence, including
the same persistent-completion operation, separately for each copy. Perform one
unrecorded warm-up suffix per policy and 20 recorded paired repetitions. Each pair
uses consecutive suffix executions; balanced AB/BA order alternates across repetitions,
with the first order selected by a fixed seed (20261105). No adaptive stopping.

Pin the process to the first available logical CPU where permitted. Collect garbage
before each paired block and suspend cyclic collection while the paired suffixes run;
restore it afterward. Capture hardware description, Python/library versions, CPU
affinity, clock information, and hashes. Perform no concurrent computational analyses.

Retain each query's original instrumentation, including total and completion-block
nanoseconds, counters, route length, and state. For each run, sum suffix time, completion
time, and suffix request time excluding the timed completion block. Summarize by
ratio of each policy's median across 20 repetitions within a workload. Report
paired-repeat winner counts and the median of within-repeat differences. Aggregate
only at engine/corpus level; retain source-map clustering for interval estimation.
Include all adverse outcomes. Repetition counts are timing observations, not samples
of new maps. Original and follow-up environment/timings remain separate in the paper.
