#!/usr/bin/env python3
"""Find exact positive check prices at which a delayed switch beats both endpoints."""

import argparse
import csv
from fractions import Fraction
import hashlib
import json
from statistics import median
from pathlib import Path

import numpy as np
import pandas as pd


def strict_line_interval(slope, intercept):
    """Intersect slope * price + intercept < 0 with price > 0."""
    if slope == 0:
        return (Fraction(0), None) if intercept < 0 else None
    root = Fraction(-intercept, slope)
    if slope > 0:
        return (Fraction(0), root) if root > 0 else None
    return max(Fraction(0), root), None


def intersect(left, right):
    if left is None or right is None:
        return None
    lo = max(left[0], right[0])
    upper_bounds = [end for end in (left[1], right[1]) if end is not None]
    hi = min(upper_bounds) if upper_bounds else None
    return (lo, hi) if hi is None or lo < hi else None


def union(intervals):
    merged = []
    for lo, hi in sorted(intervals, key=lambda item: item[0]):
        if not merged or (merged[-1][1] is not None and lo >= merged[-1][1]):
            merged.append((lo, hi))
        elif merged[-1][1] is not None:
            old_lo, old_hi = merged[-1]
            merged[-1] = (old_lo, None if hi is None else max(old_hi, hi))
    return merged


def contains(intervals, price):
    return any(lo < price and (hi is None or price < hi) for lo, hi in intervals)


def printable(intervals):
    return [[str(lo), 'infinity' if hi is None else str(hi)] for lo, hi in intervals]


def check_entire_axis(lines, intervals):
    """Classify every rational crossing and one point in each open cell independently."""
    crossings = set()
    for _, checks, scans, check_diff, scan_diff in lines:
        for slope, intercept in ((checks, scans), (check_diff, scan_diff)):
            if slope and slope * intercept < 0:
                crossings.add(Fraction(-intercept, slope))
    probes = set(crossings)
    prev = Fraction(0)
    for root in sorted(crossings):
        probes.add((prev + root) / 2)
        prev = root
    probes.add(prev + 1)
    for price in probes:
        num, den = price.numerator, price.denominator
        direct = any(
            num * checks + den * scans < 0
            and num * check_diff + den * scan_diff < 0
            for _, checks, scans, check_diff, scan_diff in lines
        )
        if direct != contains(intervals, price):
            raise AssertionError((price, intervals, lines))
    return len(probes)


def final_horizon_magnitude(switch_lines, lazy_checks, lazy_visits):
    """Supremum gain against the better endpoint over positive prices, including limits."""
    base_checks, base_visits = switch_lines[0][1:]
    # The better endpoint changes only at this potential crossing. On each side
    # each date's fractional gain is a ratio of two affine functions of price.
    # Its derivative has constant sign. Interior probes detect flat maxima.
    tests = [('zero_limit', Fraction(0)), ('infinity_limit', None)]
    crossing = Fraction(-base_visits, base_checks) if base_checks else Fraction(0)
    if crossing > 0:
        tests.extend([('positive_price', crossing / 2),
                      ('positive_price', crossing),
                      ('positive_price', crossing + 1)])
    else:
        tests.append(('positive_price', Fraction(1)))
    best = Fraction(0)
    best_type, best_price, best_k = 'no_strict_gain', '', None
    for kind, price in tests:
        if price is None:
            cost = lambda checks, visits: Fraction(checks)
        else:
            cost = lambda checks, visits: price * checks + visits
        endpoint = min(cost(lazy_checks, lazy_visits),
                       cost(lazy_checks + base_checks, lazy_visits + base_visits))
        if endpoint <= 0:
            raise ValueError('Endpoint work must be positive to define fractional gain')
        for k, checks, visits in switch_lines[1:]:
            conditional = cost(lazy_checks + checks, lazy_visits + visits)
            gain = (endpoint - conditional) / endpoint
            if gain <= 0:
                continue
            prefer_attained = gain == best and kind == 'positive_price' and best_type != 'positive_price'
            if gain > best or prefer_attained or (gain == best and kind == best_type and k > best_k):
                best, best_type, best_price, best_k = gain, kind, (str(price) if price is not None else 'infinity'), k
    all_add_checks = all(checks > 0 for _, checks, _ in switch_lines)
    cutoff = None
    if all_add_checks:
        cutoff = max([Fraction(0)] + [Fraction(-visits, checks) for _, checks, visits in switch_lines if visits < 0])
    return dict(h40_supremum_gain_exact=str(best), h40_supremum_gain_fraction=float(best),
                h40_supremum_location=best_type, h40_supremum_price=best_price,
                h40_supremum_completion_request=best_k,
                h40_all_delays_including_upfront_add_checks=all_add_checks,
                h40_best_check_price_cutoff_exact=str(cutoff) if cutoff is not None else '')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    coefficients = args.root / 'results/all_switch_coefficients.csv'
    output = args.root / 'analysis'
    output.mkdir(exist_ok=True)
    data = pd.read_csv(coefficients)
    trace_path = args.root / 'results/traces.csv'
    trace = pd.read_csv(trace_path, usecols=['workload_id', 'engine', 'policy', 'checks', 'scans'])
    lazy_totals = trace[trace.policy == 'lazy'].groupby(['workload_id', 'engine'])[['checks', 'scans']].sum()
    keys = ['workload_id', 'engine', 'horizon']
    identity = ['setup_id', 'source_map', 'corpus', 'family', 'regime']
    prices = sorted({
        Fraction(str(float(x))) for x in np.geomspace(1, 10000, 81)
    } | {Fraction(x) for x in (4, 16, 64, 256, 1024)})
    rows = []
    for (workload, engine, horizon), group in data.groupby(keys, sort=True):
        group = group.sort_values('completion_request')
        positions = group.completion_request.tolist()
        if positions != list(range(1, int(horizon) + 1)):
            raise ValueError((workload, engine, horizon, positions))
        data_rows = group.itertuples(index=False)
        first = next(data_rows)
        upfront_checks = int(first.stranded_checks + first.terminal_delta)
        upfront_scans = int(first.scan_delta)
        lines = []
        feasible_by_date = {}
        for row in data_rows:
            checks = int(row.stranded_checks + row.terminal_delta)
            scans = int(row.scan_delta)
            check_diff = checks - upfront_checks
            scan_diff = scans - upfront_scans
            date = int(row.completion_request)
            lines.append((date, checks, scans, check_diff, scan_diff))
            feasible = intersect(
                strict_line_interval(checks, scans),
                strict_line_interval(check_diff, scan_diff),
            )
            if feasible is not None:
                feasible_by_date[date] = feasible
        intervals = union(feasible_by_date.values())
        probes = check_entire_axis(lines, intervals)
        magnitude = {}
        if int(horizon) == 40:
            totals = lazy_totals.loc[(workload, engine)]
            switch_lines = [(1, upfront_checks, upfront_scans)] + [
                (date, checks, scans) for date, checks, scans, _, _ in lines
            ]
            magnitude = final_horizon_magnitude(switch_lines, int(totals.checks), int(totals.scans))
            if (Fraction(magnitude['h40_supremum_gain_exact']) > 0) != bool(intervals):
                raise AssertionError(('interval and maximal gain disagree', workload, engine))
        intersects_primary_range = any(
            hi is None or hi > 1
            for lo, hi in intervals if lo < 10000
        )
        rows.append(dict(
            workload_id=workload,
            engine=engine,
            **{key: getattr(first, key) for key in identity},
            horizon=int(horizon),
            any_strictly_better_delayed_date=bool(intervals),
            strictly_better_at_any_sampled_price=any(contains(intervals, price) for price in prices),
            intersects_continuous_price_range_1_to_10000=intersects_primary_range,
            positive_price_open_intervals=json.dumps(printable(intervals), separators=(',', ':')),
            feasible_date_intervals=json.dumps(
                {str(k): printable([i])[0] for k, i in feasible_by_date.items()},
                separators=(',', ':'),
            ),
            verified_crossings_and_cells=probes,
            **magnitude,
        ))
    with (output / 'exact_interior_intervals.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(dict.fromkeys(key for row in rows for key in row)))
        writer.writeheader()
        writer.writerows(rows)
    results = pd.DataFrame(rows)
    summary = {
        'comparator': 'strictly lower modeled work than both never completing and completing before request 1',
        'domain': 'positive check prices, scan price 1, all stored interval endpoints are open',
        'unit': 'one workload, one engine, one horizon',
        'sampled_prices': len(prices),
        'affine_coefficients_sha256': hashlib.sha256(coefficients.read_bytes()).hexdigest(),
        'canonical_traces_sha256': hashlib.sha256(trace_path.read_bytes()).hexdigest(),
        'analysis_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'all_horizon_observations': len(results),
        'verified_crossings_and_complementary_open_cells': int(results.verified_crossings_and_cells.sum()),
        'by_engine': {},
    }
    for engine, group in results.groupby('engine'):
        record = {}
        for label, selected in [('all_horizons', group), ('horizon_40', group[group.horizon == 40])]:
            exact = selected.any_strictly_better_delayed_date
            grid = selected.strictly_better_at_any_sampled_price
            within = selected.intersects_continuous_price_range_1_to_10000
            if (grid & ~within).any() or (within & ~exact).any():
                raise AssertionError('grid and continuum ordering')
            record[label] = dict(
                workload_horizons=len(selected),
                unique_workloads=selected.workload_id.nunique(),
                exact_strictly_profitable_interior_workload_horizons=int(exact.sum()),
                distinct_workloads_with_at_least_one_interior_gain=int(selected.loc[exact, 'workload_id'].nunique()),
                captured_by_sampled_prices=int(grid.sum()),
                positive_intervals_entirely_outside_1_to_10000=int((exact & ~within).sum()),
                intervals_inside_range_missed_by_all_sampled_prices=int((within & ~grid).sum()),
            )
        at_end = group[group.horizon == 40]
        gains = [Fraction(x) for x in at_end.h40_supremum_gain_exact]
        profitable_gains = [x for x in gains if x > 0]
        max_gain = max(gains)
        maximizing = at_end[at_end.h40_supremum_gain_exact == str(max_gain)]
        positive_rows = at_end[at_end.any_strictly_better_delayed_date]
        record['horizon_40'].update(
            maximum_fractional_gain_supremum_exact=str(max_gain),
            maximum_fractional_gain_supremum=float(max_gain),
            median_fractional_gain_supremum_among_profitable_exact=str(median(profitable_gains)) if profitable_gains else None,
            median_fractional_gain_supremum_among_profitable=float(median(profitable_gains)) if profitable_gains else None,
            workload_suprema_reached_at_positive_price=int((positive_rows.h40_supremum_location == 'positive_price').sum()),
            workload_suprema_only_at_zero_limit=int((positive_rows.h40_supremum_location == 'zero_limit').sum()),
            workload_suprema_only_at_infinity_limit=int((positive_rows.h40_supremum_location == 'infinity_limit').sum()),
            maximizing_workloads=maximizing.workload_id.tolist(),
        )
        if at_end.h40_all_delays_including_upfront_add_checks.all():
            cutoffs = [Fraction(x) for x in at_end.h40_best_check_price_cutoff_exact]
            record['horizon_40'].update(
                all_switches_add_checks_in_all_workloads=True,
                profitable_completion_cutoff_median_exact=str(median(cutoffs)),
                profitable_completion_cutoff_median=float(median(cutoffs)),
                profitable_completion_cutoff_maximum_exact=str(max(cutoffs)),
                profitable_completion_cutoff_maximum=float(max(cutoffs)),
                workloads_with_zero_cutoff=sum(value == 0 for value in cutoffs),
            )
        summary['by_engine'][engine] = record
    (output / 'EXACT_INTERIOR_SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
