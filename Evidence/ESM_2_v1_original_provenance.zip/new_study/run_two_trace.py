#!/usr/bin/env python3
"""Execute deterministic two-trace study and exhaustive completion-position checks."""
from pathlib import Path
import argparse, copy, csv, datetime, hashlib, importlib.metadata, json, math, platform, sys, time
import pandas as pd

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def clone(checkpoint):
    visible = checkpoint.geom.__dict__.pop('visible')
    try:
        result = copy.deepcopy(checkpoint)
    finally:
        checkpoint.geom.visible = visible
    original = result.geom.visible
    def timed_visible(a, b):
        begin = time.perf_counter_ns()
        value = original(a, b)
        result.check_ns += time.perf_counter_ns() - begin
        result.num_timed_checks += 1
        return value
    result.geom.visible = timed_visible
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--study', type=Path, default=Path(__file__).resolve().parents[1]/'baseline/evidence/study')
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent/'results')
    args = parser.parse_args()
    if (args.out/'traces.csv').exists():
        raise SystemExit('Choose a new output directory; recorded evidence is never overwritten.')
    args.out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(args.study.resolve()))
    from planners import Planner
    cases = json.loads((args.study/'inputs.json').read_text())
    refs = pd.read_csv(args.study/'results/reference_lengths.csv').set_index(['workload_id','index']).length.to_dict()
    archived = pd.read_csv(args.study/'results/queries.csv')
    archived = archived[(archived['repeat']==0)&archived['mode'].isin(['lazy_astar','lazy_lpa_query'])]
    old = archived.set_index(['workload_id','mode','index']).to_dict('index')
    service_fields = ['terminal_checks','terminal_candidates','pops','scans','rhs_updates','pushes','search_calls','extra_pops']
    archived_fields = service_fields + ['persistent_checks','checks','unknown']
    keep = archived_fields + ['complete','completion_checks','status','length']
    started = time.perf_counter()
    env = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               python=sys.version, platform=platform.platform(),
               packages={name:importlib.metadata.version(name) for name in ['numpy','pandas']},
               protocol_sha256=sha(Path(__file__).with_name('PROTOCOL.md')),
               driver_sha256=sha(__file__),planner_sha256=sha(args.study/'planners.py'),
               geometry_sha256=sha(args.study/'planner_core.py'),inputs_sha256=sha(args.study/'inputs.json'),
               purpose='deterministic operation counts; no new runtime comparison')
    (args.out/'environment.json').write_text(json.dumps(env, indent=2))
    traces=[]; vertices=[]; checks=[]
    verification=dict(workloads=0,reference_route_comparisons=0,archive_counter_equalities=0,
                      post_completion_service_equalities=0,horizon_coefficient_equalities=0,
                      completion_branches=0,branch_query_executions=0,failures=[])
    for ci, case in enumerate(cases):
        for engine in ['astar','lpa_query']:
            ident=dict(workload_id=case['workload_id'],setup_id=case['setup_id'],source_map=case['source_map'],
                       corpus=case['corpus'],family=case['family'],regime=case['regime'],engine=engine)
            lazy=Planner(case['obstacles'],'lazy_'+engine)
            full=Planner(case['obstacles'],'lazy_'+engine);full.pending=True
            m=lazy.initial_candidates
            checkpoints=[];L=[];F=[]
            for i,q in enumerate(case['queries']):
                checkpoints.append(clone(lazy))
                for policy,planner,records in [('lazy',lazy,L),('complete',full,F)]:
                    row=planner.query(q['start'],q['goal'],i);records.append(row)
                    assert math.isclose(row['length'],refs[(case['workload_id'],i)],rel_tol=1e-9,abs_tol=1e-8),(ident,policy,i,'length')
                    verification['reference_route_comparisons']+=1
                    traces.append(dict(**ident,policy=policy,index=i,initial_candidates=m,**{k:row[k] for k in keep}))
                    if policy=='lazy':
                        reference=old[(case['workload_id'],'lazy_'+engine,i)]
                        for key in archived_fields:
                            assert row[key]==reference[key],(ident,i,key,row[key],reference[key])
                            verification['archive_counter_equalities']+=1
            for k,checkpoint in enumerate(checkpoints):
                branch=clone(checkpoint);branch.pending=True
                persistent=sum(x['persistent_checks'] for x in L[:k])
                terminal_delta=scan_delta=0
                before=(checkpoint.geom.checks,dict(checkpoint.known))
                for i in range(k,len(case['queries'])):
                    q=case['queries'][i]
                    row=branch.query(q['start'],q['goal'],i)
                    assert math.isclose(row['length'],refs[(case['workload_id'],i)],rel_tol=1e-9,abs_tol=1e-8),(ident,k,i,'branch length')
                    verification['reference_route_comparisons']+=1;verification['branch_query_executions']+=1
                    for key in service_fields:
                        assert row[key]==F[i][key],(ident,k,i,key,row[key],F[i][key])
                        verification['post_completion_service_equalities']+=1
                    persistent+=row['persistent_checks']
                    terminal_delta+=row['terminal_checks']-L[i]['terminal_checks']
                    scan_delta+=row['scans']-L[i]['scans']
                    expected_p=L[i]['unknown']
                    observed_p=persistent-sum(x['persistent_checks'] for x in L[:i+1])
                    expected_t=sum(F[j]['terminal_checks']-L[j]['terminal_checks'] for j in range(k,i+1))
                    expected_a=sum(F[j]['scans']-L[j]['scans'] for j in range(k,i+1))
                    assert (observed_p,terminal_delta,scan_delta)==(expected_p,expected_t,expected_a),(ident,k,i,'identity')
                    verification['horizon_coefficient_equalities']+=3
                    vertices.append(dict(**ident,completion_request=k+1,horizon=i+1,
                                         unresolved_at_completion=L[k-1]['unknown'] if k else m,
                                         stranded_checks=expected_p,terminal_delta=expected_t,scan_delta=expected_a))
                assert before==(checkpoint.geom.checks,dict(checkpoint.known)),(ident,k,'checkpoint modified')
                verification['completion_branches']+=1
                checks.append(dict(**ident,completion_request=k+1,suffix_queries=len(case['queries'])-k,
                                   service_fields_checked=len(service_fields),all_service_fields_equal=True,
                                   all_lengths_equal=True,all_horizon_coefficients_equal=True))
            verification['workloads']+=1
            print(f"{verification['workloads']}/432 {engine} {case['workload_id']} {time.perf_counter()-started:.1f}s",flush=True)
        if (ci+1)%12==0:
            (args.out/'progress.json').write_text(json.dumps(verification,indent=2))
    pd.DataFrame(traces).to_csv(args.out/'traces.csv',index=False)
    pd.DataFrame(vertices).to_csv(args.out/'all_switch_coefficients.csv',index=False)
    pd.DataFrame(checks).to_csv(args.out/'exhaustive_verification.csv',index=False)
    env.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.perf_counter()-started,
               distinct_original_queries=len(refs),two_trace_query_executions=len(traces),operation_trace_count=verification['workloads']*2)
    verification.update(all_checks_pass=True,derived_workload_engine_combinations=verification.pop('workloads'))
    (args.out/'environment.json').write_text(json.dumps(env,indent=2))
    (args.out/'VERIFICATION.json').write_text(json.dumps(verification,indent=2))
    print(json.dumps(verification,indent=2))

if __name__=='__main__':
    main()
