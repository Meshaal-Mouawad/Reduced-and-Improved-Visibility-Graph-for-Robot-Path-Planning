from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

OUT=Path(__file__).resolve().parents[1]/'manuscript/figures'
plt.rcParams.update({'font.family':'Liberation Sans','font.size':8.5,'svg.fonttype':'none','pdf.fonttype':42})
NAVY='#294659'; TEAL='#367f85'; AMBER='#a15b20'; INK='#263b47'; GRAY='#60737d'
fig,ax=plt.subplots(figsize=(6.3,3.05));fig.subplots_adjust(0.025,0.035,.985,.99)
ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
x0=.30;step=.081;h=.092
for j in range(8):ax.text(x0+(j+.5)*step,.95,str(j+1),ha='center',va='center',color=GRAY)
ax.text(.005,.95,'Query',color=GRAY,va='center')
for y,label,kind in [(.78,'Lazy reference  L','L'),(.60,'Completed reference  F','F'),(.36,'Complete before query 4','mix')]:
 ax.text(.005,y+h/2,label,va='center',color=INK)
 for j in range(8):
  which='L' if kind=='L' or (kind=='mix' and j<3) else 'F'
  color=NAVY if which=='L' else TEAL
  ax.add_patch(Rectangle((x0+j*step,y),step-.010,h,facecolor=color,edgecolor='none',alpha=1.0))
  ax.text(x0+(j+.5)*step-.005,y+h/2,f'{which}{j+1}',ha='center',va='center',color='white')
ax.annotate('',xy=(x0+3*step-.005,.345),xytext=(x0+3*step-.005,.53),arrowprops={'arrowstyle':'-|>','lw':.9,'color':AMBER})
ax.text(x0+3*step+.017,.50,'Shared graph becomes fully checked',va='center',color=AMBER,fontsize=8)
ax.text(x0+1.5*step-.005,.295,'Lazy prefix',ha='center',va='center',color=NAVY)
ax.text(x0+5.5*step-.005,.295,'Completed-graph suffix',ha='center',va='center',color=TEAL)
ax.plot([0,1],[.235,.235],color='#d9e2e6',lw=.7)
ax.text(.005,.16,'Extra persistent checks',va='center',color=INK)
ax.text(.30,.16,r'$c_P U_H$',va='center',color=AMBER,fontsize=11)
ax.text(.44,.16,'Checks never demanded by the lazy reference',va='center',color=INK,fontsize=8)
ax.text(.005,.055,'Minus suffix service savings',va='center',color=INK)
ax.text(.30,.055,r'$\sum_{i=k}^{H} d_i$',va='center',color=TEAL,fontsize=11)
ax.text(.44,.055,'Terminal checks + adjacency/repair visits saved',va='center',color=INK,fontsize=8)
OUT.mkdir(exist_ok=True,parents=True)
for ext in ['pdf','svg','png']:
 fig.savefig(OUT/f'two_trace_mechanism.{ext}',dpi=250,metadata={'Creator':'Matplotlib; reproducible code-rendered schematic'} if ext=='pdf' else None)
plt.close(fig)
