# Online Resource 2: two-trace completion study

This resource reproduces the finite-horizon collision-check and search-work comparisons in *When Roadmap Completion Pays Off*. It contains the two canonical traces, all directly tested switch positions, exact favorable cost intervals and the scripts for the new manuscript figures and table. The original study data, geometry and planner implementations are deposited separately as Online Resource 1.

## Verify the download

Extract `ESM_2.zip` and run these commands from the directory containing `new_study/`. Verification requires Python 3.11 or later and uses only its standard library.

```sh
python new_study/reproduce.py --verify
```

The helper checks every listed file against the supplied `MANIFEST_SHA256.json`. Each key is a file path relative to the manifest's directory and each value is its SHA-256. The manifest excludes itself. The helper accepts a manifest beside the script or at the root of the extracted archive. To supply another copy explicitly, pass `--manifest /path/to/MANIFEST_SHA256.json`.

## Reproduce the results

The recorded environment used CPython 3.12.14, NumPy 2.3.5, pandas 2.2.3 and Matplotlib 3.10.8. The figures were rendered with Liberation Sans. Place the original `ESM_1.zip` alongside `new_study/`, or pass its actual path. The required archive is byte-identical to `Robotica_Computational_Supplement_v10.zip`. Its SHA-256 is `6eeb0f605d4081b9a9e2acd157e88ecdfaf5eba09c73fdeb00df1c0a86ff962c`.

```sh
python -m pip install -r new_study/REQUIREMENTS.txt
python new_study/reproduce.py --analysis --baseline-zip ESM_1.zip --out replay-analysis
```

The output directory must be new. The helper checks the ESM_1 archive hash, extracts it under `baseline/evidence/`, and checks its own embedded file manifest. It stages the ESM_2 scripts and raw operation records under `new_study/` in the output directory. It recalculates the frontier analysis, rational interval comparisons, gain suprema and publication exhibits. See the regenerated CSVs in `new_study/analysis/`, figures in `manuscript/figures/`, the LaTeX table in `manuscript/tables/` and individual script logs in `logs/`. The helper compares eight core CSV files with the deposit byte for byte and writes their checksums to `REPRODUCTION_REPORT.json`. Figures are regenerated from those numerical records. File generation dates and installed font versions can affect the bytes of rendered images.

To repeat the direct experiments as well, use a different new output directory.

```sh
python new_study/reproduce.py --full --baseline-zip ESM_1.zip --out replay-full
```

This option calls the deposited `run_two_trace.py` against the original planner sources, then runs the same analyses. It compares the three regenerated raw CSVs and the eight analysis CSVs with their deposited hashes. The original direct experiment took approximately 13 minutes on the recorded host. The environment timestamp and duration identify each fresh run. Both modes use data already present in the two archives and perform the reproduction locally.

## Read the records

| File or field | Meaning |
|---|---|
| `PROTOCOL.md`, `COUNTER_SEMANTICS_ERRATUM.md` | Dated experimental plan and clarification of the LPA* work counter. |
| `results/traces.csv` | Two canonical traces per workload and engine. `lazy` retains previous validations and defers unknown checks. `complete` validates remaining persistent edges before the first query and checks terminals lazily. `index` is zero-based. |
| `results/all_switch_coefficients.csv` | One row for each tested completion date and horizon. `completion_request` and `horizon` are one-based. A completion request of 1 means that completion precedes the first query. Signed terminal and visit coefficients use switched minus permanent-lazy work. |
| `results/exhaustive_verification.csv`, `results/VERIFICATION.json` | Direct verification records and aggregate equality counts. The historical field name `reference_route_comparisons` counts comparisons of returned **lengths** with independent reference lengths. All 388,800 lengths matched. |
| `analysis/exact_frontiers.csv`, `analysis/trigger_stranded_work.csv` | Forty-query completion cutoffs by workload and the portion of each recorded trigger's persistent checks that remain unqueried by the lazy baseline at horizon 40. |
| `analysis/exact_interior_intervals.csv`, `analysis/EXACT_INTERIOR_SUMMARY.json` | Open positive-price intervals on which a delayed date beats both upfront completion and permanent laziness. At horizon 40 the CSV also gives the fractional-gain supremum and whether a limiting price is required. |
| `analysis/horizon_weight_results.csv`, `analysis/grid_group_summary.csv` | Individual results for the 86 sampled prices at horizon 40 and group-level results across all 40 horizons. |
| `results/environment.json` | Original execution environment and SHA-256 hashes of the protocol, direct driver, planner, geometry routine and immutable workload inputs. |

The cost model prices persistent checks, terminal checks and the recorded search/repair visits. In the main sensitivity analysis one collision check has price ρ and one visit has price one. The original three-repeat and matched-checkpoint elapsed-time results are supplied in Online Resource 1.
