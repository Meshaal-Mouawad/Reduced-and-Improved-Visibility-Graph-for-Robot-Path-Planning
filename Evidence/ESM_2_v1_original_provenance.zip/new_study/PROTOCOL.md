# Two-trace completion analysis

Protocol fixed on 18 November 2026 before executing this extension. The frozen
ROBOTICA-PQV-v10 input corpus and planner sources remain unchanged.

## Scientific question

For a finite sequence of queries, when can completing every still-unknown
persistent roadmap edge repay the unused persistent checks through reduced
subsequent terminal checking and graph-search work? Separate the existence of
a favorable completion point from a controller's choice of that point.

## Population and interventions

Use all 216 archived forty-query workloads, separately for restarted A* and
query-local LPA*. Both engines initialize distance labels on each new query.
Retained LPA* is excluded from the trace-splicing proposition because its
post-completion search state depends on its history. Its historical empirical
comparisons remain in the manuscript.

For each engine and workload, record two deterministic operation traces:

1. Permanent lazy validation, with persistent collision states retained.
2. Complete all persistent candidates before query 1, retaining lazy terminal
   validation thereafter.

Both traces use the same immutable inputs, candidate graph, collision predicate,
Euclidean objective, forward selector, adjacency storage and tie ordering.
Completion is requested by setting the archived planner's existing pending flag;
no path-search or collision code is changed. Operation records, rather than new
wall-clock rankings, are the evidence of this extension.

## Exact work model and complete validation

Define work as c_P P + c_T T + c_A A, where P counts persistent collision tests,
T counts terminal collision tests and A counts stored adjacency inspections.
Weights are nonnegative costs per named operation; they are declared model
parameters, not fitted hardware times. Retain all other operation counters for
checking the stronger post-completion trace equality.

For every completion request k=1,...,40, independently execute the intervention
from the permanently lazy checkpoint immediately before k, then serve all
remaining requests. Compare every suffix query with the fully completed trace
on terminal checks, candidate counts, search calls, vertex processings, adjacency
inspections, distance updates and queue insertions. Compare all returned lengths
with the frozen independent full-visibility references. For every horizon H>=k,
check the derived persistent/terminal/adjacency identities separately as exact
integers. This is exhaustive validation over the corpus's switch positions, not
a sample of successful examples. Preserve every discrepancy as a failure.

## Analysis fixed before inspection of outputs

For each horizon and nonnegative work-weight choice, compute all completion
costs using the two traces, retain permanent laziness as the no-completion
option, and identify minimum modeled work (ties resolved toward no completion,
then latest completion). Compare the archived alpha=4 count rule to this
hindsight reference; no future information is supplied to that online rule.

Primary display: equal persistent/terminal test weights, normalized adjacency
inspection cost 1, collision-test costs on a logarithmic grid from 1 to 10000
(81 points). This is a transparent sensitivity grid, not an estimate of an
actual collision-test price. Report the exact feasible cost interval, computed
from the affine inequalities, in addition to grid-based displays. Publish the
separate three-coefficient representation so users can select unequal persistent
and terminal costs. Report original corpus groups and all three query regimes
separately. Fixed-square settings remain derived, not new independent maps.

At H=40, report persistent checks never demanded by lazy continuation, their
fraction of the candidates remaining at the archived trigger, sign of total
collision and adjacency changes, whether any completion position is favorable,
and controller regret relative to the hindsight minimum. Report all unfavorable
and null outcomes. Do not infer an online optimal policy or hardware runtime
guarantee from this deterministic operation model.

## Reproducibility

Store source/input hashes, actual execution environment, two traces, all-switch
verification records, integer identity counts and analysis code. The extension
has its own dated release and never replaces the original timing records.
