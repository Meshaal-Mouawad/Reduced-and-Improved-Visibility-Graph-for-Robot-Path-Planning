#!/usr/bin/env python3
"""Exact coefficients, feasibility frontiers, and hindsight comparisons."""
from pathlib import Path
from fractions import Fraction
import argparse, json, math
import numpy as np
import pandas as pd

def exact_intervals(frame):
    intervals=[]
    for row in frame.itertuples():
        dc=int(row.stranded_checks+row.terminal_delta); da=int(row.scan_delta)
        if dc==0:
            if da<0: intervals.append((Fraction(0),None))
        elif dc>0:
            if da<0: intervals.append((Fraction(0),Fraction(-da,dc)))
        else:
            intervals.append((max(Fraction(0),Fraction(-da,dc)),None))
    intervals.sort(key=lambda z:z[0]);merged=[]
    for lo,hi in intervals:
        if not merged or (merged[-1][1] is not None and lo>=merged[-1][1]):merged.append([lo,hi])
        else:
            if hi is None or merged[-1][1] is None:merged[-1][1]=None
            else:merged[-1][1]=max(merged[-1][1],hi)
    return [[str(lo),str(hi) if hi is not None else 'infinity'] for lo,hi in merged]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args()
    out=a.root/'analysis';out.mkdir(exist_ok=True)
    trace=pd.read_csv(a.root/'results/traces.csv');coef=pd.read_csv(a.root/'results/all_switch_coefficients.csv')
    old=pd.read_csv(a.root.parent/'baseline/evidence/study/results/queries.csv')
    old=old[(old['repeat']==0)&old['mode'].isin(['internal_astar','internal_lpa_query'])]
    old['engine']=old['mode'].str.removeprefix('internal_')
    switches=old.groupby(['workload_id','engine']).switch_request.max().to_dict()
    keys=['workload_id','engine'];ids=['setup_id','source_map','corpus','family','regime']
    limits=[];grid=[];triggered=[];prefix=[]; grouped={}; total_grid_rows=0
    weights=np.unique(np.concatenate([np.geomspace(1,10000,81),np.array([4,16,64,256,1024])]))
    cumulative={(w,e):f.sort_values('index')[['checks','scans']].cumsum().to_numpy() for (w,e),f in trace[trace.policy=='lazy'].groupby(keys)}
    total_trace=trace.groupby(keys+['policy']).agg(P=('persistent_checks','sum'),T=('terminal_checks','sum'),A=('scans','sum'))
    for (workload,engine),f in coef.groupby(keys,sort=True):
        meta={x:f.iloc[0][x] for x in ids};base=dict(workload_id=workload,engine=engine,**meta)
        f40=f[f.horizon==40].sort_values('completion_request');k=f40.completion_request.to_numpy()
        dc=(f40.stranded_checks+f40.terminal_delta).to_numpy(dtype=np.int64);da=f40.scan_delta.to_numpy(dtype=np.int64)
        cstar=max([Fraction(-int(y),int(x)) for x,y in zip(dc,da) if x>0 and y<0]+[Fraction(0)])
        ks=switches[(workload,engine)];ks=None if pd.isna(ks) else int(ks)
        allpos=bool(np.all(dc>0));feasible=exact_intervals(f40)
        lazy=total_trace.loc[(workload,engine,'lazy')]
        row=dict(**base,initial_candidates=int(f40.iloc[0].unresolved_at_completion),lazy_persistent_checks=int(lazy.P),
                 stranded_checks=int(f40.iloc[0].stranded_checks),minimum_delta_checks=int(dc.min()),maximum_delta_checks=int(dc.max()),
                 all_switches_more_total_checks=allpos,any_switch_fewer_scans=bool((da<0).any()),
                 critical_check_price=float(cstar) if allpos else math.nan,
                 critical_exact=str(cstar) if allpos else 'use interval set',
                 favorable_positive_weight_intervals=json.dumps(feasible),
                 count_completion_request=ks)
        limits.append(row)
        if ks is not None:
            rr=f40[f40.completion_request==ks].iloc[0]
            cd=int(rr.stranded_checks+rr.terminal_delta);ad=int(rr.scan_delta)
            triggered.append(dict(**base,completion_request=ks,remaining_checks=int(rr.unresolved_at_completion),
                                  stranded_checks=int(rr.stranded_checks),stranded_fraction=rr.stranded_checks/rr.unresolved_at_completion,
                                  terminal_delta=int(rr.terminal_delta),check_delta=cd,scan_delta=ad,
                                  pareto_dominated=cd>=0 and ad>=0 and (cd>0 or ad>0),
                                  critical_check_price=(-ad/cd if cd>0 and ad<0 else 0) if cd>0 else math.nan))
        for horizon,fh in f.groupby('horizon',sort=True):
            fh=fh.sort_values('completion_request');kk=fh.completion_request.to_numpy()
            cc=(fh.stranded_checks+fh.terminal_delta).to_numpy(dtype=np.int64);aa=fh.scan_delta.to_numpy(dtype=np.int64)
            lazy_checks,lazy_scans=map(int,cumulative[(workload,engine)][int(horizon)-1])
            for weight in weights:
                delta=weight*cc+aa
                best_delta=min(0.,float(delta.min()))
                tol=1e-10*max(1.,abs(best_delta),abs(float(delta[0])))
                best=0 if best_delta>=-tol else int(kk[np.flatnonzero(np.abs(delta-best_delta)<=tol)[-1]])
                endpoint_delta=min(0.,float(delta[0]))
                trigger_delta=0. if ks is None or ks>horizon else float(delta[np.flatnonzero(kk==ks)[0]])
                lazy_work=weight*lazy_checks+lazy_scans
                oracle_work=lazy_work+best_delta
                assert oracle_work>0
                entry=dict(**base,horizon=int(horizon),check_price=float(weight),best_completion_request=best,
                                 any_completion_benefits=best_delta < -tol,
                                 interior_strictly_better=best_delta<endpoint_delta-tol,
                                 oracle_gain_fraction=-best_delta/lazy_work,
                                 interior_gain_fraction=(endpoint_delta-best_delta)/(lazy_work+endpoint_delta),
                                 count_rule_regret_fraction=(trigger_delta-best_delta)/oracle_work,
                                 endpoint_rule_regret_fraction=(endpoint_delta-best_delta)/oracle_work,
                                 count_rule_worse_than_lazy=trigger_delta>tol,
                                 count_rule_completes=ks is not None and ks<=horizon)
                total_grid_rows+=1
                if horizon==40:grid.append(entry)
                groupkey=(engine,meta['corpus'],meta['regime'],int(horizon),float(weight))
                grouped.setdefault(groupkey,[]).append((entry['any_completion_benefits'],entry['interior_strictly_better'],entry['oracle_gain_fraction'],entry['count_rule_regret_fraction'],entry['count_rule_worse_than_lazy']))
    lim=pd.DataFrame(limits);tr=pd.DataFrame(triggered);gr=pd.DataFrame(grid)
    lim.to_csv(out/'exact_frontiers.csv',index=False);tr.to_csv(out/'trigger_stranded_work.csv',index=False)
    coverage=lim.assign(lazy_coverage=lim.lazy_persistent_checks/lim.initial_candidates)
    coverage_rows=[dict(engine=e,regime=r,workloads=len(f),median_validated_fraction=float(f.lazy_coverage.median())) for (e,r),f in coverage.groupby(['engine','regime'])]
    (out/'spatial_coverage.json').write_text(json.dumps(coverage_rows,indent=2))
    gr.to_csv(out/'horizon_weight_results.csv',index=False)
    group_rows=[]
    for key,values in grouped.items():
        ar=np.asarray(values,dtype=float)
        group_rows.append(dict(zip(['engine','corpus','regime','horizon','check_price'],key),
             workloads=len(ar),beneficial=int(ar[:,0].sum()),interior_beneficial=int(ar[:,1].sum()),
             median_gain=float(np.median(ar[:,2])),median_count_regret=float(np.median(ar[:,3])),
             maximum_count_regret=float(ar[:,3].max()),count_harms=int(ar[:,4].sum())))
    pd.DataFrame(group_rows).to_csv(out/'grid_group_summary.csv',index=False)
    tsummary=tr.groupby(['engine','corpus']).agg(workloads=('workload_id','size'),median_remaining=('remaining_checks','median'),
       median_stranded=('stranded_checks','median'),median_stranded_fraction=('stranded_fraction','median'),
       equal_terminals=('terminal_delta',lambda x:int((x==0).sum())),fewer_scans=('scan_delta',lambda x:int((x<0).sum())),
       dominated=('pareto_dominated','sum'),median_critical=('critical_check_price','median'))
    tsummary.to_csv(out/'trigger_group_summary.csv')
    fsummary=lim.groupby(['engine','corpus']).agg(workloads=('workload_id','size'),all_more_checks=('all_switches_more_total_checks','sum'),
       any_fewer_scans=('any_switch_fewer_scans','sum'),critical_median=('critical_check_price','median'),
       critical_q25=('critical_check_price',lambda x:x.quantile(.25)),critical_q75=('critical_check_price',lambda x:x.quantile(.75)))
    fsummary.to_csv(out/'frontier_group_summary.csv')
    final=gr[(gr.horizon==40)&gr.check_price.isin([1,4,16,64,256,1024,10000])]
    final.groupby(['engine','check_price']).agg(workloads=('workload_id','size'),beneficial=('any_completion_benefits','sum'),
        interior=('interior_strictly_better','sum'),max_interior_gain=('interior_gain_fraction','max'),
        median_count_regret=('count_rule_regret_fraction','median'),max_count_regret=('count_rule_regret_fraction','max')).to_csv(out/'weight_summary.csv')
    record=dict(workload_engine_pairs=len(lim),triggered_pairs=len(tr),all_switches_more_checks=int(lim.all_switches_more_total_checks.sum()),
                weights=weights.tolist(),grid_rows=total_grid_rows,retained_detailed_grid_rows=len(gr),horizons=40,maximum_horizon=40,
                interior_workload_engine_price_cases_at_40=int(gr[gr.interior_strictly_better].shape[0]),
                interior_unique_workload_engine_pairs_on_grid_at_40=int(gr[gr.interior_strictly_better][keys].drop_duplicates().shape[0]),
                all_source_groups_retained=True,weights_are_model_parameters=True)
    (out/'ANALYSIS_CHECKS.json').write_text(json.dumps(record,indent=2))
    print(fsummary.to_string());print(tsummary.to_string());print(pd.read_csv(out/'weight_summary.csv').to_string(index=False))

if __name__=='__main__': main()
