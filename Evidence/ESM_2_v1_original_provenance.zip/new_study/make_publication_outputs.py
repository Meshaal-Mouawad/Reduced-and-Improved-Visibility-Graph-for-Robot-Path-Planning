#!/usr/bin/env python3
"""Render exact, data-bound manuscript artwork and compact result tables."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch
from matplotlib.colors import to_rgb

ROOT=Path(__file__).resolve().parent
MAN=ROOT.parent/'manuscript'
OUT=MAN/'figures'
plt.rcParams.update({'font.family':'Liberation Sans','font.size':8.5,
    'axes.labelsize':8.5,'xtick.labelsize':8,'ytick.labelsize':8,
    'axes.linewidth':.55,'pdf.fonttype':42,'ps.fonttype':42,
    'svg.fonttype':'none','text.color':'#243e4e','axes.labelcolor':'#243e4e',
    'xtick.color':'#516671','ytick.color':'#516671','savefig.facecolor':'white'})
INK='#243e4e';TEAL='#337d83';PALE='#e6eef0';RUST='#aa5a26';GREY='#d8e2e7'
labels={'astar':'Restarted A*','lpa_query':'Query-local LPA*'}
corpus={'generated':'Generated','external':'External','finite':'Fixed square'}
regimes=['dispersed','localized','shifted']
front=pd.read_csv(ROOT/'analysis/exact_frontiers.csv')
trigger=pd.read_csv(ROOT/'analysis/trigger_stranded_work.csv')
grid=pd.read_csv(ROOT/'analysis/horizon_weight_results.csv')
coeff=pd.read_csv(ROOT/'results/all_switch_coefficients.csv')
traces=pd.read_csv(ROOT/'results/traces.csv')
interval=pd.read_csv(ROOT/'analysis/exact_interior_intervals.csv')

def save(fig,name):
    for ext in ['pdf','svg','png']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=300,bbox_inches=None,
            metadata={'Creator':'Deterministic matplotlib rendering of archived operation records'} if ext=='pdf' else None)
    plt.close(fig)

def contrast(color, against='white'):
    def lum(c):
        v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in to_rgb(c)]
        return sum(x*y for x,y in zip(v,[.2126,.7152,.0722]))
    a,b=sorted([lum(color),lum(against)])
    return (b+.05)/(a+.05)

def mix(a,b,f):
    return tuple((1-f)*x+f*y for x,y in zip(to_rgb(a),to_rgb(b)))

# A compact decision matrix: every number is an exact count, color is redundant.
fig=plt.figure(figsize=(6.3,4.0))
ax=fig.add_axes([.02,.44,.96,.51]);ax.set_xlim(0,9);ax.set_ylim(-.25,7.3);ax.axis('off')
ax.text(0,7.05,'a   Workloads with a beneficial completion',fontsize=9)
prices=[1,4,16,64,256,1024]
for j,p in enumerate(prices):ax.text(3.35+j*.92,6.27,f'{p:,}',ha='center',va='center')
ax.text(5.65,6.8,'Collision-test price ρ  (adjacency/repair-visit units)',ha='center',fontsize=8)
for ei,e in enumerate(['astar','lpa_query']):
    ytop=5.65-ei*3.0
    ax.text(0,ytop,labels[e],fontsize=8.5,va='center')
    for ri,regime in enumerate(regimes):
        y=ytop-ri*.83
        ax.text(1.73,y,regime.capitalize(),fontsize=8,va='center')
        for j,p in enumerate(prices):
            rows=grid[(grid.engine==e)&(grid.regime==regime)&(grid.check_price==p)]
            n=int(rows.any_completion_benefits.sum());assert len(rows)==72
            frac=n/72
            ax.add_patch(Rectangle((2.93+j*.92,y-.33),.84,.66,facecolor=mix('#f3f6f7',TEAL,frac),edgecolor='none'))
            ax.text(3.35+j*.92,y,f'{n}/72',ha='center',va='center',fontsize=8,
                    color='white' if contrast(mix('#f3f6f7',TEAL,frac))>=4.5 else INK)
    if ei==0:ax.plot([0,8.7],[3.38,3.38],color=GREY,lw=.7)

# Completion positions from two selected observed workloads, no interpolated data.
ax=fig.add_axes([.02,.045,.96,.335]);ax.set_xlim(0,45);ax.set_ylim(-.55,3.55);ax.axis('off')
ax.text(0,3.42,'b   Where delay helps in two observed workloads (ρ = 1)',fontsize=9)
examples=[]
for ei,e in enumerate(['astar','lpa_query']):
    row=grid[(grid.engine==e)&(grid.check_price==1)].sort_values(['interior_gain_fraction','workload_id'],ascending=[False,True]).iloc[0]
    w=row.workload_id;f=coeff[(coeff.engine==e)&(coeff.workload_id==w)&(coeff.horizon==40)].sort_values('completion_request')
    delta=(f.stranded_checks+f.terminal_delta+f.scan_delta).to_numpy()
    lazy=traces[(traces.engine==e)&(traces.workload_id==w)&(traces.policy=='lazy')]
    lazy_work=int((lazy.checks+lazy.scans).sum());endpoint=min(0,int(delta[0]));gain=(endpoint-delta)/(lazy_work+endpoint)
    y=2.25-ei*1.45
    ax.text(0,y+.52,labels[e],fontsize=8.2)
    ax.text(44.5,y+.52,f'Best gain {100*gain.max():.3f}%  ·  before query {int(row.best_completion_request)}',ha='right',fontsize=8.2)
    for k,g in enumerate(gain,1):
        color=TEAL if g>1e-12 else ('#d4dde2' if abs(g)<1e-12 else '#b97950')
        ax.add_patch(Rectangle((k-1+.2,y-.19),.81,.34,facecolor='white' if abs(g)<1e-12 else color,edgecolor=color if abs(g)<1e-12 else 'none',linewidth=.65))
        if g>1e-12: ax.plot(k-.395,y-.02,marker='o',ms=1.4,color='white',mec='none')
    for k in [1,10,20,30,40]:ax.text(k-.4,y-.45,str(k),ha='center',fontsize=7.7)
    examples.append({'engine':e,'workload_id':w,'check_price':1,'best_completion_request':int(row.best_completion_request),
        'gain_over_better_endpoint_fraction':float(gain.max()),'selection':'largest strict interior gain at rho=1 within engine'})
for x,color,txt in [(0,TEAL,'Lower work'),(15,'#d4dde2','Tie'),(24,'#b97950','Higher work')]:
    ax.add_patch(Rectangle((x,-.49),.65,.2,facecolor=color,edgecolor='none'));ax.text(x+1,-.39,txt,va='center',fontsize=8)
ax.text(44.5,-.39,'Comparison: better of upfront and never',ha='right',fontsize=7.8)
save(fig,'completion_frontiers')

# Every triggered workload appears once, sorted only for display.
fig=plt.figure(figsize=(6.3,3.55))
fig.text(.035,.965,'a   Checks purchased at completion that lazy continuation never demands',fontsize=9,va='top')
for ei,e in enumerate(['astar','lpa_query']):
    d=trigger[trigger.engine==e].sort_values(['stranded_fraction','workload_id']);n=len(d)
    ax=fig.add_axes([.10+ei*.48,.43,.375,.41]);x=np.arange(n)
    ax.bar(x,100*d.stranded_fraction,width=.88,color=TEAL,edgecolor='none')
    ax.bar(x,100*(1-d.stranded_fraction),bottom=100*d.stranded_fraction,width=.88,color=GREY,edgecolor='none')
    ax.set_ylim(0,100);ax.set_xlim(-.8,n-.2);ax.set_yticks([0,50,100],labels=['0','50','100%'])
    ax.set_xticks([0,n-1],labels=['1',str(n)])
    for spine in ['top','right']:ax.spines[spine].set_visible(False)
    ax.spines['left'].set_color(GREY);ax.spines['bottom'].set_color(GREY);ax.tick_params(length=2)
    ax.set_title(f'{labels[e]}  ·  {n} workloads',fontsize=8.6,loc='left',pad=8)
    ax.text(.98,.08,f'Median {100*d.stranded_fraction.median():.1f}%',ha='right',transform=ax.transAxes,color='white',fontsize=8.5,bbox={'facecolor':TEAL,'edgecolor':'none','pad':1.8})
fig.text(.1,.32,'Teal: unused at query 40',color=TEAL,fontsize=8)
fig.text(.58,.32,'Pale: subsequently demanded',color='#516671',fontsize=8)

# Trigger outcomes use a declared model price, separated from the fraction panel.
ax=fig.add_axes([.035,.045,.93,.245]);ax.axis('off');ax.set_xlim(0,100);ax.set_ylim(0,3.35)
ax.text(0,3.12,'b   Distinguishing the controller’s decision at ρ = 16',fontsize=9)
outcomes=[]
for ei,e in enumerate(['astar','lpa_query']):
    q=grid[(grid.engine==e)&(grid.check_price==16)]
    n=int(q.count_rule_completes.sum())
    win=int((q.count_rule_completes&~q.count_rule_worse_than_lazy).sum())
    mistime=int((q.count_rule_completes&q.count_rule_worse_than_lazy&q.any_completion_benefits).sum())
    noopp=int((q.count_rule_completes&q.count_rule_worse_than_lazy&~q.any_completion_benefits).sum())
    miss=int((~q.count_rule_completes&q.any_completion_benefits).sum())
    assert win+mistime+noopp==n
    y=2.05-ei*.81
    ax.text(0,y,labels[e],fontsize=8.1,va='center')
    ax.text(25,y,f'{win}/{n}',fontsize=8.4,color=TEAL,ha='center',va='center')
    ax.text(46,y,f'{mistime}/{n}',fontsize=8.4,color=RUST,ha='center',va='center')
    ax.text(68,y,f'{noopp}/{n}',fontsize=8.4,color=INK,ha='center',va='center')
    ax.text(90,y,f'{miss}',fontsize=8.4,color=INK,ha='center',va='center')
    outcomes.append(dict(engine=e,price=16,triggered=n,triggered_benefit=win,triggered_timing_loss=mistime,
        triggered_no_opportunity=noopp,feasible_without_trigger=miss))
for x,s in [(25,'Switch benefits'),(46,'Timing loss'),(68,'No feasible date'),(90,'Missed by no switch')]:
    ax.text(x,.30,s,ha='center',fontsize=7.5)
save(fig,'completion_investment')

# Table of exact boundaries: the distribution includes zero-frontier cases.
lines=[r'\begin{table*}[tb]',r'\caption{Exact completion frontiers at forty queries. The critical price $\rho^*$ is measured in adjacency/repair-visit work per collision test. Medians and quartiles include zero frontiers. A zero frontier means that no finite completion reduces modeled work at any positive collision-test price}\label{tab:frontiers}',r'\centering\small',r'\begin{tabular}{llrrrr}\toprule',r'Engine & Corpus & Workloads & Zero frontiers & Median $\rho^*$ & Interquartile range\\\midrule']
for e in ['astar','lpa_query']:
    for c in ['generated','external','finite']:
        f=front[(front.engine==e)&(front.corpus==c)];q=f.critical_check_price.quantile([.25,.5,.75])
        lines.append(f"{labels[e].replace('*',r'$^*$')} & {corpus[c]} & {len(f)} & {int((f.critical_check_price==0).sum())} & {q[.5]:.3f} & [{q[.25]:.3f}, {q[.75]:.3f}]"+r'\\')
    if e=='astar':lines.append(r'\midrule')
lines += [r'\bottomrule\end{tabular}',r'\end{table*}']
(MAN/'tables/completion_frontiers.tex').write_text('\n'.join(lines)+'\n')

summary={'figure_examples':examples,'controller_price_16_partition':outcomes,'frontiers':{}}
for e in labels:
    f=front[front.engine==e];v=interval[(interval.engine==e)&(interval.horizon==40)]
    summary['frontiers'][e]={'n':len(f),'zero':int((f.critical_check_price==0).sum()),
        'median':float(f.critical_check_price.median()),'maximum':float(f.critical_check_price.max()),
        'strict_interior_cases_all_positive_prices':int(v.any_strictly_better_delayed_date.sum())}
(ROOT/'analysis/PUBLICATION_SUMMARY.json').write_text(json.dumps(summary,indent=2))

# Graphical abstract: short, exact representation of the new scientific claim.
fig=plt.figure(figsize=(10,3.8));ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,10);ax.set_ylim(0,3.8);ax.axis('off')
ax.text(.28,3.48,'When does completing a roadmap pay?',fontsize=15,color=INK)
ax.text(.28,3.12,'Fixed obstacle graph · changing start and goal · repeated collision-free path queries',fontsize=10,color='#526875')
for x,title in [(.28,'Observe two reference traces'),(3.65,'Recover every completion date'),(7.05,'Compare with never completing')]:
    ax.text(x,2.64,title,fontsize=10.1,color=INK)
for y,lab,color in [(2.07,'Lazy',INK),(1.49,'Completed',TEAL)]:
    ax.text(.28,y+.02,lab,fontsize=9.1,va='center')
    for i in range(6):ax.add_patch(Rectangle((1.15+i*.27,y-.15),.23,.30,facecolor=color,edgecolor='none'))
ax.text(.28,.92,'Same queries, graph and search rules',fontsize=9.1)
for r,k in enumerate([0,2,4]):
    for i in range(6):ax.add_patch(Rectangle((3.67+i*.33,2.00-r*.4),.29,.29,facecolor=INK if i<k else TEAL,edgecolor='none'))
ax.text(3.65,.92,'Cost of unused checks − service savings',fontsize=9.1)
ax.text(3.65,.55,'Exact criterion from two executions',fontsize=9.1,color=TEAL)
for a,b in [(2.98,3.38),(6.36,6.78)]:
    ax.add_patch(FancyArrowPatch((a,1.72),(b,1.72),arrowstyle='-|>',mutation_scale=10,color='#8397a3',lw=1))
ax.text(7.05,2.07,'17,280 completion schedules verified',fontsize=10,color=TEAL)
ax.text(7.05,1.61,'Delay beats both upfront and never:',fontsize=9.1)
ax.text(7.05,1.19,'1 / 216  A* workloads',fontsize=11,color=INK)
ax.text(7.05,.82,'40 / 216  query-local LPA* workloads',fontsize=10,color=TEAL)
ax.text(7.05,.40,'For some positive test price · 40-query horizon',fontsize=8.2,color='#526875')
ax.text(.28,.18,'Constructed trace schematic; result counts are from the exhaustive finite-workload analysis.',fontsize=8.1,color='#526875')
save(fig,'graphical_summary_jirs')
for ext in ['pdf','svg','png']:
    (MAN/f'graphical_abstract.{ext}').write_bytes((OUT/f'graphical_summary_jirs.{ext}').read_bytes())
print(json.dumps(summary,indent=2))
