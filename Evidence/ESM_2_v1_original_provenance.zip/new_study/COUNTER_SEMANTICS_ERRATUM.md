# Clarification of the archived scans counter

Independent code review on 18 November 2026 identified a naming correction.
The original record named `scans` as adjacency inspections. In `LPA.shortest`,
the repair loop iterates `list(self.adj[u]) + [u]` and increments `scans` for each
entry. It therefore includes one explicit self visit in addition to neighbor
examinations in that branch. Restarted A* counts neighbor entries.

The revised manuscript uses **adjacency/repair visits** and explains the exact
counter definition. All archived values, executed code, and comparative ratios
are preserved. The two-trace identity applies to this deterministic counter.
This clarification changes its interpretation and label, not the operation
traces, linear weights, or verification protocol's execution. The signed
pre-execution PROTOCOL.md remains intact; this note records its corrected term.
