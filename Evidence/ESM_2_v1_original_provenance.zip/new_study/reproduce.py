#!/usr/bin/env python3
"""Verify Online Resource 2 or reproduce its analysis in a fresh directory."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile


SOURCE = Path(__file__).resolve().parent
BASELINE_SHA256 = '6eeb0f605d4081b9a9e2acd157e88ecdfaf5eba09c73fdeb00df1c0a86ff962c'
ANALYSES = ('analyze_two_trace.py', 'exact_interior.py', 'make_publication_outputs.py', 'make_theory_visual.py')
RAW_RECORDS = ('traces.csv', 'all_switch_coefficients.csv', 'exhaustive_verification.csv')
CORE_ANALYSES = ('exact_frontiers.csv', 'exact_interior_intervals.csv', 'frontier_group_summary.csv',
                 'grid_group_summary.csv', 'horizon_weight_results.csv', 'trigger_group_summary.csv',
                 'trigger_stranded_work.csv', 'weight_summary.csv')


def sha256(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def member_path(root, name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        raise ValueError(f'Invalid relative member path {name!r}')
    parts = PurePosixPath(name).parts
    if not parts or PurePosixPath(name).is_absolute() or PureWindowsPath(name).drive or '..' in parts:
        raise ValueError(f'Unsafe member path {name!r}')
    candidate = root.joinpath(*parts)
    if not candidate.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Member escapes its directory: {name}')
    return candidate


def verify_manifest(manifest):
    records = json.loads(manifest.read_text(encoding='utf-8'))
    if not isinstance(records, dict) or not records:
        raise ValueError(f'Expected a nonempty JSON path-to-SHA-256 mapping in {manifest}')
    checked = 0
    for name, expected in records.items():
        path = member_path(manifest.parent, name)
        if path.resolve() == manifest.resolve():
            continue
        if not isinstance(expected, str) or re.fullmatch('[0-9a-fA-F]{64}', expected) is None:
            raise ValueError(f'Invalid SHA-256 for {name}')
        if path.is_symlink() or not path.is_file() or sha256(path) != expected.lower():
            raise ValueError(f'Integrity check failed for {name}')
        checked += 1
    if not checked:
        raise ValueError(f'Manifest has no data members: {manifest}')
    return checked


def default_manifest():
    candidates = [SOURCE / 'MANIFEST_SHA256.json', SOURCE.parent / 'MANIFEST_SHA256.json']
    for manifest in candidates:
        if manifest.is_file():
            return manifest
    raise ValueError('MANIFEST_SHA256.json is missing. Pass --manifest PATH to the supplied manifest.')


def unpack_baseline(archive, target):
    target.mkdir(parents=True)
    with zipfile.ZipFile(archive) as source:
        seen = set()
        for item in source.infolist():
            path = member_path(target, item.filename)
            if path in seen:
                raise ValueError(f'Duplicate archive member {item.filename!r}')
            seen.add(path)
            file_type = stat.S_IFMT(item.external_attr >> 16)
            if file_type not in (0, stat.S_IFDIR, stat.S_IFREG):
                raise ValueError(f'Unsupported archive member type: {item.filename}')
            if item.is_dir():
                path.mkdir(exist_ok=True, parents=True)
            else:
                path.parent.mkdir(exist_ok=True, parents=True)
                with source.open(item) as inp, path.open('xb') as out:
                    shutil.copyfileobj(inp, out)
    return verify_manifest(target / 'MANIFEST_SHA256.json')


def compare_files(recorded, regenerated, names):
    matches = {}
    for name in names:
        expected = sha256(recorded / name)
        actual = sha256(regenerated / name)
        if expected != actual:
            raise ValueError(f'Regenerated file differs from the deposited record: {regenerated / name}')
        matches[name] = actual
    return matches


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--verify', action='store_true', help='verify the deposited SHA-256 manifest')
    modes.add_argument('--analysis', action='store_true', help='rebuild analyses and publication outputs from recorded operations')
    modes.add_argument('--full', action='store_true', help='also repeat all direct branch executions before rebuilding analyses')
    parser.add_argument('--manifest', type=Path, help='manifest with paths relative to its directory')
    parser.add_argument('--baseline-zip', type=Path, help='original ESM_1.zip supplied with this article')
    parser.add_argument('--out', type=Path, help='fresh, non-existent directory for reproduced outputs')
    args = parser.parse_args()
    manifest = args.manifest.resolve() if args.manifest else default_manifest()
    checked = verify_manifest(manifest)
    print(f'Verified {checked} files in {manifest}.', flush=True)
    if args.verify:
        return
    if args.out is None or args.baseline_zip is None:
        parser.error('--analysis and --full require --baseline-zip PATH and --out NEW_DIRECTORY')
    archive, output = args.baseline_zip.resolve(), args.out.resolve()
    if output.exists() or output.is_relative_to(SOURCE):
        parser.error('--out must be a new directory outside the deposited new_study directory')
    if sha256(archive) != BASELINE_SHA256:
        raise ValueError(f'ESM_1 archive does not match the published SHA-256: {archive}')
    output.mkdir(parents=True, exist_ok=False)
    n_baseline = unpack_baseline(archive, output / 'baseline/evidence')
    print(f'Verified ESM_1 archive and {n_baseline} extracted files.', flush=True)
    stage = output / 'new_study'
    stage.mkdir()
    for name in ('run_two_trace.py', 'PROTOCOL.md', 'COUNTER_SEMANTICS_ERRATUM.md', *ANALYSES):
        shutil.copy2(SOURCE / name, stage / name)
    for name in ('figures', 'tables'):
        (output / 'manuscript' / name).mkdir(parents=True)
    logs = output / 'logs'
    logs.mkdir()
    environment = dict(os.environ, MPLBACKEND='Agg', MPLCONFIGDIR=str(output / 'matplotlib-cache'),
                       PYTHONDONTWRITEBYTECODE='1')
    if not args.full:
        shutil.copytree(SOURCE / 'results', stage / 'results')
    programs = ('run_two_trace.py', *ANALYSES) if args.full else ANALYSES
    for script in programs:
        logfile = logs / (Path(script).stem + '.log')
        print(f'Running {script} (log: {logfile}).', flush=True)
        with logfile.open('w', encoding='utf-8') as handle:
            result = subprocess.run([sys.executable, str(stage / script)], cwd=stage,
                                    env=environment, stdout=handle, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'{script} exited with code {result.returncode}. See {logfile}.')
    matches = compare_files(SOURCE / 'analysis', stage / 'analysis', CORE_ANALYSES)
    raw_matches = compare_files(SOURCE / 'results', stage / 'results', RAW_RECORDS) if args.full else {}
    report = {
        'mode': 'full' if args.full else 'analysis',
        'verified_esm2_manifest_members': checked,
        'verified_esm1_manifest_members': n_baseline,
        'esm1_zip_sha256': BASELINE_SHA256,
        'matching_analysis_csv_sha256': matches,
        'matching_regenerated_direct_csv_sha256': raw_matches,
        'regenerated_figures': sorted(path.name for path in (output / 'manuscript/figures').glob('*')),
        'regenerated_tables': sorted(path.name for path in (output / 'manuscript/tables').glob('*')),
    }
    report_path = output / 'REPRODUCTION_REPORT.json'
    report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(f'All {len(matches)} analysis CSVs match byte for byte. Report: {report_path}', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as error:
        raise SystemExit(str(error)) from error
